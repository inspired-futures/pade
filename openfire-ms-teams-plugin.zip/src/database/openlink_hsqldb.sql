// $Revision$
// $Date$

INSERT INTO ofVersion (name, version) VALUES ('openlink', 0);


CREATE TABLE ofcalllog (
  callId VARCHAR(255) NOT NULL,
  tscId VARCHAR(50),  
  profileId VARCHAR(255),
  interestId VARCHAR(255),
  state VARCHAR(50),
  direction VARCHAR(50),
  startTimestamp TIMESTAMP NOT NULL,
  duration BIGINT,
  callerName VARCHAR(255),
  callerNumber VARCHAR(255),
  calledName VARCHAR(255),  
  calledNumber VARCHAR(255),
  CONSTRAINT ofcalllog_pk PRIMARY KEY (callId, startTimestamp)  
);

CREATE TABLE ofparticipantlog (
  callId VARCHAR(255) NOT NULL,
  jid VARCHAR(255) NOT NULL,
  tscId VARCHAR(50),    
  direction VARCHAR(50),
  type VARCHAR(50),
  startTimestamp TIMESTAMP NOT NULL,
  duration BIGINT,
  CONSTRAINT ofparticipantlog_pk PRIMARY KEY (callId, jid, startTimestamp)    
); 