# $Revision$
# $Date$

INSERT INTO ofVersion (name, version) VALUES ('openlink', 0);

 
CREATE TABLE ofcalllog (
  callId VARCHAR(255) NOT NULL,
  tscId VARCHAR(50),  
  profileId VARCHAR(255) DEFAULT NULL,
  interestId VARCHAR(255) DEFAULT NULL,
  state VARCHAR(50) DEFAULT NULL,
  direction VARCHAR(50) DEFAULT NULL,
  startTimestamp TIMESTAMP NOT NULL,
  duration bigint(20) DEFAULT NULL,
  callerName VARCHAR(255) DEFAULT NULL,
  callerNumber VARCHAR(255) DEFAULT NULL,
  calledName VARCHAR(255) DEFAULT NULL, 
  calledNumber VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (callId, startTimestamp)  
);

CREATE TABLE ofparticipantlog (
  callId VARCHAR(255) NOT NULL,
  tscId VARCHAR(50),  
  jid VARCHAR(255) NOT NULL,
  direction VARCHAR(50) DEFAULT NULL,
  type VARCHAR(50) DEFAULT NULL,
  startTimestamp TIMESTAMP NOT NULL,
  duration bigint(20) DEFAULT NULL,
  PRIMARY KEY (callId, jid, startTimestamp)  
); 