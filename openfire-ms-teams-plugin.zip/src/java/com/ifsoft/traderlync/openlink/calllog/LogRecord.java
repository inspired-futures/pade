package com.ifsoft.traderlync.openlink.calllog;

/**
 *
 */
public interface LogRecord {

}
