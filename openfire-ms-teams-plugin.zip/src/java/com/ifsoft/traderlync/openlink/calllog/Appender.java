package com.ifsoft.traderlync.openlink.calllog;

/**
 *
 */
public interface Appender {

	public void append(LogRecord logRecord);

}
