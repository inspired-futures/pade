package com.ifsoft.traderlync.openlink.commands;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.dom4j.Element;
import org.xmpp.packet.JID;

import org.jivesoftware.util.Log;

import com.ifsoft.traderlync.openlink.component.*;
import com.ifsoft.traderlync.openlink.calllog.*;


public class GetCallHistory extends OpenlinkCommand {

	public GetCallHistory(TraderLyncComponent traderlyncComponent)
	{
		super(traderlyncComponent);
	}

	@Override protected boolean addStageInformation(SessionData data, Element newCommand, Element oldCommand)
	{
		return false;
	}

	@Override public Element execute(SessionData data, Element newCommand, Element oldCommand)
	{
		Element in = oldCommand.element("iodata").element("in");

		JID userJID = null;

		try {
			userJID = new JID(in.element("jid").getText());

			if (!validPermissions(data, userJID.getNode(), newCommand))
				return newCommand;
		} catch (Exception e) {
			Element note = newCommand.addElement("note");
			note.addAttribute("type", "error");
			note.setText("Get Call History - Invalid JID");
			return newCommand;
		}

		try {

			String caller 	= in.element("caller") == null ? null : in.element("caller").getText();
			String called 	= in.element("called") == null ? null : in.element("called").getText();
			String callType = in.element("calltype") == null ? null : in.element("calltype").getText();
			String fromDate = in.element("fromdate") == null ? null : in.element("fromdate").getText();
			String uptoDate = in.element("uptodate") == null ? null : in.element("uptodate").getText();
			String start 	= in.element("start") == null ? "0" : in.element("start").getText();
			String count 	= in.element("count") == null ? "50" : in.element("count").getText();

			DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
			formatter.setLenient(false);
			Date startDate = null;
			Date endDate = null;

			try {

				if("".equalsIgnoreCase(start))
					start = "0";
				if("".equalsIgnoreCase(count))
					count = "50";

				if(null != callType && !"".equals(callType)) {
					if(!"in".equalsIgnoreCase(callType) && !"out".equalsIgnoreCase(callType) && !"missed".equalsIgnoreCase(callType)) {
						Element note = newCommand.addElement("note");
						note.addAttribute("type", "error");
						note.setText("Get Call History - Expected values for type of call are in, out or missed");
						return newCommand;
					}
				}

				if (fromDate != null && fromDate.length() > 0)
					startDate = formatter.parse(fromDate);

				if (uptoDate != null && uptoDate.length() > 0)
					endDate = formatter.parse(uptoDate);
			}

			catch (Exception e) {
				Log.error("Get Call History - Start or end date should be valide date and in mm/dd/yyyy format", e);
				Element note = newCommand.addElement("note");
				note.addAttribute("type", "error");
				note.setText("Get Call History - Start or end date not valid. Date should be a valid and in mm/dd/yyyy format");
				return newCommand;
			}
			CallFilter filter = CallLogDAO.createSQLFilter(userJID.getNode(), caller, called, callType, startDate, endDate, "traderlync");

			if ((filter != null && !"".equals(filter)) && Integer.parseInt(count) > 0 && Integer.parseInt(start) >= 0)
			{
				int numberOfCalls = CallLogDAO.getLogCount(filter);

				if (numberOfCalls > 0)
				{
					Collection<CallLog> calls = CallLogDAO.getCalls(filter, Integer.parseInt(start), Integer.parseInt(count));

					Iterator<CallLog> it = calls.iterator();
					int i = 0;

					Element iodata = newCommand.addElement("iodata", "urn:xmpp:tmp:io-data");
					iodata.addAttribute("type","output");

					Element callHistory = iodata.addElement("out").addElement("callhistory", "http://xmpp.org/protocol/openlink:01:00:00/callhistory");

					callHistory.addAttribute("total", String.valueOf(numberOfCalls));
					callHistory.addAttribute("start", String.valueOf(start));
					callHistory.addAttribute("count", String.valueOf(count));

					while(it.hasNext())
					{
						CallLog callLog = (CallLog)it.next();

						Element call = callHistory.addElement("call");

						call.addElement("id").setText(callLog.getCallId());
						call.addElement("profile").setText(callLog.getProfileId());
						call.addElement("interest").setText(callLog.getInterestId());
						call.addElement("state").setText(callLog.getState());
						call.addElement("direction").setText(callLog.getDirection());
						call.addElement("tsc").setText(callLog.getTscId());

						call.addElement("caller").setText(callLog.getCallerNumber());
						call.addElement("callername").setText(callLog.getCallerName());
						call.addElement("called").setText(callLog.getCalledNumber());
						call.addElement("calledname").setText(callLog.getCalledName());

						call.addElement("duration").setText(String.valueOf(callLog.getParticipantLog().getDuration()));
						call.addElement("timestamp").setText(String.valueOf(callLog.getParticipantLog().getStartTimestamp()));
					}
				} else {
					Element note = newCommand.addElement("note");
					note.addAttribute("type", "error");
					note.setText("Get Call History - No records found");
					return newCommand;
				}
			} else {
				Element note = newCommand.addElement("note");
				note.addAttribute("type", "error");
				note.setText("Get Call History - Invalid Request");
				return newCommand;
			}
		} catch (Exception e) {
			Log.error("[Openlink]Get Call History error ", e);

			Element note = newCommand.addElement("note");
			note.addAttribute("type", "error");
			note.setText("Get Call History - Missing or bad input");
		}
		return newCommand;
	}

	@Override protected List<Action> getActions(SessionData data)
	{
		return Arrays.asList(new Action[] { Action.complete });
	}

	@Override public String getCode()
	{
		return "http://xmpp.org/protocol/openlink:01:00:00#get-call-history";
	}

	@Override public String getDefaultLabel()
	{
		return "Get Call History";
	}

	@Override protected Action getExecuteAction(SessionData data)
	{
		return Action.complete;
	}

	@Override public int getMaxStages(SessionData data)
	{
		return 0;
	}
}
