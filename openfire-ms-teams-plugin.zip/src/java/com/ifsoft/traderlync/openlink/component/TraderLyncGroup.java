package com.ifsoft.traderlync.openlink.component;

public class TraderLyncGroup extends AbstractGroup
{

}

