package com.ifsoft.traderlync.openlink.component;

import java.net.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import org.jivesoftware.database.DbConnectionManager;
import org.jivesoftware.openfire.http.HttpBindManager;
import org.jivesoftware.openfire.lockout.LockOutManager;
import org.jivesoftware.openfire.SessionManager;
import org.jivesoftware.openfire.session.LocalClientSession;
import org.jivesoftware.openfire.session.Session;
import org.jivesoftware.openfire.RoutingTable;
import org.jivesoftware.openfire.SharedGroupException;
import org.jivesoftware.openfire.XMPPServer;
import org.jivesoftware.openfire.PrivateStorage;
import org.jivesoftware.openfire.user.*;
import org.jivesoftware.openfire.vcard.*;
import org.jivesoftware.openfire.group.*;
import org.jivesoftware.openfire.muc.*;
import org.jivesoftware.openfire.cluster.ClusterManager;
import org.jivesoftware.util.*;
import org.jivesoftware.openfire.roster.*;

import org.xmpp.component.Component;
import org.xmpp.component.AbstractComponent;
import org.xmpp.component.ComponentException;
import org.xmpp.component.ComponentManager;
import org.xmpp.component.ComponentManagerFactory;

import org.xmpp.packet.IQ;
import org.xmpp.packet.JID;
import org.xmpp.packet.Message;
import org.xmpp.packet.Presence;
import org.xmpp.packet.Packet;

import com.ifsoft.traderlync.openlink.commands.*;
import com.ifsoft.traderlync.openlink.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.sf.json.*;
import org.jivesoftware.openfire.plugin.spark.*;

public class TraderLyncComponent extends AbstractTSComponent implements TraderLyncConstants, MUCEventListener
{
    private static final Logger Log = LoggerFactory.getLogger(TraderLyncComponent.class);
    private ComponentManager componentManager;
    private JID componentJID = null;

    private XMPPServer server = XMPPServer.getInstance();
    private MultiUserChatManager mucManager;
    private PrivateStorage privateStorage;
    private UserManager userManager;
    private RosterManager rosterManager;
    private SessionManager sessionManager;
    private OpenlinkCommandManager openlinkManger;

    public Map<String, TraderLyncUserInterest> openlinkInterests;
    public Map<String, TraderLyncUserInterest> defaultInterests;
    public Map<String, TraderLyncUser> traderLyncUserTable;
    public Map<String, TraderLyncInterest> traderLyncInterests;
    public Map<String, TraderLyncUserInterest> callList;
    public Map<String, TraderLyncInterest> missedCallList;
    public Map<String, TraderLyncUserInterest> heldCallList;
    public Map<String, TraderLyncUserInterest> transferCallList;
    public Map<String, BridgeParticipant> bridgeParticipants;
    public Map<String, BridgeParticipant> intercomList;
    public Map<String, JSONObject> reverseSpeeedDials;

    private Map<String, String> thirdPartyCalls;
    private Map<String, String> thirdPartyCallList;

    public TelephoneNumberFormatter telephoneNumberFormatter;
    public Site site;

    private Vector<TraderLyncUser> sortedProfiles;
    private Timer timer = null;
    private DateFormat dateFormat;

    private String instantVoiceConference = null;
    public Map<String, String> instantVoices = null;
    private boolean instantVoiceEnabled = false;

    static public TraderLyncComponent self;


    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------


    public TraderLyncComponent(Site site)
    {
        super(16, 1000, true);

        this.site = site;
        this.componentJID = new JID(getName() + "." + getDomain());
        sortedProfiles =  new Vector<TraderLyncUser>();

        self = this;

        TimeZone tz =  JiveGlobals.getTimeZone();
        dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'");
        dateFormat.setTimeZone(tz);

        Log.info( "["+ site.getName() + "] TraderLyncComponent Initialised");
    }

    public void componentEnable()
    {
        privateStorage      = server.getPrivateStorage();
        userManager         = server.getUserManager();
        rosterManager       = server.getRosterManager();
        sessionManager      = server.getSessionManager();
        mucManager          = server.getMultiUserChatManager();

        componentManager    = ComponentManagerFactory.getComponentManager();
        openlinkManger      = new OpenlinkCommandManager();

        openlinkInterests   = new ConcurrentHashMap<String, TraderLyncUserInterest>();
        defaultInterests    = new ConcurrentHashMap<String, TraderLyncUserInterest>();
        traderLyncUserTable = new ConcurrentHashMap<String, TraderLyncUser>();
        traderLyncInterests = new ConcurrentHashMap<String, TraderLyncInterest>();

        callList            = new ConcurrentHashMap<String, TraderLyncUserInterest>();
        missedCallList      = new ConcurrentHashMap<String, TraderLyncInterest>();
        heldCallList        = new ConcurrentHashMap<String, TraderLyncUserInterest>();
        transferCallList    = new ConcurrentHashMap<String, TraderLyncUserInterest>();

        bridgeParticipants  = new ConcurrentHashMap<String, BridgeParticipant>();
        intercomList        = new ConcurrentHashMap<String, BridgeParticipant>();

        thirdPartyCalls     = new ConcurrentHashMap<String, String>();
        thirdPartyCallList  = new ConcurrentHashMap<String, String>();
        reverseSpeeedDials  = new ConcurrentHashMap<String, JSONObject>();

        timer = new Timer();

        Log.info( "["+ site.getName() + "] Creating telephoneNumberFormatter object");
        setupTelephoneNumberFormatter();

        Log.info( "["+ site.getName() + "] Creating user profiles");
        getUserProfiles();

        openlinkManger.addCommand(new GetProfiles(this));
        openlinkManger.addCommand(new GetProfile(this));
        openlinkManger.addCommand(new GetInterests(this));
        openlinkManger.addCommand(new GetInterest(this));
        openlinkManger.addCommand(new GetFeatures(this));
        openlinkManger.addCommand(new MakeCall(this));
        openlinkManger.addCommand(new IntercomCall(this));
        openlinkManger.addCommand(new RequestAction(this));
        openlinkManger.addCommand(new SetFeature(this));
        openlinkManger.addCommand(new QueryFeatures(this));
        openlinkManger.addCommand(new ManageVoiceBridge(this));
        openlinkManger.addCommand(new GetCallHistory(this));
        openlinkManger.addCommand(new Meet(this));


        MUCEventDispatcher.addListener(this);
    }

    public void componentDestroyed()
    {
        try {
            openlinkManger.stop();

            if (timer != null) {
                timer.cancel();
                timer = null;
            }

            MUCEventDispatcher.removeListener(this);
        }
        catch(Exception e) {
            Log.error(e.toString());
        }
    }


    public void setupTelephoneNumberFormatter()
    {
        Log.info( "["+ site.getName() + "] setupTelephoneNumberFormatter");

        try
        {
            String pname = site.getName().toLowerCase();
            String country = JiveGlobals.getProperty(Properties.TraderLync_PBX_COUNTRY_CODE + "."  + pname, Locale.getDefault().getCountry());

            String pbxAccessDigits  = JiveGlobals.getProperty(Properties.TraderLync_PBX_ACCESS_DIGITS   + "."  + pname, "9");
            String areaCode         = JiveGlobals.getProperty(Properties.TraderLync_AREA_CODE       + "."  + pname, "0207");
            String pbxNumberLength  = JiveGlobals.getProperty(Properties.TraderLync_PBX_NUMBER_LENGTH + "."  + pname, "5");

            telephoneNumberFormatter = new TelephoneNumberFormatter(new Locale("en", country));
            telephoneNumberFormatter.setExtensionNumberLength(Integer.parseInt(pbxNumberLength));
            telephoneNumberFormatter.setOutsideAccess(pbxAccessDigits);
            telephoneNumberFormatter.setAreaCode(areaCode);
            telephoneNumberFormatter.setLocale(new Locale("en", country));
        }
        catch (Exception e)
        {
            Log.error( "["+ site.getName() + "] setupTelephoneNumberFormatter ", e);
        }
    }

    public String formatCanonicalNumber(String dialDigits)
    {
        String canonicalNumber = dialDigits;

        try
        {
            canonicalNumber = telephoneNumberFormatter.formatCanonicalNumber(dialDigits);
        }
        catch (Exception e)
        {
            Log.error( "["+ site.getName() + "] formatCanonicalNumber ", e);
        }

        return canonicalNumber;
    }

    public String formatDialableNumber(String cononicalNumber)
    {
        String dialableNumber = cononicalNumber;

        try
        {
            dialableNumber = telephoneNumberFormatter.formatDialableNumber(cononicalNumber);
        }
        catch (Exception e)
        {
            cononicalNumber = formatCanonicalNumber(cononicalNumber);

            try
            {
                dialableNumber = telephoneNumberFormatter.formatDialableNumber(cononicalNumber);
            }

            catch (Exception e1)
            {
                Log.error( "["+ site.getName() + "] formatDialableNumber ", e1);
            }
        }

        return dialableNumber;
    }

    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------

    @Override public String getDescription()
    {
        return "TraderLynk Component";
    }


    @Override public String getName()
    {
        return "traderlynk";
    }

    @Override public String getDomain()
    {
        return  XMPPServer.getInstance().getServerInfo().getXMPPDomain();
    }

    @Override public void postComponentStart()
    {

    }

    @Override public void postComponentShutdown()
    {

    }

    public JID getComponentJID()
    {
        return new JID(getName() + "." + getDomain());
    }

    public String getSiteName()
    {
        if (site == null)
            return "";
        else
            return site.getName();
    }

    public int getUserCount()
    {
        return traderLyncUserTable.values().size();
    }

    public List<TraderLyncUser> getUsers(int startIndex, int numResults)
    {
        List<TraderLyncUser> profiles  = new ArrayList<TraderLyncUser>();
        int counter = 0;

        if (startIndex == 0 || sortedProfiles.size() == 0)
        {
            sortedProfiles = new Vector<TraderLyncUser>(traderLyncUserTable.values());
            Collections.sort(sortedProfiles);
        }

        Iterator it = sortedProfiles.iterator();

        while( it.hasNext() )
        {
            TraderLyncUser traderLyncUser = (TraderLyncUser)it.next();

            if (counter > (startIndex + numResults))
            {
                break;
            }

            if (counter >= startIndex)
            {
                profiles.add(traderLyncUser);
            }

            counter++;
        }

        return profiles;
    }


    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------


    public void interceptMessage(Message received)
    {
        //traderLyncLinkService.interceptMessage(received);
    }

    @Override protected void handleMessage(Message received)
    {
        Log.debug("["+ site.getName() + "] handleMessage \n"+ received.toString());
    }

    @Override protected void handleIQResult(IQ iq)
    {
        Log.debug("["+ site.getName() + "] handleIQResult \n"+ iq.toString());

        Element element = iq.getChildElement();

        if (element != null)
        {
            String namespace = element.getNamespaceURI();

            if("http://jabber.org/protocol/pubsub#owner".equals(namespace))
            {
                Element subscriptions = element.element("subscriptions");

                if (subscriptions != null)
                {
                    String node = subscriptions.attributeValue("node");

                    Log.debug("["+ site.getName() + "] handleIQResult found subscription node " + node);

                    if (openlinkInterests.containsKey(node))
                    {
                        Log.debug("["+ site.getName() + "] handleIQResult found user interest " + node);

                        TraderLyncUserInterest traderLyncUserInterest = openlinkInterests.get(node);

                        for ( Iterator<Element> i = subscriptions.elementIterator( "subscription" ); i.hasNext(); )
                        {
                            Element subscription = (Element) i.next();
                            JID jid = new JID(subscription.attributeValue("jid"));
                            String sub = subscription.attributeValue("subscription");

                            TraderLyncSubscriber traderLyncSubscriber = traderLyncUserInterest.getSubscriber(jid);
                            traderLyncSubscriber.setSubscription(sub);

                            //BloombergPlugin.self.setSubscriberDetails(jid, traderLyncSubscriber);

                            Log.debug("["+ site.getName() + "] handleIQResult added subscriber " + jid);

                        }
                    }
                }
            }
        }
    }

    @Override protected void handleIQError(IQ iq)
    {
        String xml = iq.toString();

        if (xml.indexOf("<create node=") == -1)
            Log.debug("["+ site.getName() + "] handleIQError \n"+ iq.toString());
    }

   @Override public IQ handleDiscoInfo(IQ iq)
    {
        JID jid = iq.getFrom();
        Element child = iq.getChildElement();
        String node = child.attributeValue("node");

        IQ iq1 = IQ.createResultIQ(iq);
        iq1.setType(org.xmpp.packet.IQ.Type.result);
        iq1.setChildElement(iq.getChildElement().createCopy());

        Element queryElement = iq1.getChildElement();
        Element identity = queryElement.addElement("identity");

        queryElement.addElement("feature").addAttribute("var",NAMESPACE_DISCO_INFO);
        queryElement.addElement("feature").addAttribute("var",NAMESPACE_XMPP_PING);

        identity.addAttribute("category", "component");
        identity.addAttribute("name", "traderLync");

        if (node == null)               // Disco discovery of openlink
        {
            identity.addAttribute("type", "command-list");
            queryElement.addElement("feature").addAttribute("var", "http://jabber.org/protocol/commands");
            queryElement.addElement("feature").addAttribute("var", "http://xmpp.org/protocol/openlink:01:00:00");
            queryElement.addElement("feature").addAttribute("var", "http://xmpp.org/protocol/openlink:01:00:00#tsc");


        } else {

            // Disco discovery of Openlink command

            OpenlinkCommand command = openlinkManger.getCommand(node);

            if (command != null && command.hasPermission(jid))
            {
                identity.addAttribute("type", "command-node");
                queryElement.addElement("feature").addAttribute("var", "http://jabber.org/protocol/commands");
                queryElement.addElement("feature").addAttribute("var", "http://xmpp.org/protocol/openlink:01:00:00");
            }

        }
        Log.debug("["+ site.getName() + "] handleDiscoInfo "+ iq1.toString());
        return iq1;
    }


   @Override public IQ handleDiscoItems(IQ iq)
    {
        JID jid = iq.getFrom();
        Element child = iq.getChildElement();
        String node = child.attributeValue("node");

        IQ iq1 = IQ.createResultIQ(iq);
        iq1.setType(org.xmpp.packet.IQ.Type.result);
        iq1.setChildElement(iq.getChildElement().createCopy());

        Element queryElement = iq1.getChildElement();
        Element identity = queryElement.addElement("identity");

        identity.addAttribute("category", "component");
        identity.addAttribute("name", "openlink");
        identity.addAttribute("type", "command-list");

        if ("http://jabber.org/protocol/commands".equals(node))
        {
            for (OpenlinkCommand command : openlinkManger.getCommands())
            {
                // Only include commands that the sender can invoke (i.e. has enough permissions)

                if (command.hasPermission(jid))
                {
                    Element item = queryElement.addElement("item");
                    item.addAttribute("jid", componentJID.toString());
                    item.addAttribute("node", command.getCode());
                    item.addAttribute("name", command.getLabel());
                }
            }
        }
        Log.debug("["+ site.getName() + "] handleDiscoItems "+ iq1.toString());
        return iq1;
    }

   @Override public IQ handleIQGet(IQ iq)
    {
        return handleIQPacket(iq);
    }

   @Override public IQ handleIQSet(IQ iq)
    {
        return handleIQPacket(iq);
    }

   private IQ handleIQPacket(IQ iq)
    {
        Log.debug("["+ site.getName() + "] handleIQPacket \n"+ iq.toString());

        Element element = iq.getChildElement();
        IQ iq1 = IQ.createResultIQ(iq);
        iq1.setType(org.xmpp.packet.IQ.Type.result);
        iq1.setChildElement(iq.getChildElement().createCopy());

        if (element != null)
        {
            String namespace = element.getNamespaceURI();

            if("http://jabber.org/protocol/commands".equals(namespace))
                iq1 = openlinkManger.process(iq);
        }
        return iq1;
    }


    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------

    public boolean isUserOnline(TraderLyncUser traderLyncUser)
    {
        if (traderLyncUser.email != null && traderLyncUser.email.contains("@"))
        {
            String uname = traderLyncUser.email.split("@")[0];

            if (uname.equals(traderLyncUser.getDeviceNo()))
            {
                String key = traderLyncUser.email;
            }
        }
        return true;
    }

    public void instantVoiceAction(String action, String from, String to)
    {
        if (instantVoiceEnabled && instantVoices != null && from != null && to != null && instantVoices.containsKey(from) && instantVoices.containsKey(to))
        {
            String memberFrom = instantVoices.get(from);
            String memberTo = instantVoices.get(to);

            Log.debug("["+ site.getName() + "] instantVoiceAction " + memberFrom + " " + memberTo  + " " + action);
        }
    }



    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------


    public void handleOnOffHook(String lineNo, boolean onHook, boolean offHook, Map<String, String> headers)
    {
        Log.debug("["+ site.getName() + "] handleOnoffHook " + lineNo + " " + onHook  + " " + offHook);

        Group group = null;

        try {
            group = GroupManager.getInstance().getGroup(lineNo);
            Map<String, String> properties = group.getProperties();
            String state = properties.get("skype.wirelynk.state");

            //properties.put("traderlynk.wirelynk.ringing", "true");
            properties.put("traderlynk.wirelynk.offhook", offHook ? "true" : "false");

            if ("idle".equals(state))
            {
                if (offHook) state = "busy";
            }
            else

            if ("busy".equals(state))
            {
                if (onHook) state = "idle";
            }

            updateSkypePresence(properties, state);

        } catch (Exception e) {
            Log.warn("handleOnoffHook", e);
        }
    }

    public void callStateEvent(Map<String, String> headers)
    {
        Log.debug("["+ site.getName() + "] callStateEvent \n" + headers);

        String callState = headers.get("Channel-Call-State");
        String callDirection = headers.get("Call-Direction");
        String callId = headers.get("Caller-Unique-ID");
        String source = headers.get("Caller-Caller-ID-Number");
        String destination = headers.get("Caller-Destination-Number");
        String otherCallId = headers.get("Other-Leg-Unique-ID");

        if ("RINGING".equals(callState) && "inbound".equals(callDirection))
        {
            ringingEvent(source, destination, callId, otherCallId);
        }
        else

        if ("HANGUP".equals(callState))
        {
            hangupEvent(callId, false);
        }

        else

        if ("ACTIVE".equals(callState))
        {
            activeEvent(callId, otherCallId, callDirection);
        }
    }

    public void conferenceEventSpeaking(String action, String memberId, String confName, Map<String, String> headers)
    {
        String callId = headers.get("Caller-Unique-ID");
        String otherCallId = headers.get("Other-Leg-Unique-ID");

        Log.debug(" conferenceEventSpeaking " + action + " " + callId + " " + confName + " " + otherCallId);

        boolean skypeEnabled = JiveGlobals.getBooleanProperty("skype.enabled", false);

        if (skypeEnabled)
        {
            String key = callId;
            if (callList.containsKey(callId) == false) key = otherCallId;

            if (key != null && callList.containsKey(key))
            {
                TraderLyncUserInterest userInterest = callList.get(key);
                TraderLyncInterest callInterest = userInterest.getInterest();

                String username = callInterest.getInterestLabel();
                String groupname = callInterest.getInterestId();

                Group group = null;
                String note = null;

                if (action.equals("start-talking")) note = username + " has started talking";
                if (action.equals("stop-talking")) note = username + " has stopped talking";

                try {
                    group = GroupManager.getInstance().getGroup(groupname);
                    Map<String, String> properties = group.getProperties();

                    if ("connected".equals(properties.get("skype.wirelynk.state")))
                    {
                        updateSkypeNote(properties, note);
                        //properties.put("skype.wirelynk.state", action);
                    }

                } catch (Exception e) {
                    //Log.error("conferenceEventSpeaking", e);
                }
            }
        }
    }

    public void conferenceEventRecord(String action, String recordingPath, String confName, Map<String, String> headers)
    {
        Log.debug(" conferenceEventRecord " + action + " " + recordingPath + " " + confName + "\n" + headers);

        if (callList.containsKey(confName))
        {
            TraderLyncUserInterest userInterest = callList.get(confName);
            TraderLyncInterest callInterest = userInterest.getInterest();

            for (TraderLyncUserInterest peerInterest : callInterest.getUserInterests().values())
            {
                TraderLyncCall traderLyncCall = peerInterest.getCallByLine(confName);
                if (traderLyncCall != null) traderLyncCall.line = recordingPath;
            }
        }
        else

        if (intercomList.containsKey(confName))
        {
            BridgeParticipant bp = intercomList.get(confName);

            TraderLyncCall call1 = bp.outgoingInterest.getCallByLine(confName);
            if (call1 != null) call1.line = recordingPath;

            TraderLyncCall call2 = bp.incomingInterest.getCallByLine(confName);
            if (call2 != null) call1.line = recordingPath;
        }
    }

    public void conferenceEventJoin(String confName, int confSize, Map<String, String> headers)
    {
        Log.debug("["+ site.getName() + "] conferenceEventJoin "+ confName + " " + confSize + "\n" + headers);

        String callId = headers.get("Caller-Unique-ID");
        String source = headers.get("Caller-Orig-Caller-ID-Number");
        String originator = headers.get("Caller-Caller-ID-Number");
        String destination = headers.get("Caller-Destination-Number");
        String memberId = headers.get("Member-ID");
        String otherCallId = headers.get("Other-Leg-Unique-ID");

        Log.debug("["+ site.getName() + "] conferenceEventJoin "+ callId + " " + otherCallId + " " + source + " " + destination + " " + originator);

        if (otherCallId == null)    otherCallId = callId;
        if (source == null)         source = originator;

        // private wire confjoin event via telephone call

        if (traderLyncInterests.containsKey(confName))
        {
            try {
                Group privateWireGroup = GroupManager.getInstance().getGroup(confName);

                if (privateWireGroup != null)
                {
                    Map<String, String> properties = privateWireGroup.getProperties();
                    updateSkypePresence(properties, "connected");
                }
            } catch (Exception e) {}
        }

        if (instantVoiceEnabled && confName.equals(instantVoiceConference))
        {
            for (String member : instantVoices.values())
            {
                if (member != null)                     // start with intercon (half-duplex)
                {

                }
            }

            if (callList.containsKey(callId))   // private wire (full-duplex)
            {
                String groupname = callList.get(callId).getInterest().getInterestId();

                try {
                    Group nearsideGroup = GroupManager.getInstance().getGroup(groupname);

                    if (nearsideGroup != null)
                    {
                        Map<String, String> properties = nearsideGroup.getProperties();
                        updateSkypePresence(properties, "connected");
                    }
                } catch (Exception e) {}

                instantVoices.put(groupname, memberId);
            }

            instantVoices.put(callId, memberId);        // to overcome duplicate sources

            String userId = getUserFromCallerId(source);

            if (userId != null)
            {
                instantVoices.put(userId, memberId);

                Log.debug("["+ site.getName() + "] instantVoice join "+ userId + " " + memberId);
            }
            return;
        }

        if (bridgeParticipants.containsKey(callId))
        {
            BridgeParticipant bp = bridgeParticipants.get(callId);
            bp.memberId = memberId;
            sendBridgedEvent(bp, "established");

        } else {

            if (intercomList.containsKey(callId))
            {
                BridgeParticipant bp = intercomList.get(callId);

                bp.outgoingInterest.handleCallIntercom(callId, bp.secondPartyPhoneNo, bp.phoneNumber, false);
                publishTraderLyncUserCallEvent(bp.outgoingInterest);

                bp.incomingInterest.handleCallIntercom(callId, bp.phoneNumber, bp.secondPartyPhoneNo, false);
                publishTraderLyncUserCallEvent(bp.incomingInterest);

                if (missedCallList.containsKey(callId)) missedCallList.remove(callId);

            }
            else {
                if (callList.containsKey(callId) == false) callId = otherCallId;
                if (callId != null && callList.containsKey(callId) == false) callId = confName;

                if (callList.containsKey(callId))
                {
                    if (otherCallId != null && callList.containsKey(otherCallId)) callList.put(otherCallId, callList.get(callId));

                    TraderLyncUserInterest userInterest = callList.get(callId);
                    userInterest.memberId = memberId;
                    handleParticipantJoining(userInterest, confSize, callId, confName, true);
                }
            }
        }
    }

    public void handleParticipantJoining(TraderLyncUserInterest userInterest, int confSize, String callId, String confName, boolean publish)
    {
        Log.debug("["+ site.getName() + "] handleParticipantJoining "+ confName + " " + confSize + " " + callId);

        TraderLyncInterest callInterest = userInterest.getInterest();

        if (confSize == 2)
        {
            updateSkypePresenceByName(callInterest.getInterestId(), "connected");       // we change associated skype pw contact

            userInterest.handleCallConnected(confName);
            if (publish) publishTraderLyncUserCallEvent(userInterest);

            String deviceNo = userInterest.getUser().getDeviceNo();

            for (TraderLyncUserInterest peerInterest : callInterest.getUserInterests().values())
            {
                if (deviceNo.equals(peerInterest.getUser().getDeviceNo()) == false)
                {
                    peerInterest.handleCallBusy(confName);
                    if (publish) publishTraderLyncUserCallEvent(peerInterest);
                }
            }

        }

        else if (confSize > 2) {

            updateSkypePresenceByName(callInterest.getInterestId(), "conferenced");

            userInterest.handleCallConferenced(confName);
            if (publish) publishTraderLyncUserCallEvent(userInterest);

            String deviceNo = userInterest.getUser().getDeviceNo();

            for (TraderLyncUserInterest peerInterest : callInterest.getUserInterests().values())
            {
                if (deviceNo.equals(peerInterest.getUser().getDeviceNo()) == false)
                {
                    TraderLyncCall traderLyncCall = peerInterest.getCallByLine(confName);

                    if ("CallEstablished".equals(traderLyncCall.getState()) || "CallBusy".equals(traderLyncCall.getState()))
                    {
                        peerInterest.handleCallConferenced(confName);
                        if (publish) publishTraderLyncUserCallEvent(peerInterest);

                        testForNoSpeak(confName, userInterest, peerInterest);
                    }
                }
            }
        }
    }

    private void testForNoSpeak(String confName, TraderLyncUserInterest userInterest, TraderLyncUserInterest peerInterest)
    {
        boolean nospeak = false;

        String username = userInterest.getUser().getUserNo();
        String peer = peerInterest.getUser().getUserNo();

        try {
            Roster roster = rosterManager.getRoster(username);
            JID peerJid = new JID(peer + "@" + getDomain());

            RosterItem item = roster.getRosterItem(peerJid);

            // audio group requirements to prevent acoustic feedback for peers within earshot or each other
            // if user and peer have a roster relationship with subscription type "from"
            // disable audio from user to peer

            if (item != null && item.getSubStatus() == RosterItem.SUB_FROM && userInterest.memberId != null && peerInterest.memberId != null)
            {

            }

        }
        catch (UserNotFoundException e) {
            // no relationshp, assume user can speak
        }
    }

    private void terminateIntercom(String confName, String callId)
    {
        BridgeParticipant bp = intercomList.remove(callId);

        TraderLyncCall call1 = bp.outgoingInterest.getCallByLine(confName);
        call1.direction = "Outgoing";
        bp.outgoingInterest.logCall(call1, getDomain(), 0);
        bp.outgoingInterest.handleConnectionCleared(confName);
        publishTraderLyncUserCallEvent(bp.outgoingInterest);
        bp.outgoingInterest.removeCallById(callId);

        TraderLyncCall call2 = bp.incomingInterest.getCallByLine(confName);
        call2.direction = "Incoming";
        bp.incomingInterest.logCall(call2, getDomain(), 0);
        bp.incomingInterest.handleConnectionCleared(confName);
        publishTraderLyncUserCallEvent(bp.incomingInterest);
        bp.incomingInterest.removeCallById(callId);

        callList.remove(callId);
    }

    public void conferenceEventLeave(String confName, int confSize, Map<String, String> headers)
    {
        Log.debug("["+ site.getName() + "] conferenceEventLeave "+ confName + " " + confSize);

        // we are not interested in 1 single participant because a bridge conference has a min of 2
        // we are interested in 3 callids in callList

        // 1. callid that matches conference brige id on outgoing calls
        // 2. callid that is given to incoming calls
        // 3. callids generated for joincall actions

        // when call originator or destination leaves, conference bridge is killed, all participnats removed

        String callId = headers.get("Caller-Unique-ID");
        String source = headers.get("Caller-Caller-ID-Number");
        String originator = headers.get("Caller-Caller-ID-Number");
        String destination = headers.get("Caller-Destination-Number");
        String memberId = headers.get("Member-ID");
        String otherCallId = headers.get("Other-Leg-Unique-ID");

        if (otherCallId == null)    otherCallId = callId;
        if (source == null)         source = originator;

        // private wire confleave event via telephone call

        if (traderLyncInterests.containsKey(confName))
        {
            try {
                Group privateWireGroup = GroupManager.getInstance().getGroup(confName);

                if (privateWireGroup != null)
                {
                    Map<String, String> properties = privateWireGroup.getProperties();
                    updateSkypePresence(properties, confSize < 2 ? "idle" : "connected");
                }
            } catch (Exception e) {}
        }

        if (instantVoiceEnabled && confName.equals(instantVoiceConference))
        {
            instantVoices.remove(callId);
            instantVoices.remove(source);

            String userId = getUserFromCallerId(source);

            if (userId != null)
            {
                instantVoices.remove(userId);
                Log.debug("["+ site.getName() + "] instantVoice leave "+ userId + " " + memberId);
            }
            return;
        }

        if (bridgeParticipants.containsKey(callId))
        {
            BridgeParticipant bp = bridgeParticipants.remove(callId);
            sendBridgedEvent(bp, "ended");

        } else {

            if (intercomList.containsKey(callId))
            {
                terminateIntercom(confName, callId);
            }
            else

            if (confSize != 1 && heldCallList.containsKey(otherCallId) == false && heldCallList.containsKey(callId) == false)
            {
                Log.debug("["+ site.getName() + "] conferenceEventLeave "+ confName + " " + confSize + "\n" + headers);

                if (callId != null)
                {
                    if (callList.containsKey(callId) == false) callId = otherCallId;
                    if (callList.containsKey(callId) == false) callId = confName;

                    if (callList.containsKey(callId) && thirdPartyCallList.containsKey(callId) == false)
                    {
                        TraderLyncUserInterest userInterest = callList.get(callId);
                        handleParticipantLeaving(userInterest, confSize, callId, confName, true);

                    } else {
                        if (thirdPartyCallList.containsKey(callId)) thirdPartyCallList.remove(callId);
                    }
                }

                if (otherCallId != null && otherCallId.equals(callId) == false && transferCallList.containsKey(confName) == false)
                {

                }

            } else {

                // transferCallList has done it's job, remove callid

                if (confSize == 0 && transferCallList.containsKey(confName)) transferCallList.remove(confName);
            }
        }
    }

    public void handleParticipantLeaving(TraderLyncUserInterest userInterest, int confSize, String callId, String confName, boolean publish)
    {
        Log.debug("["+ site.getName() + "] handleParticipantLeaving "+ confName + " " + confSize + " " + callId);

        TraderLyncInterest callInterest = userInterest.getInterest();

        if (confSize == 0)
        {
            updateSkypePresenceByName(callInterest.getInterestId(), "idle");

            TraderLyncCall traderLyncCall = userInterest.getCallByLine(confName);

            if (traderLyncCall != null) userInterest.logCall(traderLyncCall, getDomain(), 0);

            for (TraderLyncUserInterest peerInterest : callInterest.getUserInterests().values())
            {
                peerInterest.handleConnectionCleared(confName);
                if (publish) publishTraderLyncUserCallEvent(peerInterest);

                peerInterest.removeCallById(confName);
                peerInterest.removeCallById(callId);
            }

            callList.remove(callId);
            callList.remove(confName);
        }

        else if (confSize > 1) {

            userInterest.handleCallBusy(confName);
            if (publish) publishTraderLyncUserCallEvent(userInterest);

            if (confSize == 2)
            {
                updateSkypePresenceByName(callInterest.getInterestId(), "connected");

                for (TraderLyncUserInterest peerInterest : callInterest.getUserInterests().values())
                {
                    TraderLyncCall traderLyncCall = peerInterest.getCallByLine(confName);

                    if(traderLyncCall != null && "CallConferenced".equals(traderLyncCall.getState()))
                    {
                        peerInterest.handleCallConnected(confName);
                    }

                    if (publish) publishTraderLyncUserCallEvent(peerInterest);
                }

            }
        }
    }


    public void handleRingDown(String bridgeId, String lineId)
    {
        Log.debug("["+ site.getName() + "] handleRingDown " + bridgeId + " " + lineId);

        // ringdown event happens on near side

        Group nearGroup = getGroupFromGW(bridgeId, lineId);

        if (nearGroup != null)
        {
            final Map<String, String> properties = nearGroup.getProperties();

            String groupname = nearGroup.getName();

            if (instantVoiceEnabled && traderLyncInterests.containsKey(groupname))
            {
                TraderLyncInterest interest = traderLyncInterests.get(groupname);

                for (TraderLyncUserInterest nearInterest : interest.getUserInterests().values())
                {
                    if (nearInterest.ivCallId != null)
                    {
                        nearInterest.handleCallAlerted(nearInterest.ivCallId, true);
                        publishTraderLyncUserCallEvent(nearInterest);
                    }
                }

                updateSkypePresence(properties, "ringing");

                try {

                    final String timeout = JiveGlobals.getProperty("wirelynk.ringing.timeout", "60000");
                    final String newState = JiveGlobals.getProperty("wirelynk.ringing.timeout.state", "connected");
                    final String target = groupname;
                    final TraderLyncInterest resetInterest = interest;

                    timer.schedule(new TimerTask()
                    {
                        @Override public void run()
                        {
                            try {
                                Log.debug("["+ site.getName() + "] ringingEvent reset " + target + " to " + newState);
                                String state = properties.get("skype.wirelynk.state");

                                if (state.equals("ringing"))
                                {
                                    updateSkypePresence(properties, newState);
                                }

                                for (TraderLyncUserInterest nearInterest : resetInterest.getUserInterests().values())
                                {
                                    if (nearInterest.ivCallId != null)
                                    {
                                        nearInterest.handleCallAlerted(nearInterest.ivCallId, false);
                                        publishTraderLyncUserCallEvent(nearInterest);
                                    }
                                }

                            } catch (Exception e) {
                                Log.warn("exception on ringing event timeout", e);
                            }
                        }
                    }, Integer.parseInt(timeout));

                } catch (Exception e) {
                    Log.warn("exception on ringing event timeout", e);
                }

            } else {

                String farsideGroup = properties.get("traderlynk.wirelynk");
                String callId = groupname + "-" + System.currentTimeMillis();

                ringingEvent(farsideGroup, groupname, callId, callId);
            }
        }
    }

    public void handleLineState(String bridgeId, String lineId, String state)
    {
        Log.debug("["+ site.getName() + "] handleLineState " + bridgeId + " " + lineId + " " + state);

        Group nearGroup = getGroupFromGW(bridgeId, lineId);

        if (nearGroup != null)
        {
            Map<String, String> properties = nearGroup.getProperties();
            updateSkypePresence(properties, "up".equals(state) ? "connected" : "idle");
        }
    }

    public void handleGWConfJoin(String bridgeId, String lineId)
    {
        updateSkypePresenceFromState(bridgeId, lineId, "connected");
    }

    public void handleGWConfLeave(String bridgeId, String lineId)
    {
        updateSkypePresenceFromState(bridgeId, lineId, "idle");
    }

    public void updateSkypePresenceFromState(String bridgeId, String lineId, String state)
    {
        Log.debug("["+ site.getName() + "] updateSkypePresenceFromState " + bridgeId  + " " + lineId + " " + state);

        Group group = getGroupFromGW(bridgeId, lineId);

        if (group != null)
        {
            Map<String, String> properties = group.getProperties();
            updateSkypePresence(properties, state);
        }
    }

    public void updateSkypePresence(Map<String, String> properties, String state)
    {
        Log.debug("["+ site.getName() + "] updateSkypePresence " + properties  + " " + state);

        if (properties.containsKey("skype.wirelynk"))
        {
            String key = properties.get("skype.wirelynk");
        }

        properties.put("skype.wirelynk.state", state);
    }

    public void updateSkypeNote(Map<String, String> properties, String note)
    {
        Log.debug("["+ site.getName() + "] updateSkypeNote " + properties  + " " + note);

        if (properties.containsKey("skype.wirelynk"))
        {
            String key = properties.get("skype.wirelynk");
        }
    }

    public Group getGroupFromGW(String bridgeId, String lineId)
    {
        Log.debug("["+ site.getName() + "] getGroupFromGW " + bridgeId  + " " + lineId);

        Group foundGroup = null;
        Collection<Group> groups = GroupManager.getInstance().getSharedGroups();

        for (Group group : groups)
        {
            String groupname = group.getName();

            if (isNumeric(groupname))
            {
                Map<String, String> properties = group.getProperties();

                if (properties.containsKey("traderlynk.wirelynk") && properties.containsKey("traderlynk.wirelynk.gateway") && properties.containsKey("traderlynk.wirelynk.lineid"))
                {
                    String gateway = properties.get("traderlynk.wirelynk.gateway");
                    String line = properties.get("traderlynk.wirelynk.lineid");

                    if (line.equals(lineId) && gateway.equals(bridgeId))
                    {
                        foundGroup = group;
                        break;
                    }
                }
            }
        }

        return foundGroup;
    }

    public void activeEvent(String callId, String otherCallId, String callDirection)
    {
        Log.debug("["+ site.getName() + "] activeEvent " + callId + " " + otherCallId + " " + callDirection);

        if (callList.containsKey(callId))
        {
            Log.debug("["+ site.getName() + "] activeEvent " + callId  + " " + otherCallId);

            TraderLyncUserInterest userInterest = callList.get(callId);
            TraderLyncInterest callInterest = userInterest.getInterest();

            for (TraderLyncUserInterest interest : callInterest.getUserInterests().values())
            {
                TraderLyncCall traderLyncCall = interest.getCallById(callId);

                if (traderLyncCall != null)
                {
                    if ("inbound".equals(callDirection))
                        traderLyncCall.holdCallId = callId;
                    else
                        traderLyncCall.holdCallId = otherCallId;
                }
            }
        }
    }

    private String getUserFromCallerId(String from)
    {
        Log.debug("["+ site.getName() + "] getUserFromCallerId " + from);

        if (from == null) return null;

        String userId = null;

        TraderLyncUserInterest phoneInterest = getDefaultInterestByDevice(from);

        if (phoneInterest != null)      // only if it is a default interest, then it is the user calling in
        {
            userId = phoneInterest.getUser().getUserNo();
        }

        return userId;
    }

    private TraderLyncUserInterest getPeerInterest(String to, String from)
    {
        TraderLyncUserInterest target = null;

        TraderLyncUserInterest toUserInterest = defaultInterests.get(to);
        TraderLyncUserInterest fromUserInterest = defaultInterests.get(from);

        if (toUserInterest != null && fromUserInterest != null)
        {
            target = toUserInterest.getInterest().getUserInterests().get(fromUserInterest.getUser().getUserNo());
        }

        return target;
    }


    public void ringingEvent(String from, String to, String callId, String otherCallId)
    {
        Log.debug("["+ site.getName() + "] ringingEvent " + from + " " + to  + " " + callId + " " + otherCallId);

        // if 'from' is an identified endpoint, user is trying to join an existing call or originate PW call
        // use uuid_transfer to add user to call

        if (otherCallId == null) otherCallId = callId;

        if (traderLyncInterests.containsKey(to))    // first check for interest
        {
            Log.debug("["+ site.getName() + "] ringingEvent to interest " + to);

            TraderLyncInterest callInterest = traderLyncInterests.get(to);

            String label = from;

            if (traderLyncInterests.containsKey(from))
            {
                label = traderLyncInterests.get(from).getInterestLabel();
            }

            if (reverseSpeeedDials.containsKey(from))
            {
                label = reverseSpeeedDials.get(from).getString("name");
            }

            // for instant voice, chnage state to alerting
            // otherwise, use call delivered (ringing)

            missedCallList.put(callId, callInterest);

            for (TraderLyncUserInterest userInterest : callInterest.getUserInterests().values())
            {
                userInterest.handleCallIncoming(otherCallId, from, to, label);
                callList.put(callId, userInterest);
                publishTraderLyncUserCallEvent(userInterest);
            }
        }
    }

    public Group updateSkypePresenceByName(String groupname, String state)
    {
        Log.debug("["+ site.getName() + "] updateSkypePresence " + groupname  + " " + state);
        Group group = null;

        try {
            group = GroupManager.getInstance().getGroup(groupname);
            Map<String, String> properties = group.getProperties();

            updateSkypePresence(properties, state);

        } catch (Exception e) {     // no need to trap error

        }

        return group;
    }


    public void hangupEvent(String callId, boolean missed)
    {
        if (callId == null) return;
        if (!missed) missedCallList.remove(callId);

        Log.debug("["+ site.getName() + "] hangupEvent " + callId + " " + missed);

        if (missedCallList.containsKey(callId))     //missed call
        {
            TraderLyncInterest callInterest = missedCallList.get(callId);
            TraderLyncUserInterest logInterest = null;

            for (TraderLyncUserInterest userInterest : callInterest.getUserInterests().values())
            {
                logInterest = userInterest;
                userInterest.handleCallAbandoned(callId);
                publishTraderLyncUserCallEvent(userInterest);
            }

            TraderLyncCall traderLyncCall = logInterest.getCallById(callId);
            if (traderLyncCall != null) logInterest.logCall(traderLyncCall, getDomain(), 0);
        }
        else

        if (callList.containsKey(callId))
        {
            TraderLyncUserInterest userInterest = callList.get(callId);             // we remove later on on Conf leave or ClearCall
            TraderLyncInterest callInterest = userInterest.getInterest();           // unless instant voice. we remove now

            for (TraderLyncUserInterest farInterest : callInterest.getUserInterests().values())
            {
                farInterest.handleConnectionCleared(callId);
                publishTraderLyncUserCallEvent(farInterest);
            }

            TraderLyncCall traderLyncCall = userInterest.getCallById(callId);
            if (traderLyncCall != null) userInterest.logCall(traderLyncCall, getDomain(), 0);
            //userInterest.removeCallById(callId);
        }
    }

    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------


    private String getSkypeCallback(TraderLyncUserInterest traderLyncUserInterest)
    {
        TraderLyncUser traderLyncUser = traderLyncUserInterest.getUser();
        TraderLyncInterest traderLyncInterest = traderLyncUserInterest.getInterest();
        String interestValue = traderLyncInterest.getInterestId();
        String deviceNo = traderLyncUserInterest.getUser().getDeviceNo();
        boolean skype4bUser = false;
        String skypeCallback = null;
        String prefix = JiveGlobals.getProperty("skype.device.prefix", "");
        String suffix = JiveGlobals.getProperty("skype.device.suffix", "");

        // only default interest can be used for makecall and request actions

        if (interestValue.equals(traderLyncUserInterest.getUser().getUserId() + "-skype4b"))
        {
            if (traderLyncUser.email != null)
            {
                String key = traderLyncUser.email;
                return null;
            } else {
                return null;
            }
        }

        if (skype4bUser)
        {
            skypeCallback = prefix + deviceNo + suffix;
        }

        return skypeCallback;
    }

    public String processOpenlinkRequest(TraderLyncUserInterest traderLyncUserInterest, String action, String username, String dialDigits, String callId, String handset, String joinCallId)
    {
        String error = null;

        String deviceNo = traderLyncUserInterest.getUser().getDeviceNo();

        TraderLyncUser traderLyncUser = traderLyncUserInterest.getUser();
        TraderLyncInterest traderLyncInterest = traderLyncUserInterest.getInterest();

        if (deviceNo != null)
        {
            String interestValue = traderLyncInterest.getInterestId();
            String skypeCallback = getSkypeCallback(traderLyncUserInterest);

            Log.debug("["+ site.getName() + "] processOpenlinkRequest " + action + " " + interestValue);

            if (action.equals("MakeCall"))
            {
                // originate a call from SIP handset of user who originates call to the destination via a conference bridge (callid)

                String cliNumber = interestValue;
                String cliName = traderLyncInterest.getInterestLabel();

                String callbackName = JiveGlobals.getProperty("freeswitch.callback.name", cliName);
                String callbackNumber = JiveGlobals.getProperty("freeswitch.callback.number", cliNumber);

                String destination = makeDestination(dialDigits, null);
                destination = "[origination_caller_id_name='" + cliName + "',origination_caller_id_number='" + cliNumber + "']" + destination;

                callList.put(callId, traderLyncUserInterest);
            }
            else

            if (action.equals("AnswerCall"))
            {
                // transfer the call directly to SIP handset of user who accepts via a conference bridge (callid)

                callList.put(callId, traderLyncUserInterest);
                missedCallList.remove(callId);

                String cliNumber = traderLyncUserInterest.getInterest().getInterestId();
            }

            else

            if (action.equals("RetrieveCall"))
            {
                // freeswitch command uuid_transfer to user device

                TraderLyncCall traderLyncCall = traderLyncUserInterest.getCallById(callId);

                if (traderLyncCall != null)
                {
                    heldCallList.remove(traderLyncCall.holdCallId);

                    callList.put(callId, traderLyncUserInterest);                   // lost, adding it again
                    callList.put(traderLyncCall.holdCallId, traderLyncUserInterest);

                    if (error == null)
                    {
                        TraderLyncInterest callInterest = traderLyncUserInterest.getInterest();

                        for (TraderLyncUserInterest interest : callInterest.getUserInterests().values())
                        {
                            TraderLyncCall call = interest.getCallById(callId);
                            call.uuid = traderLyncCall.holdCallId;
                        }
                    }

                } else error = "HoldCall Failed, call Id invalid";
            }

            else

            if (action.equals("HoldCall"))
            {
                // freeswitch command uuid_park

                TraderLyncCall traderLyncCall = traderLyncUserInterest.getCallById(callId);

                if (traderLyncCall != null)
                {
                    heldCallList.put(traderLyncCall.holdCallId, traderLyncUserInterest);

                } else error = "HoldCall Failed, call Id invalid";
            }
            else

            if (action.equals("TransferCall"))
            {
                // do attended call transfer

                TraderLyncCall traderLyncCall = traderLyncUserInterest.getCallById(callId);

                if (traderLyncCall != null)
                {
                    transferCallList.put(callId, traderLyncUserInterest);

                } else error = "TransferCall Failed, call Id invalid";
            }
            else

            if (action.equals("SingleStepTransfer"))
            {
                // transfer the call directly to new destination

                TraderLyncCall traderLyncCall = traderLyncUserInterest.getCallById(callId);

                if (traderLyncCall != null)
                {
                    transferCallList.put(callId, traderLyncUserInterest);

                } else error = "SingleStepTransfer Failed, call Id invalid";
            }
            else

            if (action.equals("IntercomTransfer"))
            {
                // transfer the call directly to new destination

                TraderLyncCall traderLyncCall = traderLyncUserInterest.getCallById(callId);

                if (traderLyncCall != null)
                {
                    transferCallList.put(callId, traderLyncUserInterest);

                } else error = "IntercomTransfer Failed, call Id invalid";
            }

            else

            if (action.equals("SendDigits"))
            {
                // send DTMF tones

                TraderLyncCall traderLyncCall = traderLyncUserInterest.getCallById(callId);

                if (traderLyncCall != null)
                {

                } else error = "SendDigits Failed, call Id invalid";
            }

            else

            if (action.equals("JoinCall"))
            {
                // originate a call from SIP handset of user who joins call to the call conference bridge (callid)

                String cliNumber = traderLyncUserInterest.getInterest().getInterestId();
                String cliName = traderLyncUserInterest.getInterest().getInterestLabel();
                String callbackName = JiveGlobals.getProperty("freeswitch.callback.name", cliName);
                String callbackNumber = JiveGlobals.getProperty("freeswitch.callback.number", cliNumber);

                callList.put(joinCallId, traderLyncUserInterest);
            }
            else

            if (action.equals("RemoveThirdParty"))
            {
                if (skypeCallback != null)
                {


                } else {

                    if (joinCallId != null)
                    {

                    }
                }
            }
            else

            if (action.equals("AddThirdParty"))
            {
                // originate a call from call conference bridge to an external party (conference external party to call)

                String cliNumber = traderLyncUserInterest.getInterest().getInterestId();
                String cliName = traderLyncUserInterest.getInterest().getInterestLabel();
                String callbackName = JiveGlobals.getProperty("freeswitch.callback.name", cliName);
                String callbackNumber = JiveGlobals.getProperty("freeswitch.callback.number", cliNumber);

                //String command = "originate {presence_id=" + cliNumber + "@" + sipDomain + ",origination_caller_id_name='" + callbackName + "',origination_caller_id_number='" + callbackNumber + "',sip_from_user='" + cliNumber + "',origination_uuid=" + joinCallId + "}sofia/" + sipDomain + "/" + dialDigits + " &conference(" + callId + ")";

                thirdPartyCallList.put(joinCallId, callId);
                callList.put(joinCallId, traderLyncUserInterest);
            }

            else

            if (action.equals("ClearConnection"))
            {
                BridgeParticipant bp = intercomList.get(callId);

                if (bp != null && bp.fromMember != null && bp.toMember != null) // instant voice
                {
                    terminateIntercom(callId, callId);

                } else {

                    if (instantVoiceEnabled && instantVoices.containsKey(traderLyncInterest.getInterestId()) && instantVoices.containsKey(traderLyncUser.getUserNo()))
                    {
                        leaveInstantVoiceCall(traderLyncUserInterest, traderLyncUser, traderLyncInterest, callId);

                    } else {

                        TraderLyncCall traderLyncCall = traderLyncUserInterest.getCallById(callId);

                    }
                }
            }

            else

            if (action.equals("ClearCall"))
            {
                BridgeParticipant bp = intercomList.get(callId);

                if (bp != null && bp.fromMember != null && bp.toMember != null) // instant voice
                {
                    terminateIntercom(callId, callId);

                } else {

                    if (instantVoiceEnabled && instantVoices.containsKey(traderLyncInterest.getInterestId()) && instantVoices.containsKey(traderLyncUser.getUserNo()))
                    {
                        leaveInstantVoiceCall(traderLyncUserInterest, traderLyncUser, traderLyncInterest, callId);

                    } else {
                        TraderLyncInterest callInterest = traderLyncUserInterest.getInterest();

                        for (TraderLyncUserInterest interest : callInterest.getUserInterests().values())
                        {
                            TraderLyncCall traderLyncCall = interest.getCallById(callId);

                        }
                    }
                }
            }

        } else error = "user device is undefined for " + username;

        return error;
    }

    private void addCallStatusExtension(Element newCommand)
    {
        if (newCommand != null)
        {
            Element iodata = newCommand.addElement("iodata", "urn:xmpp:tmp:io-data");
            iodata.addAttribute("type","output");
            Element childElement = iodata.addElement("out").addElement("callstatus", "http://xmpp.org/protocol/openlink:01:00:00#call-status").addAttribute("busy","true");
        }
    }


    public String makeCallDefault(Element newCommand, JID jid, String handset, String privacy, String autoHold, String dialDigits)
    {
        return makeCallDefault(newCommand, jid, handset, privacy, autoHold, dialDigits, null);
    }

    public String makeCallDefault(Element newCommand, JID jid, String handset, String privacy, String autoHold, String dialDigits, String callId)
    {
        Log.debug( "["+ site.getName() + "] makeCallDefault "+ jid + " " + handset + " " + dialDigits + " " + privacy);

        String errorMessage = "No default profile found";

        try {

            if (dialDigits != null && !"".equals(dialDigits))
            {
                dialDigits = makeDialableNumber(dialDigits);

                if (dialDigits == null || "".equals(dialDigits))
                {
                    errorMessage = "Destination is not a dialable number";
                    return errorMessage;
                }
            }

            boolean foundDefaultProfile = false;

            String userName = jid.getNode();
            Iterator<TraderLyncUser> it = traderLyncUserTable.values().iterator();

            while( it.hasNext() )
            {
                TraderLyncUser traderLyncUser = (TraderLyncUser)it.next();

                if (userName.equals(traderLyncUser.getUserId()) && "true".equals(traderLyncUser.getDefault()))
                {
                    foundDefaultProfile = true;

                    handset = handset == null ? traderLyncUser.getHandsetNo() : handset;
                    privacy = privacy == null ? traderLyncUser.getLastPrivacy() : privacy;
                    autoHold = autoHold == null ? (traderLyncUser.autoHold() ? "true" : "false")  : autoHold;

                    if (traderLyncUser.getDefaultInterest() != null)    // default profile calls use default directory interest
                    {
                        traderLyncUser.setWaitingInterest(null);
                        errorMessage = makeOutgoingCall(traderLyncUser.getDefaultInterest().getUserInterests().get(traderLyncUser.getUserNo()), dialDigits, handset, callId);

                    } else errorMessage = "no default interest found";

                    break;
                }
            }

            if (foundDefaultProfile == false)
                errorMessage = "no default profile found";
        }
        catch(Exception e) {
            Log.error("makeCallDefault ", e);
            errorMessage = "Internal error - " + e.toString();
        }

        if (errorMessage == null) addCallStatusExtension(newCommand);
        return errorMessage;
    }


    public String makeCall(Element newCommand, String userInterest, String handset, String privacy, String autoHold, String dialDigits)
    {
        return makeCall(newCommand, userInterest, handset, privacy, autoHold, dialDigits, null);
    }


    public String makeCall(Element newCommand, String userInterest, String handset, String privacy, String autoHold, String dialDigits, String callId)
    {
        Log.debug( "["+ site.getName() + "] makeCall "+ userInterest + " " + dialDigits + " " + callId);

        String errorMessage = "Interest not found";

        try {

            if (openlinkInterests.containsKey(userInterest))
            {
                TraderLyncUserInterest traderLyncUserInterest = openlinkInterests.get(userInterest);
                TraderLyncUser traderLyncUser = traderLyncUserInterest.getUser();
                TraderLyncInterest traderLyncInterest = traderLyncUserInterest.getInterest();

                handset = handset == null ? traderLyncUser.getHandsetNo() : handset;
                privacy = privacy == null ? traderLyncUser.getLastPrivacy() : privacy;

                String groupname = traderLyncUserInterest.getInterest().getInterestId();

                if (traderLyncInterest.isSharedLine)
                {
                    try {
                        Group nearsideGroup = GroupManager.getInstance().getGroup(groupname);
                        Map<String, String> properties = nearsideGroup.getProperties();

                        if (traderLyncInterest.useGateway == false)             // not gateway, use virtual PW (internal peering DDIs)
                        {
                            if (dialDigits != null && !"".equals(dialDigits))
                            {
                                dialDigits = makeDialableNumber(dialDigits);

                                if (dialDigits == null || "".equals(dialDigits))
                                {
                                    errorMessage = "Destination is not a dialable number";
                                    return errorMessage;
                                }
                            }

                            if (properties.containsKey("traderlynk.wirelynk")) // virtual PW (DDI peering)
                            {
                                String farsideGroup = properties.get("traderlynk.wirelynk");
                                String interestName = farsideGroup; // + "-" + groupname;

                                Log.debug( "["+ site.getName() + "] makeCall virtual private wire " + interestName);

                                if (callId == null) callId = groupname + "-" + System.currentTimeMillis();
                                errorMessage = makeOutgoingCall(traderLyncUserInterest, farsideGroup, handset, callId);


                            } else {
                                Log.debug( "["+ site.getName() + "] makeCall shared line " + groupname);
                                errorMessage = makeOutgoingCall(traderLyncUserInterest, dialDigits, handset, callId); // personal DDI
                            }
                        }
                    } catch (Exception e) {
                        errorMessage = "Error getting group " + groupname + " - " + e.toString();
                        Log.error("makeCall", e);
                    }
                }
                else {
                    Log.debug( "["+ site.getName() + "] makeCall personal line " + groupname);
                    errorMessage = makeOutgoingCall(traderLyncUserInterest, dialDigits, handset, callId); // personal DDI
                }
            }
        }
        catch(Exception e) {
            Log.error("makeCall ", e);
            errorMessage = "Internal error - " + e.toString();
        }

        if (errorMessage == null) addCallStatusExtension(newCommand);
        return errorMessage;
    }


    private String makeOutgoingCall(TraderLyncUserInterest traderLyncUserInterest, String dialDigits, String handset, String callId)
    {
        Log.debug( "["+ site.getName() + "] makeOutgoingCall "+ traderLyncUserInterest.getInterest().getInterestId() + " " + dialDigits + " " + callId);

        String username = traderLyncUserInterest.getUser().getUserId();
        String errorMessage = null;
        String skypeCallback = getSkypeCallback(traderLyncUserInterest);

        try {
            if (skypeCallback != null)
            {
                processOpenlinkRequest(traderLyncUserInterest, "MakeCall", username, dialDigits, null, handset, null);

            } else {

                if (callId == null) callId = username + "-" + System.currentTimeMillis();

                errorMessage = processOpenlinkRequest(traderLyncUserInterest, "MakeCall", username, dialDigits, callId, handset, null);

                if (errorMessage == null)
                {
                    outgoingCallNotification(username, callId, dialDigits, traderLyncUserInterest, false);
                }
            }
        }

        catch(Exception e) {
            Log.error("makeOutgoingCall ", e);
            errorMessage = "Internal error - " + e.toString();
        }

        return errorMessage;
    }


    public String intercomCall(Element newCommand, String profileID, JID to, String intercomId)
    {
        Log.debug( "["+ site.getName() + "] intercomCall "+ profileID + " -> " + to + " => " + intercomId);
        String errorMessage = null;

        try {
            TraderLyncUser fromUser = getOpenlinkProfile(profileID);

            if (intercomId == null)
            {
                if (to != null)
                {
                    TraderLyncUser toUser = getTraderLyncUser(to);

                    if (isUserOnline(toUser))
                    {
                        String toDeviceNo = toUser.getDeviceNo();
                        errorMessage = intercom2Way(fromUser, toUser, toDeviceNo, intercomId, null);

                    } else errorMessage = "Intercom destination not online";

                } else errorMessage = "Intercom destination or feature id must be provided";

            } else {

                int pos = intercomId.indexOf("_");

                if (pos > - 1)
                {
                    String featureType = intercomId.substring(0, pos);
                    String toDeviceNo = intercomId.substring(pos + 1);

                    if ("icom".equals(featureType))
                    {
                        errorMessage = intercom2Way(fromUser, null, toDeviceNo, intercomId, null);

                    } else {

                        Group intercomGroup = GroupManager.getInstance().getGroup(toDeviceNo);

                        if (intercomGroup != null)
                        {
                            String confId = intercomId + "-" + System.currentTimeMillis();

                            for (JID memberJID : intercomGroup.getMembers()) intercomPeer(memberJID, profileID, fromUser, intercomId, confId);
                            for (JID memberJID : intercomGroup.getAdmins()) intercomPeer(memberJID, profileID, fromUser, intercomId, confId);

                        } else errorMessage = "group " + toDeviceNo + " not found";
                    }

                } else errorMessage = "invalid intercom feture id";
            }
        }
        catch(Exception e) {
            Log.error("["+ site.getName() + "] intercomCall ", e);
            errorMessage = "Internal error - " + e.toString();
        }

        if (errorMessage == null) addCallStatusExtension(newCommand);
        return errorMessage;
    }

    private String intercomPeer(JID memberJID, String profileID, TraderLyncUser fromUser, String intercomId, String confId)
    {
        Log.debug( "["+ site.getName() + "] intercomPeer " + memberJID + " " + profileID  + " " + fromUser  + " " + intercomId  + " " + confId);

        String errorMessage = null;
        String peer = memberJID.getNode();

        if (!peer.equals(profileID))
        {
            TraderLyncUser peerUser = getOpenlinkProfile(peer);
            String toDeviceNo = peerUser.getDeviceNo();
            errorMessage = intercom2Way(fromUser, peerUser, toDeviceNo, intercomId, confId);
        }
        return errorMessage;
    }


    private String intercom2Way(TraderLyncUser fromUser, TraderLyncUser toUser, String toDeviceNo, String intercomId, String confId)
    {
        Log.debug( "["+ site.getName() + "] intercom2Way " + fromUser.getUserNo() + " " + toUser + " " + toDeviceNo  + " " + intercomId  + " " + confId);

        String errorMessage = null;
        String username = fromUser.getUserNo();
        TraderLyncUserInterest traderLyncUserInterest = fromUser.getDefaultInterest().getUserInterests().get(username);

        // first we check if both users are instant voice enabled and try that first

        if (instantVoiceEnabled && instantVoices.containsKey(username))
        {
            String target = null;

            if (toUser == null)
            {
                target = getUserFromCallerId(toDeviceNo);
            }
            else target = toUser.getUserNo();

            Log.debug( "["+ site.getName() + "] intercom2Way instant voice from " + username + " " + toDeviceNo  + " " + target);

            if (target != null && instantVoices.containsKey(target))
            {
                String fromMember = instantVoices.get(username);
                String toMember = instantVoices.get(target);

                Log.debug( "["+ site.getName() + "] intercom2Way instant voice to " + fromMember + " " + toMember);
            }
        }

        Log.debug( "["+ site.getName() + "] intercom2Way telephone from " + username + " " + toDeviceNo);

        //  both parties are not instant voice enabled, fall back on the plain old telephone  system (POTS)

        if (isUserOnline(fromUser))
        {
            String fromDeviceNo = fromUser.getDeviceNo();

            BridgeParticipant bp = new BridgeParticipant();
            bp.outgoingInterest = traderLyncUserInterest;
            bp.incomingInterest = getDefaultInterestByDevice(toDeviceNo);
            bp.phoneNumber = fromDeviceNo;
            bp.secondPartyPhoneNo = toDeviceNo;

            if (bp.outgoingInterest != null && bp.incomingInterest != null)
            {
                String cliNumber = traderLyncUserInterest.getInterest().getInterestId();
                String cliName = traderLyncUserInterest.getInterest().getInterestLabel();

                String callbackName = JiveGlobals.getProperty("freeswitch.callback.name", cliName);
                String callbackNumber = JiveGlobals.getProperty("freeswitch.callback.number", cliNumber);

                String callId = username + "-" + System.currentTimeMillis();
                if (confId == null) confId = callId;

                String destination = "user/" + fromDeviceNo;

                destination = "[origination_caller_id_name='" + cliName + "',origination_caller_id_number='" + cliNumber + "']" + destination;


                if (errorMessage == null)
                {
                    intercomList.put(callId, bp);
                }

            } else errorMessage = "Intercom profiles not found";

        } else errorMessage = "Intercom not online";

        return errorMessage;
    }

    private boolean isValidAction(TraderLyncCall traderLyncCall, String validAction)
    {
        boolean valid = false;

        Iterator it4 = traderLyncCall.getValidActions().iterator();

        while( it4.hasNext() )
        {
            String action = (String)it4.next();

            if (action.equals(validAction))
            {
                valid = true;
                break;
            }
        }

        return valid;
    }

    private void leaveInstantVoiceCall(TraderLyncUserInterest traderLyncUserInterest, TraderLyncUser traderLyncUser, TraderLyncInterest traderLyncInterest, String callId)
    {
        String username = traderLyncUser.getUserNo();

        String userMemberId = instantVoices.get(username);
        String pwMemberId = instantVoices.get(traderLyncInterest.getInterestId());

        Log.debug( "["+ site.getName() + "] leaveInstantVoiceCall " + userMemberId + " " + pwMemberId);
    }

    private void updateSkypePresencePW(String groupname, String state)
    {
        try {
            Group nearsideGroup = GroupManager.getInstance().getGroup(groupname);

            if (nearsideGroup != null)
            {
                Map<String, String> properties = nearsideGroup.getProperties();
                updateSkypePresence(properties, state);
            }
        } catch (Exception e) {}
    }


    private void joinCall(TraderLyncUserInterest traderLyncUserInterest, TraderLyncUser traderLyncUser, TraderLyncInterest traderLyncInterest, String callID, String userInterest)
    {
        Log.debug( "["+ site.getName() + "] joinCall " + traderLyncInterest.getInterestId() + " " + traderLyncUser.getUserNo() + " " + callID);

        if (traderLyncInterest.useGateway)  // gateway, join external conference
        {
            String username = traderLyncUser.getUserNo();

            if (instantVoices.containsKey(traderLyncInterest.getInterestId()) && instantVoices.containsKey(username))
            {
                String userMemberId = instantVoices.get(username);
                String pwMemberId = instantVoices.get(traderLyncInterest.getInterestId());

                Log.debug( "["+ site.getName() + "] joinCall - instant voice " + userMemberId + " " + pwMemberId);


            } else {
                makeCall(null, userInterest, traderLyncUser.getHandsetNo(), null, null, userInterest, callID);
            }
        }

        else {
            String joinCallId = callID  + "-" + System.currentTimeMillis();
            String errorMessage = processOpenlinkRequest(traderLyncUserInterest, "JoinCall", traderLyncUser.getUserNo(), null, callID, null, joinCallId);

            if (errorMessage == null)
            {
                Iterator it = traderLyncInterest.getUserInterests().values().iterator();

                while( it.hasNext() )
                {
                    TraderLyncUserInterest eachInterest = (TraderLyncUserInterest)it.next();
                    TraderLyncCall usercall = eachInterest.getCallById(callID);

                    if (eachInterest.getUser().getUserNo().equals(traderLyncUser.getUserNo()))
                    {
                        eachInterest.handleCallConferenced(callID);
                        usercall.uuid = joinCallId;

                        testForNoSpeak(callID, traderLyncUserInterest, eachInterest);

                    } else {

                        if ("Inactive".equals(usercall.participation))
                            eachInterest.handleCallBusy(callID);
                        else {
                            eachInterest.handleCallConferenced(callID);
                            testForNoSpeak(callID, traderLyncUserInterest, eachInterest);
                        }
                    }
                }

                publishTraderLyncCallEvent(traderLyncInterest);
            }
        }
    }

    public String processUserAction(Element command, String userInterest, String action, String callID, String value1)
    {
        Log.debug( "["+ site.getName() + "] processUserAction " + userInterest + " " + action + " " + callID + " " + value1);
        String errorMessage = null;

        try {

            if (openlinkInterests.containsKey(userInterest))
            {
                TraderLyncUserInterest traderLyncUserInterest = openlinkInterests.get(userInterest);
                TraderLyncInterest traderLyncInterest = traderLyncUserInterest.getInterest();
                TraderLyncUser traderLyncUser = traderLyncUserInterest.getUser();

                TraderLyncCall traderLyncCall = traderLyncUserInterest.getCallById(callID);

                if (traderLyncCall != null)
                {
                    traderLyncCall.published = true;

                    Log.debug( "[" + site.getName() + "] processUserAction");

                    if (isValidAction(traderLyncCall, action))
                    {
                        if ("AnswerCall".equals(action))
                        {
                            if (isUserOnline(traderLyncUser))
                            {
                                if (traderLyncInterest.useGateway)      // gateway join, external conference
                                {
                                    makeCall(null, userInterest, traderLyncUser.getHandsetNo(), null, null, userInterest, callID);
                                }
                                else {
                                    errorMessage = processOpenlinkRequest(traderLyncUserInterest, "AnswerCall", traderLyncUser.getUserNo(), null, callID, null, null);
                                }

                                if (traderLyncUser.autoPrivate())
                                {
                                    //Thread.sleep(500);
                                    //traderLyncLinkService.privateCall(traderLyncUser.getDeviceNo(), traderLyncUser.getHandsetNo(), "Y");
                                }

                            } else {

                                errorMessage = "User device not online";
                            }
                        }

                        if ("JoinCall".equals(action))
                        {
                            if (isUserOnline(traderLyncUser))
                            {
                                joinCall(traderLyncUserInterest, traderLyncUser, traderLyncInterest, callID, userInterest);

                                if (traderLyncUser.autoPrivate())
                                {
                                    //Thread.sleep(500);
                                    //traderLyncLinkService.privateCall(traderLyncUser.getDeviceNo(), traderLyncUser.getHandsetNo(), "Y");
                                }

                            } else {

                                errorMessage = "User device not online";
                            }
                        }

                        if ("ClearConnection".equals(action))
                        {
                            errorMessage = processOpenlinkRequest(traderLyncUserInterest, "ClearConnection", traderLyncUser.getUserNo(), null, callID, null, null);
                        }

                        if ("PrivateCall".equals(action))
                        {
                            TraderLyncInterest callInterest = traderLyncUserInterest.getInterest();

                            for (TraderLyncUserInterest interest : callInterest.getUserInterests().values())
                            {
                                interest.handleCallPrivate(callID, "Y");
                            }

                            publishTraderLyncCallEvent(callInterest);
                        }

                        if ("PublicCall".equals(action))
                        {
                            TraderLyncInterest callInterest = traderLyncUserInterest.getInterest();

                            for (TraderLyncUserInterest interest : callInterest.getUserInterests().values())
                            {
                                interest.handleCallPrivate(callID, "N");
                            }

                            publishTraderLyncCallEvent(callInterest);
                        }

                        if ("SendDigits".equals(action))
                        {
                            value1 = makeDialableNumber(value1);

                            if (value1 == null || "".equals(value1))
                            {
                                errorMessage = "A dialable number is required for SendDigits";

                            } else {
                                errorMessage = processOpenlinkRequest(traderLyncUserInterest, "SendDigits", traderLyncUser.getUserNo(), value1, callID,  null, null);
                            }
                        }

                        if ("SendDigit".equals(action))
                        {
                            if (value1 != null && value1.length() > 0)
                            {
                                errorMessage = processOpenlinkRequest(traderLyncUserInterest, "SendDigits", traderLyncUser.getUserNo(), value1, callID,  null, null);

                            } else errorMessage = "A dialable digit must be provided for SendDigit action";
                        }

                        if ("ClearCall".equals(action))
                        {
                            errorMessage = processOpenlinkRequest(traderLyncUserInterest, "ClearCall", traderLyncUser.getUserNo(), null, callID, null, null);

                            for (TraderLyncUserInterest eachInterest : traderLyncInterest.getUserInterests().values())
                            {
                                eachInterest.handleConnectionCleared(callID);
                                publishTraderLyncUserCallEvent(eachInterest);

                                eachInterest.removeCallById(callID);
                            }

                            callList.remove(callID);

                        }

                        if ("IntercomTransfer".equals(action))
                        {
                            try {
                                TraderLyncUser toUser = getTraderLyncUser(new JID(value1));

                                if (isUserOnline(toUser))
                                {
                                    String toDeviceNo = toUser.getDeviceNo();
                                    errorMessage = processOpenlinkRequest(traderLyncUserInterest, "IntercomTransfer", traderLyncUser.getUserNo(), toDeviceNo, callID,  null, null);

                                } else errorMessage = value1 + " is either not a valid user or logged into a device";

                            } catch (Exception e) {
                                errorMessage = value1 + " is not a valid user identity";
                            }
                        }

                        if ("TransferCall".equals(action))
                        {
                            value1 = makeDialableNumber(value1);

                            if (value1 == null || "".equals(value1))
                            {
                                errorMessage = "A dialable number must be provided for a TransferCall action";

                            } else {
                                errorMessage = processOpenlinkRequest(traderLyncUserInterest, "TransferCall", traderLyncUser.getUserNo(), value1, callID,  null, null);
                            }
                        }

                        if ("SingleStepTransfer".equals(action))
                        {
                            value1 = makeDialableNumber(value1);

                            if (value1 == null || "".equals(value1))
                            {
                                errorMessage = "A dialable number must be provided for a SingleStepTransfer action";

                            } else {
                                errorMessage = processOpenlinkRequest(traderLyncUserInterest, "SingleStepTransfer", traderLyncUser.getUserNo(), value1, callID,  null, null);
                            }
                        }

                        if ("AddThirdParty".equals(action))
                        {
                            if (isUserOnline(traderLyncUser))
                            {
                                value1 = makeDialableNumber(value1);

                                if (value1 == null || "".equals(value1))
                                {
                                    errorMessage = "A dialable number must be provided for a AddThirdParty action";

                                } else {
                                    String joinCallId = callID  + "-" + System.currentTimeMillis();
                                    errorMessage = processOpenlinkRequest(traderLyncUserInterest, "AddThirdParty", traderLyncUser.getUserNo(), value1, callID,  null, joinCallId);

                                    if (errorMessage == null)
                                    {
                                        thirdPartyCalls.put(callID + "-" + traderLyncUser.getDeviceNo() + "-" + value1, joinCallId);
                                    }
                                }

                            } else {
                                errorMessage = "User device not online";
                            }
                        }

                        if ("RemoveThirdParty".equals(action))
                        {
                            if (isUserOnline(traderLyncUser))
                            {
                                value1 = makeDialableNumber(value1);

                                if (value1 == null || "".equals(value1))
                                {
                                    errorMessage = "A dialable number must be provided for a RemoveThirdParty action";

                                } else {
                                    String joinCallId = thirdPartyCalls.remove(callID + "-" + traderLyncUser.getDeviceNo() + "-" + value1);
                                    errorMessage = processOpenlinkRequest(traderLyncUserInterest, "RemoveThirdParty", traderLyncUser.getUserNo(), value1, callID,  null, joinCallId);
                            }
                            } else {
                                errorMessage = "User device not online";
                            }
                        }


                        if ("HoldCall".equals(action))
                        {
                            if (isUserOnline(traderLyncUser))
                            {
                                errorMessage = processOpenlinkRequest(traderLyncUserInterest, "HoldCall", traderLyncUser.getUserNo(), null, callID,  null, null);

                                if (errorMessage == null)
                                {
                                    Iterator it = traderLyncInterest.getUserInterests().values().iterator();

                                    while( it.hasNext() )
                                    {
                                        TraderLyncUserInterest eachInterest = (TraderLyncUserInterest)it.next();
                                        eachInterest.handleCallHeld(callID);
                                    }

                                    publishTraderLyncCallEvent(traderLyncInterest);
                                }

                            } else {
                                errorMessage = "User device not online";
                            }
                        }

                        if ("RetrieveCall".equals(action))
                        {
                            if (isUserOnline(traderLyncUser))
                            {
                                errorMessage = processOpenlinkRequest(traderLyncUserInterest, "RetrieveCall", traderLyncUser.getUserNo(), null, callID, null, null);

                            } else {
                                errorMessage = "User device not online";
                            }
                        }

                        if ("StartVoiceDrop".equals(action))
                        {

                            //VMessage message = getVMId(traderLyncUser, value1);

                            //if (message == null)
                            //{
                            //  errorMessage = "A valid voice message feature Id must be provided for a StartVoiceDrop action";

                            //} else {

                                //String exten = traderLyncVmsService.getVMExtenToDial(traderLyncUser, message.getId(), message.getName());
                                //errorMessage = traderLyncLinkService.addExternalCall(traderLyncCall.getLine(), makeDialableNumber(exten));
                            //}
                        }

                        if ("StopVoiceDrop".equals(action))
                        {
                            //Message message = getVMId(traderLyncUser, value1);

                            //if (message == null)
                            //{
                            //  errorMessage = "A valid voice message feature Id must be provided for a StartVoiceDrop action";

                            //} else {

                                //String exten = traderLyncVmsService.getVMExtenToDial(traderLyncUser, message.getId(), message.getName());
                                //errorMessage = traderLyncLinkService.removeExternalCall(traderLyncCall.getLine(), makeDialableNumber(exten));
                            //}
                        }

                        if ("AlertCall".equals(action))
                        {
                            errorMessage = sendAlert(traderLyncInterest, callID);
                        }

                        if ("StartSpeaking".equals(action))
                        {
                            errorMessage = intercomStartSpeaking(callID);
                        }

                    } else errorMessage = "Action is not valid";

                } else errorMessage = "Call id not found";

            } else errorMessage = "Interest not found";

        }
        catch(Exception e) {
            Log.error("["+ site.getName() + "] processUserAction ", e);
            errorMessage = "Request Action internal error - " + e.toString();
        }


        if (errorMessage != null && command != null)
        {
            Element note = command.addElement("note");
            note.addAttribute("type", "error");
            note.setText("Request Action - " + errorMessage);
        }

        if (errorMessage == null) addCallStatusExtension(command);
        return errorMessage;
    }

    private String intercomStartSpeaking(String callId)
    {
        Log.debug( "["+ site.getName() + "] intercomStartSpeaking " + callId);

        String error = null;
        BridgeParticipant bp = intercomList.get(callId);

        if (bp != null && bp.fromMember != null && bp.toMember != null) // instant voice
        {

        }
        else error = "StartSpeaking intercom call not found";

        return error;
    }

    private String sendAlert(TraderLyncInterest traderLyncInterest, String callId)
    {
        Log.debug( "["+ site.getName() + "] sendAlert " + traderLyncInterest.getInterestId());

        String error = null;

        try {
            String groupname = traderLyncInterest.getInterestId();
            Group nearsideGroup = GroupManager.getInstance().getGroup(groupname);

            if (nearsideGroup != null)
            {
                Map<String, String> properties = nearsideGroup.getProperties();

                if (properties.containsKey("traderlynk.wirelynk"))
                {
                    String farsideGroupName = properties.get("traderlynk.wirelynk");
                    Group farsideGroup = GroupManager.getInstance().getGroup(farsideGroupName);

                    Log.debug("["+ site.getName() + "] sendAlert send audiobridge ring-down to " + farsideGroupName);

                    if (farsideGroup != null)
                    {
                        Map<String, String> farProperties = farsideGroup.getProperties();
                        String audiobridge = farProperties.get("traderlynk.wirelynk.gateway");
                        String lineId = farProperties.get("traderlynk.wirelynk.lineid");

                        if (lineId != null && audiobridge != null)
                        {
                            //BloombergPlugin.self.sendRingdown(audiobridge, callId, lineId);
                        }

                    } else error = "Interest farside is missing";

                    Log.debug("["+ site.getName() + "] sendAlert send call-alerted event " + farsideGroupName);

                    if (traderLyncInterests.containsKey(farsideGroupName))
                    {
                        Log.debug("["+ site.getName() + "] sendAlert found interest " + farsideGroupName);

                        TraderLyncInterest interest = traderLyncInterests.get(farsideGroupName);

                        for (TraderLyncUserInterest farInterest : interest.getUserInterests().values())
                        {
                            farInterest.handleCallAlerted(farInterest.ivCallId, true);
                            publishTraderLyncUserCallEvent(farInterest);
                        }

                    } else error = "Interest farside is invalid";

                } else error = "Interest is missing farside";

            } else error = "Interest not found";
        }
        catch(Exception e) {
            Log.error("["+ site.getName() + "] sendAlert ", e);
            error = "Exception: " + e;
        }
        return error;
    }

    public String setFeature(Element newCommand, String profileID, String featureID, String value1, String value2)
    {
        Log.debug( "["+ site.getName() + "] setFeature " + profileID + " " + featureID + " " + value1 + " " + value2);
        String errorMessage = null;

        try {

            if (value1 != null && value1.length() > 0)
            {
                TraderLyncUser traderLyncUser = getOpenlinkProfile(profileID);

                if (traderLyncUser != null)
                {
                    if ("hs_1".equals(featureID))
                    {
                        if (validateTrueFalse(value1))
                            traderLyncUser.setHandsetNo("true".equals(value1.toLowerCase()) ? "1" : "2");
                        else
                            errorMessage = "value1 is not true or false";

                    }

                    else if ("hs_2".equals(featureID))
                    {
                        if (validateTrueFalse(value1))
                            traderLyncUser.setHandsetNo("true".equals(value1.toLowerCase()) ? "2" : "1");
                        else
                            errorMessage = "value1 is not true or false";
                    }

                    else if ("priv_1".equals(featureID))
                    {
                        if (validateTrueFalse(value1))
                            traderLyncUser.setAutoPrivate("true".equals(value1.toLowerCase()));
                        else
                            errorMessage = "value1 is not true or false";
                    }

                    else if ("hold_1".equals(featureID))
                    {
                        if (validateTrueFalse(value1))
                            traderLyncUser.setAutoHold("true".equals(value1.toLowerCase()));
                        else
                            errorMessage = "value1 is not true or false";
                    }

                    else if ("callback_1".equals(featureID))
                    {
                        if (validateTrueFalse(value1))
                        {
                            if ("true".equals(value1.toLowerCase()))
                            {
                                if (value2 != null && !"".equals(value2))
                                {
                                    String dialableNumber = makeDialableNumber(value2);

                                    if (dialableNumber != null && !"".equals(dialableNumber))
                                    {
                                        traderLyncUser.setCallback(dialableNumber);
                                        TraderLyncCallback traderLyncCallback = null; //traderLyncLinkService.allocateCallback(traderLyncUser);

                                        if (traderLyncCallback == null)
                                            errorMessage = "unable to allocate a virtual turret";

                                    } else errorMessage = "value2 is not a dialable number";

                                } else {

                                    if (traderLyncUser.getCallback() != null)
                                    {
                                        TraderLyncCallback traderLyncCallback = null; //traderLyncLinkService.allocateCallback(traderLyncUser);

                                        if (traderLyncCallback == null)
                                            errorMessage = "unable to allocate a callback";

                                    } else errorMessage = "calback destination is missing";
                                }

                            } else  {

                                //traderLyncLinkService.freeCallback(traderLyncUser.getUserNo());
                                traderLyncUser.setPhoneCallback(null);
                            }
                        }
                        else errorMessage = "value1 is not true or false";
                    }

                    else if ("fwd_1".equals(featureID)) // call forward
                    {
                        if (openlinkInterests.containsKey(value1))  // value is interest id
                        {
                            TraderLyncUserInterest traderLyncUserInterest = openlinkInterests.get(value1);

                            if (traderLyncUser.getUserNo().equals(traderLyncUser.getUserNo()))
                            {
                                if ("D".equals(traderLyncUserInterest.getInterest().getInterestType()))
                                {
                                    String pname = site.getName().toLowerCase();

                                    String pbxFWDCodePrefix = JiveGlobals.getProperty(Properties.TraderLync_PBX_FWD_CODE_PREFIX + "." + pname, "*41");
                                    String pbxFWDCodeSuffix = JiveGlobals.getProperty(Properties.TraderLync_PBX_FWD_CODE_SUFFIX + "." + pname, "");
                                    String pbxFWDCodeCancel = JiveGlobals.getProperty(Properties.TraderLync_PBX_FWD_CODE_CANCEL + "." + pname, "*41");

                                    String dialDigits = null;

                                    if (value2 == null || "".equals(value2))
                                    {
                                        dialDigits = pbxFWDCodeCancel;
                                        errorMessage = doCallForward(dialDigits, traderLyncUserInterest, newCommand);

                                        if (errorMessage == null)
                                        {
                                            Iterator<TraderLyncUserInterest> iter2 = traderLyncUserInterest.getInterest().getUserInterests().values().iterator();

                                            while( iter2.hasNext() )
                                            {
                                                TraderLyncUserInterest theUserInterest = (TraderLyncUserInterest)iter2.next();
                                                theUserInterest.setCallFWD("false");
                                            }

                                            traderLyncUser.setLastCallForward("");
                                        }

                                    } else {

                                        String dialableNumber = makeDialableNumber(value2);

                                        if (dialableNumber != null && !"".equals(dialableNumber))
                                        {
                                            dialDigits = pbxFWDCodePrefix + dialableNumber + pbxFWDCodeSuffix;
                                            errorMessage = doCallForward(dialDigits, traderLyncUserInterest, newCommand);

                                            if (errorMessage == null)
                                            {
                                                Iterator<TraderLyncUserInterest> iter2 = traderLyncUserInterest.getInterest().getUserInterests().values().iterator();

                                                while( iter2.hasNext() )
                                                {
                                                    TraderLyncUserInterest theUserInterest = (TraderLyncUserInterest)iter2.next();
                                                    theUserInterest.setCallFWD("true");
                                                    theUserInterest.setCallFWDDigits(value2);
                                                }

                                                traderLyncUser.setLastCallForwardInterest(value1);
                                                traderLyncUser.setLastCallForward(value2);
                                            }

                                        } else errorMessage = "value2 is not a dialable number";
                                    }

                                } else errorMessage = "CallForward requires a directory number interest";

                            } else errorMessage = "Interest does not belong to this profile";

                        } else errorMessage = "Interest not found";
                    }
                    else errorMessage = "Feature not found";

                } else errorMessage = "Profile not found";

            } else errorMessage = "Input1 is missing";
        }
        catch(Exception e) {
            Log.error("["+ site.getName() + "] setFeature ", e);
            errorMessage = "Internal error - " + e.toString();
        }

        return errorMessage;
    }


    private String doCallForward(String dialDigits, TraderLyncUserInterest traderLyncUserInterest, Element newCommand)
    {
        String errorMessage = null;

        //traderLyncUserInterest.getUser().selectCallset(this, traderLyncUserInterest.getInterest().getCallset(), traderLyncUserInterest.getUser().getHandsetNo(), "true", "true", dialDigits);
        //errorMessage = waitForFirstEvent(newCommand, traderLyncUserInterest.getUser(), false, traderLyncUserInterest.getUser().getHandsetNo());
        //traderLyncLinkService.clearCall(traderLyncUserInterest.getUser().getDeviceNo(), traderLyncUserInterest.getUser().getHandsetNo());

        return errorMessage;
    }

    //-------------------------------------------------------
    //
    //  Meet Command
    //
    //-------------------------------------------------------

    public String meet(Element newCommand, JID userJID, JID meetingJID, String action, JSONObject meeting)
    {
        Log.debug( "["+ site.getName() + "] meeting " + userJID + " " + meetingJID + " " + action + "\n" + meeting);

        String errorMessage = null;

        try {

            if ("join".equals(action))
            {
                String userId = userJID.getNode();
                String muc = meetingJID.getNode();

                if (traderLyncUserTable.containsKey(userId))
                {
                    TraderLyncUser traderLyncUser = traderLyncUserTable.get(userId);

                    if (isUserOnline(traderLyncUser))
                    {

                    } else errorMessage = "user is offline";

                } else errorMessage = "user not found";

            } else {
                errorMessage = processMeetAction(newCommand, userJID, meetingJID, action, meeting);
            }

        } catch (Exception e) {
            errorMessage = e.toString();
        }
        return errorMessage;
    }

    //-------------------------------------------------------
    //
    //  Manage VoiceBridge
    //
    //-------------------------------------------------------


    public String manageVoiceBridge(Element newCommand, JID userJID, List<Object[]> actions)
    {
        Log.debug( "["+ site.getName() + "] manageVoiceMessage " + userJID + " ");
        String errorMessage = "";
        List<String> actionList = new ArrayList<String>();

        try {

            if (actions != null && actions.size() > 0)
            {
                Iterator it = actions.iterator();

                while( it.hasNext() )
                {
                    Object[] action = (Object[])it.next();

                    String name = (String) action[0];
                    String value1 = (String) action[1];
                    String value2 = (String) action[2];

                    String thisErrorMessage = manageCallParticipant(userJID, value1, name, value2, it.hasNext());

                    if (thisErrorMessage != null)
                    {
                        errorMessage = errorMessage + thisErrorMessage + "; ";
                    }
                }

                if (actionList.size() > 0)
                {
                    //handlePostBridge(actionList);
                }

            } else errorMessage = "Voice bridge actions are missing";

        }
        catch(Exception e) {
            Log.error("["+ site.getName() + "] manageVoiceBridge ", e);
            errorMessage = "Internal error - " + e.toString();
        }

        return errorMessage.length() == 0 ? null : errorMessage;
    }


    private String manageCallParticipant(JID userJID, String uid, String parameter, String value, boolean more)
    {
        String response = null;

        try {
            Log.debug( "["+ site.getName() + "] manageCallParticipant " + uid);

            if (bridgeParticipants.containsKey(uid) == false)
            {
                BridgeParticipant bp = new BridgeParticipant();
                bp.userJID = userJID;
                bp.uid = uid;

                bridgeParticipants.put(uid, bp);
            }

            response = parseCallParameters(parameter, value, uid, bridgeParticipants.get(uid));

            if ("CancelCall".equalsIgnoreCase(parameter))
            {
                bridgeParticipants.remove(uid);
            }

        } catch (Exception e) {
            response = (e.toString());
        }

        return response;
    }

    private String parseCallParameters(String parameter, String value, String uid, BridgeParticipant bp)
    {
        String response = null;

        if ("SetPhoneNo".equalsIgnoreCase(parameter)) {
            String dialDigits = makeDialableNumber(value);

            if (dialDigits == null || "".equals(dialDigits)) {
                response =  "SetPhoneNo is not a dialable number";
            } else {
                bp.phoneNumber = dialDigits;
            }
            return response;
        }

        if ("Set2ndPartyPhoneNo".equalsIgnoreCase(parameter)) {
            String dialDigits = makeDialableNumber(value);

            if (dialDigits == null || "".equals(dialDigits)) {
                response =  "secondPartyPhoneNo is not a dialable number";
            } else {
                bp.secondPartyPhoneNo = dialDigits;
            }
            return response;
        }

        if ("SetConference".equalsIgnoreCase(parameter)) {
            bp.conference = value;
            createPubsubNode(bp.conference);
            return response;
        }

        if ("SetIncomingInterest".equalsIgnoreCase(parameter)) {

            if (openlinkInterests.containsKey(value))
                bp.incomingInterest = openlinkInterests.get(value);
            else
                response = "Unknown incoming Interest";
            return response;
        }

        if ("SetOutgoingInterest".equalsIgnoreCase(parameter)) {
            if (openlinkInterests.containsKey(value))
                bp.outgoingInterest = openlinkInterests.get(value);
            else
                response = "Unknown incoming Interest";
            return response;
        }

        if ("DeafenTalk".equalsIgnoreCase(parameter)) response = relateAction(parameter, "nohear", value, bp);
        if ("MuteTalk".equalsIgnoreCase(parameter)) response = relateAction(parameter, "nospeak", value, bp);
        if ("ResetTalk".equalsIgnoreCase(parameter)) response = relateAction(parameter, "clear", value, bp);

        if ("CancelCall".equalsIgnoreCase(parameter))
        {

            return response;
        }

        if ("MakeCall".equalsIgnoreCase(parameter))
        {
            response = validateAndAdjustParameters(bp);

            if (response == null)
            {

            }
            return response;
        }
        return "Invalid action";
    }

    private String relateAction(String parameter, String action, String value, BridgeParticipant bp)
    {
        String response = null;

        if (bridgeParticipants.containsKey(value))
        {
            BridgeParticipant participant = bridgeParticipants.get(value);

            if (participant.memberId != null && bp.memberId != null)
            {


            } else response = "Participants not found";

        } else response = "Bridged conference call not found";

        return response;
    }

    private String makeDestination(String dialDigits, String sipDomain)
    {
        return dialDigits;
    }

    private TraderLyncUserInterest getDefaultInterestByDevice(String deviceNo)
    {
        TraderLyncUserInterest traderLyncUserInterest = null;

        if (defaultInterests.containsKey(deviceNo))
        {
            traderLyncUserInterest = defaultInterests.get(deviceNo);
        }
        return traderLyncUserInterest;
    }

    private TraderLyncUserInterest getDefaultInterestByUsername(String userName)
    {
        TraderLyncUserInterest traderLyncUserInterest = null;
        Iterator<TraderLyncUser> it = traderLyncUserTable.values().iterator();

        while( it.hasNext() )
        {
            TraderLyncUser traderLyncUser = (TraderLyncUser)it.next();

            if (userName.equals(traderLyncUser.getUserId()) && "true".equals(traderLyncUser.getDefault()))
            {
                if (traderLyncUser.getDefaultInterest() != null)
                {
                    traderLyncUserInterest = traderLyncUser.getDefaultInterest().getUserInterests().get(userName);
                }
                break;
            }
        }
        return traderLyncUserInterest;
    }

    private String validateAndAdjustParameters(BridgeParticipant bp)
    {
        String response = null;

        if (bp.phoneNumber == null)
        {
            response = ("You must specify a phone number or a soft phone URI");
            return response;
        }

        if (bp.conference == null && bp.secondPartyPhoneNo == null)
        {
            response = ("You must specify a conference Id");
            return response;
        }

        if (bp.secondPartyPhoneNo != null)
        {
            if (bp.conference == null)
            {
                bp.conference = bp.phoneNumber;
            }
        }
        return response;
    }

    private void sendBridgedEvent(BridgeParticipant bp, String callState)
    {
        String nodeName = bp.conference;

        String myEvent  = "state_changed";
        String info     = "source='" + bp.phoneNumber + "' destination='" + bp.secondPartyPhoneNo + "'";
        String dtmf     = "";
        int noOfCalls   = 2;
        String callId   = bp.uid;
        String memberId = bp.memberId == null ? "" : bp.memberId;
        String confId   = bp.conference;
        String callInfo = bp.outgoingInterest == null ? "" : bp.outgoingInterest.getInterestName();

        IQ iq = new IQ(IQ.Type.set);
        iq.setFrom(getName() + "." + getDomain());
        iq.setTo("pubsub." + getDomain());
        Element pubsub = iq.setChildElement("pubsub", "http://jabber.org/protocol/pubsub");
        Element publish = pubsub.addElement("publish").addAttribute("node", nodeName);
        Element item = publish.addElement("item").addAttribute("id", nodeName);
        Element voicebridge = item.addElement("voicebridge", "http://xmpp.org/protocol/openlink:01:00:00#voice-bridge");

        voicebridge.addElement("jid").setText(bp.userJID.toBareJID());
        voicebridge.addElement("source").setText("monitorCallStatus");
        voicebridge.addElement("eventtype").setText(myEvent);
        voicebridge.addElement("dtmf").setText(dtmf);
        voicebridge.addElement("participants").setText(String.valueOf(noOfCalls));
        voicebridge.addElement("callstate").setText(callState);
        voicebridge.addElement("conference").setText(confId);
        voicebridge.addElement("participant").setText(callId);
        voicebridge.addElement("member").setText(memberId);
        voicebridge.addElement("callinfo").setText(callInfo);
        voicebridge.addElement("eventinfo").setText(info);

        sendPacket(iq);
    }

    private class BridgeParticipant
    {
        public JID userJID;
        public String uid;
        public String memberId = null;
        public String phoneNumber = null;
        public String secondPartyPhoneNo = null;
        public String conference;
        public TraderLyncUserInterest incomingInterest = null;
        public TraderLyncUserInterest outgoingInterest = null;
        public String callset;
        public TraderLyncUser itsUser = null;
        public boolean last = false;
        public String fromMember = null;
        public String toMember = null;

    }

    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------


    public String manageVoiceMessage(Element newCommand, String profileID, String featureId, String action, String value1)
    {
        Log.debug( "["+ site.getName() + "] manageVoiceMessage " + profileID + " " + featureId + " " + action + " " + value1);
        String errorMessage = null;

        try {

            if (action != null && action.length() > 0)
            {
                TraderLyncUser traderLyncUser = getOpenlinkProfile(profileID);

                if (traderLyncUser != null)
                {
                    action = action.toLowerCase();

                    if ("record".equals(action))
                    {

                    }

                    else if ("edit".equals(action))
                    {

                    }

                    else if ("playback".equals(action))
                    {

                    }

                    else if ("delete".equals(action))
                    {

                    }

                    else if ("save".equals(action))
                    {

                    }

                    else if ("archive".equals(action))
                    {

                    } else  errorMessage = "Action not supported";

                } else errorMessage = "Profile not found";

            } else errorMessage = "Action is missing";
        }
        catch(Exception e) {
            Log.error("["+ site.getName() + "] manageVoiceMessage ", e);
            errorMessage = "Internal error - " + e.toString();
        }

        return errorMessage;
    }

    private void addVoiceMessageExtension(Element newCommand, String exten, TraderLyncUser traderLyncUser, String msgId)
    {
        Element iodata = newCommand.addElement("iodata", "urn:xmpp:tmp:io-data");
        iodata.addAttribute("type","output");
        Element devicestatus = iodata.addElement("out").addElement("devicestatus", "http://xmpp.org/protocol/openlink:01:00:00#device-status");
        devicestatus.addElement("profile").setText(traderLyncUser.getProfileName());
        Element feature = devicestatus.addElement("features").addElement("feature").addAttribute("id", msgId);
        Element voicemessage = feature.addElement("voicemessage").addAttribute("xmlns", "http://xmpp.org/protocol/openlink:01:00:00/features#voice-message");

        voicemessage.addElement("msglen");
        voicemessage.addElement("status").setText("ok");
        voicemessage.addElement("statusdescriptor");
        voicemessage.addElement("state");

        if (exten == null || exten.length() == 0)
            voicemessage.addElement("exten");
        else
            voicemessage.addElement("exten").setText(exten);
    }

    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------

    public List<TraderLyncUser> getOpenlinkProfiles(JID jid)
    {
        List<TraderLyncUser> traderLyncUsers = new ArrayList();
        String userName = jid.getNode();

        if (jid.getDomain().indexOf(getDomain()) > -1)
        {
            Iterator<TraderLyncUser> it = traderLyncUserTable.values().iterator();

            while( it.hasNext() )
            {
                TraderLyncUser traderLyncUser = (TraderLyncUser)it.next();

                if (userName.equals(traderLyncUser.getUserId()))
                {
                    traderLyncUsers.add(traderLyncUser);
                }
            }
        }

        return traderLyncUsers;
    }


    public TraderLyncUser getTraderLyncUser(JID jid)
    {
        return getTraderLyncUser(jid.getNode());
    }


    public TraderLyncUser getTraderLyncUser(String userName)
    {
        Iterator<TraderLyncUser> it = traderLyncUserTable.values().iterator();

        while( it.hasNext() )
        {
            TraderLyncUser traderLyncUser = (TraderLyncUser)it.next();

            if (isUserOnline(traderLyncUser))
            {
                return traderLyncUser;
            }
        }
        return null;
    }


    public TraderLyncUser getOpenlinkProfile(String profileID)
    {
        TraderLyncUser traderLyncUser = null;

        if (traderLyncUserTable.containsKey(profileID))
        {
            traderLyncUser = traderLyncUserTable.get(profileID);
        }

        return traderLyncUser;
    }

    public TraderLyncUser findOpenlinkProfile(String profileID)
    {
        TraderLyncUser traderLyncUser = new TraderLyncUser();

        if (traderLyncUserTable.containsKey(profileID))
        {
            traderLyncUser = traderLyncUserTable.get(profileID);

        } else {
            traderLyncUser = new TraderLyncUser();
            traderLyncUser.setUserId(profileID);
            traderLyncUser.setUserNo(profileID);

            traderLyncUserTable.put(profileID, traderLyncUser);
        }

        return traderLyncUser;
    }

    public TraderLyncUserInterest getOpenlinkInterest(String userInterest)
    {
        TraderLyncUserInterest traderLyncUserInterest = null;

        if (openlinkInterests.containsKey(userInterest))
        {
            traderLyncUserInterest = openlinkInterests.get(userInterest);
        }

        return traderLyncUserInterest;
    }

    public String getSiteID()
    {
        return String.valueOf(site.getSiteID());
    }

    public void sendPacket(Packet packet)
    {
        try {
            componentManager.sendPacket(this, packet);

        } catch (Exception e) {
            Log.error("Exception occured while sending packet.", e);

        }
    }


    public void getInterestSubscriptions()
    {
        Log.debug( "["+ site.getName() + "] getInterestSubscriptions");

        try {
            Iterator<TraderLyncUser> iter = traderLyncUserTable.values().iterator();

            while(iter.hasNext())
            {
                TraderLyncUser traderLyncUser = (TraderLyncUser)iter.next();

                Iterator<TraderLyncInterest> iter2 = traderLyncUser.getInterests().values().iterator();

                while( iter2.hasNext() )
                {
                    TraderLyncInterest traderLyncInterest = (TraderLyncInterest)iter2.next();
                    getInterestSubscriptions(traderLyncInterest, traderLyncUser.getUserNo());
                }
            }
        }
        catch(Exception e) {
            Log.error("["+ site.getName() + "] getInterestSubscriptions ", e);
        }
    }


    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------


    public boolean validateTrueFalse(String value1)
    {
        boolean valid = false;
        String flag = value1.toLowerCase();

        if ("true".equals(flag) || "false".equals(flag))
        {
            valid = true;
        }
        return valid;
    }


    public String makeDialableNumber(String digits)
    {
        String dialableNumber = null;

        if ((digits != null && !"".equals(digits)) || digits.startsWith("sip:") || digits.startsWith("tel:")  || digits.startsWith("user:")  || digits.startsWith("extn:"))
        {
            dialableNumber = digits;
/*
            String cononicalNumber = formatCanonicalNumber(convertAlpha(digits));

            if (cononicalNumber != null && !"".equals(cononicalNumber))
            {
                dialableNumber = formatDialableNumber(cononicalNumber);
            }
*/
            Log.info( "["+ site.getName() + "] makeDialableNumber " + digits + "=>" + dialableNumber);
        }

        return dialableNumber;
    }

    private String convertAlpha(String input)
    {
        int inputlength = input.length();
        input = input.toLowerCase();
        String phonenumber = "";

        for (int i = 0; i < inputlength; i++) {
            int character = input.charAt(i);

            switch(character) {
                case '+': phonenumber+="+";break;
                case '*': phonenumber+="*";break;
                case '#': phonenumber+="#";break;
                case '0': phonenumber+="0";break;
                case '1': phonenumber+="1";break;
                case '2': phonenumber+="2";break;
                case '3': phonenumber+="3";break;
                case '4': phonenumber+="4";break;
                case '5': phonenumber+="5";break;
                case '6': phonenumber+="6";break;
                case '7': phonenumber+="7";break;
                case '8': phonenumber+="8";break;
                case '9': phonenumber+="9";break;
                case  'a': case 'b': case 'c': phonenumber+="2";break;
                case  'd': case 'e': case 'f': phonenumber+="3";break;
                case  'g': case 'h': case 'i': phonenumber+="4";break;
                case  'j': case 'k': case 'l': phonenumber+="5";break;
                case  'm': case 'n': case 'o': phonenumber+="6";break;
                case  'p': case 'q': case 'r': case 's': phonenumber+="7";break;
                case  't': case 'u': case 'v': phonenumber+="8";break;
                case  'w': case 'x': case 'y': case 'z': phonenumber+="9";break;
           }
        }

        return (phonenumber);
    }

    public boolean isComponent(JID jid) {
        final RoutingTable routingTable = server.getRoutingTable();

        if (routingTable != null)
        {
            return routingTable.hasComponentRoute(jid);
        }
        return false;
    }

    public void setRefreshCacheInterval()
    {
        Log.debug( "["+ site.getName() + "] setRefreshCacheInterval ");

        try {


        }
        catch (Exception e)
        {
            Log.error("["+ site.getName() + "] setRefreshCacheInterval ", e);
        }
    }

    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------

    private boolean isNumeric(String str)
    {
      try
      {
        double d = Double.parseDouble(str);
      }
      catch(NumberFormatException nfe)
      {
        return false;
      }
      return true;
    }

    private boolean isBookmarkForJID(String username, Bookmark bookmark) {

        if (username == null || username.equals("null")) return false;

        if (bookmark.getUsers().contains(username)) {
            return true;
        }

        Collection<String> groups = bookmark.getGroups();

        if (groups != null && !groups.isEmpty()) {
            GroupManager groupManager = GroupManager.getInstance();

            for (String groupName : groups) {
                try {
                    Group group = groupManager.getGroup(groupName);

                    if (group.isUser(username)) {
                        return true;
                    }
                }
                catch (GroupNotFoundException e) {
                    Log.debug(e.getMessage(), e);
                }
            }
        }
        return false;
    }

    public Map getUserIntercoms(String username)
    {
        Map<String, String> intercoms = new HashMap<String, String>();

        try {

            Roster roster = rosterManager.getRoster(username);
            List<RosterItem> rosterItems = new ArrayList<RosterItem>(roster.getRosterItems());
            Collections.sort(rosterItems, new RosterItemComparator());

            for (RosterItem item : rosterItems)
            {
                User peerUser = getUser(item.getJid().getNode());

                if (peerUser != null && peerUser.getProperties().containsKey("msteams.phone.number") && item.getSubStatus() != RosterItem.SUB_NONE)
                {
                    intercoms.put(peerUser.getUsername(), peerUser.getEmail());
                }
            }

        } catch (Exception e) {

        }
        return intercoms;
    }


    public Map getUserSpeedDials(String username)
    {
        Map<String, String> speedDials = new HashMap<String, String>();

        try {
            Roster roster = rosterManager.getRoster(username);
            List<RosterItem> rosterItems = new ArrayList<RosterItem>(roster.getRosterItems());
            Collections.sort(rosterItems, new RosterItemComparator());

            for (RosterItem item : rosterItems)
            {
                User peerUser = getUser(item.getJid().getNode());

                if (peerUser != null && peerUser.getProperties().containsKey("msteams.phone.number") && item.getSubStatus() != RosterItem.SUB_NONE)
                {
                    speedDials.put(peerUser.getUsername(), peerUser.getProperties().get("msteams.phone.number"));
                }
            }

            final Collection<Bookmark> bookmarks = BookmarkManager.getBookmarks();

            for (Bookmark bookmark : bookmarks)
            {
                boolean addBookmarkForUser = bookmark.isGlobalBookmark() || isBookmarkForJID(username, bookmark);

                if (addBookmarkForUser)
                {
                    if (bookmark.getType() == Bookmark.Type.url)
                    {
                        String url = bookmark.getValue();

                        if (url.indexOf("tel:+") == 0)
                        {
                            String value = url.substring(5);
                            speedDials.put(bookmark.getName(), value);

                            JSONObject json = new JSONObject();
                            json.put("value", value);
                            json.put("name", bookmark.getName());
                            json.put("notification", bookmark.getProperty("notification"));
                            json.put("title", bookmark.getProperty("title"));
                            json.put("org", bookmark.getProperty("org"));
                            json.put("research", bookmark.getProperty("research"));

                            reverseSpeeedDials.put(value, json);
                        }
                    }
                }
            }

        } catch (Exception e) {

        }
        return speedDials;
    }


    private void preloadDirectInterests()
    {
        Log.info( "["+ site.getName() + "] preloadDirectInterests");

        for (TraderLyncInterest traderLyncInterest : traderLyncInterests.values())
        {
            if (traderLyncInterest.useGateway)
            {
                preloadDirectInterest(traderLyncInterest);
            }
        }

    }

    private void preloadDirectInterest(TraderLyncInterest traderLyncInterest)
    {
        Log.info( "["+ site.getName() + "] preloadDirectInterest - interest " + traderLyncInterest.getInterestId());

        try
        {
            Group group = GroupManager.getInstance().getGroup(traderLyncInterest.getInterestId());
            Map<String, String> properties = group.getProperties();


        } catch (Exception e) {
            Log.error("preloadDirectInterest", e);
        }
    }

    public void resetInterest(TraderLyncInterest traderLyncInterest, Map<String, String> properties)
    {
        updateSkypePresence(properties, "idle");

        if (instantVoiceEnabled && traderLyncInterest.useGateway)
        {
            String ivCallId = null;

            for (TraderLyncUserInterest eachInterest : traderLyncInterest.getUserInterests().values())
            {
                if (eachInterest.ivCallId != null) ivCallId = eachInterest.ivCallId;
            }

            if (ivCallId != null)
            {
                preloadDirectInterest(traderLyncInterest);
            }
        }
    }

    public void getUserProfiles()
    {
        try
        {
            traderLyncInterests.clear();
            openlinkInterests.clear();

            Collection<User> users = userManager.getUsers();
            boolean shareDDIWithPeers = JiveGlobals.getBooleanProperty("msteams.share.ddi.withpeers", false);

            for (User user : getUsersByProperty("msteams.phone.number", null, 0, 0))
            {
                String userId = user.getUsername();
                getUserSpeedDials(userId);
                Roster roster = rosterManager.getRoster(userId);
                Map<String, String> userProperties = user.getProperties();
                String userPhone = userProperties.get("msteams.phone.number").replace("?", "");

                Log.info( "["+ site.getName() + "] getUserProfiles - user profile " + userId + " " + userPhone);

                TraderLyncUser traderLyncUser = findOpenlinkProfile(userId);
                traderLyncUser.setUserName(user.getName());
                traderLyncUser.setSiteName(getName());
                traderLyncUser.setSiteID(1);
                traderLyncUser.setHandsetNo("1");

                traderLyncUser.properties = userProperties;
                traderLyncUser.email = user.getEmail();

                TraderLyncUserInterest userInterest = null;

                setupPrivateStorage(userId);

                // personal DDI

                traderLyncUser.setDeviceNo(userPhone);
                userInterest = createInterest(traderLyncUser, userPhone, "D", user.getName(), "true", userPhone, false, false);
                traderLyncUser.setDefault("true");

                defaultInterests.put(userId, userInterest);

                if (shareDDIWithPeers)
                {
                    TraderLyncInterest traderLyncInterest = userInterest.getInterest();

                    for (RosterItem item : roster.getRosterItems())
                    {
                        User peerUser = getUser(item.getJid().getNode());

                        if (peerUser != null && peerUser.getProperties().containsKey("msteams.phone.number") && item.getSubStatus() != RosterItem.SUB_NONE)
                        {
                            createPeer(traderLyncInterest, peerUser.getUsername());
                        }
                    }
                }

                List<TraderLyncGroup> traderLyncGroups = new ArrayList<TraderLyncGroup>();

                Collection<Group> groups = GroupManager.getInstance().getGroups(user);
                int index = 0;

                for (Group group : groups)
                {
                    String description = group.getDescription();
                    String groupname = group.getName().replace("?", "");

                    Log.info( "["+ site.getName() + "] found group " + groupname + " " + description);

                    if (isNumeric(groupname))
                    {
                        Log.info( "["+ site.getName() + "] adding group " + groupname + " " + description);

                        userInterest = createInterest(traderLyncUser, groupname, "D", description, "false", groupname, true, false);

                        TraderLyncGroup traderlyncGroup = new TraderLyncGroup();

                        traderlyncGroup.setGroupID(groupname);
                        traderlyncGroup.setName(description);

                        for (JID memberJID : group.getMembers())
                        {
                            String name = memberJID.getNode();
                            TraderLyncGroupMember member = new TraderLyncGroupMember();
                            member.setMemberID(memberJID.toString());
                            traderlyncGroup.addMember(name, member);
                        }

                        for (JID memberJID : group.getAdmins())
                        {
                            String name = memberJID.getNode();
                            TraderLyncGroupMember member = new TraderLyncGroupMember();
                            member.setMemberID(memberJID.toString());
                            traderlyncGroup.addMember(name, member);
                        }
                        traderLyncGroups.add(traderlyncGroup);
                    }
                }

                traderLyncUser.setGroups(traderLyncGroups);
                // not sure why this is here
                createPubsubNode(user.getUsername() + "@" + getDomain());
            }
        }
        catch (Exception e)
        {
            Log.error( "["+ site.getName() + "] " +  "Error in getProfiles ",e);
        }
    }

    private TraderLyncUserInterest createInterest(TraderLyncUser traderLyncUser, String interestNode, String interestType, String nickname, String defaultInterest, String interestValue, boolean sharedLine, boolean useGateway)
    {
        Log.info( "["+ site.getName() + "] createInterest " + interestNode);

        TraderLyncInterest traderLyncInterest = null;

        if (traderLyncInterests.containsKey(interestNode))
        {
            traderLyncInterest = traderLyncInterests.get(interestNode);

        } else {

            traderLyncInterest = new TraderLyncInterest(interestNode);
            traderLyncInterests.put(interestNode, traderLyncInterest);
        }

        traderLyncInterest.setInterestType(interestType);
        traderLyncInterest.setSiteName(getName());
        traderLyncInterest.setInterestLabel(nickname);
        traderLyncInterest.setInterestValue(interestValue);

        traderLyncInterest.useGateway = useGateway;
        traderLyncInterest.isSharedLine = sharedLine;

        if (defaultInterest.equals("true"))
        {
            traderLyncUser.setDefaultInterest(traderLyncInterest);
        }

        TraderLyncUserInterest traderLyncUserInterest = traderLyncInterest.addUserInterest(traderLyncUser, defaultInterest);
        traderLyncUser.addInterest(traderLyncInterest);

        openlinkInterests.put(interestNode + traderLyncUser.getUserNo(), traderLyncUserInterest);

        createPubsubNode(interestNode + traderLyncUser.getUserNo());
        getInterestSubscriptions(traderLyncInterest, traderLyncUser.getUserNo());

        return traderLyncUserInterest;
    }

    private void createPeer(TraderLyncInterest traderLyncInterest, String peerUser)
    {
        TraderLyncUser peerTraderLyncUser = findOpenlinkProfile(peerUser);

        TraderLyncUserInterest peerUserInterest = traderLyncInterest.addUserInterest(peerTraderLyncUser, "false");
        peerTraderLyncUser.addInterest(traderLyncInterest);

        openlinkInterests.put(traderLyncInterest.getInterestId() + peerUser, peerUserInterest);
        createPubsubNode(traderLyncInterest.getInterestId() + peerUser);
        getInterestSubscriptions(traderLyncInterest, peerUser);
    }

    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------


    private String getUserNo(String email)
    {
        if (email != null)
        {
            int pos = email.indexOf("@");

            if ( pos > -1)
            {
                return email.substring(0, pos);

            } else {

                return email;
            }

        } else return null;
    }

    private String getTelVoiceNumber(Element vCard, String work, String voice)
    {
        String telVoiceNumber = null;

        for ( Iterator i = vCard.elementIterator( "TEL" ); i.hasNext(); )
        {
            Element tel = (Element) i.next();
            //Log.debug( "["+ site.getName() + "] getTelVoiceNumber - tel " + tel.asXML());

            if (tel.element(work) != null && tel.element(voice) != null)
            {
                Element number = tel.element("NUMBER");

                if (number != null)
                {
                    //Log.debug( "["+ site.getName() + "] getTelVoiceNumber - number " + number.getText());
                    telVoiceNumber = number.getText();
                    break;
                }
            }
        }

        return telVoiceNumber;
    }

    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------


    public void outgoingCallNotification(String requester, String callId, String dialDigits, TraderLyncUserInterest targetInterest, boolean disconnected)
    {
        requester = getUserNo(requester);

        Log.debug( "["+ site.getName() + "] outgoingCallNotification " + requester + " " + callId + " " + dialDigits + " " + disconnected);

        TraderLyncInterest callInterest = targetInterest.getInterest();
        String label = dialDigits;

        try {
            if (traderLyncInterests.containsKey(dialDigits))
            {
                label = traderLyncInterests.get(dialDigits).getInterestLabel();
            }

            Iterator<TraderLyncUserInterest> it4 = callInterest.getUserInterests().values().iterator();

            while( it4.hasNext() )
            {
                TraderLyncUserInterest userInterest = (TraderLyncUserInterest)it4.next();
                TraderLyncCall traderLyncCall = userInterest.getCallById(callId);
                boolean remove = false;

                if (requester.equals(userInterest.getUser().getUserNo()))
                {
                    if (traderLyncCall == null)
                    {
                        userInterest.handleCallOutgoing("CallOriginated", callId, dialDigits, label);

                    } else {

                        if (disconnected == false)
                        {
                            userInterest.handleCallOutgoing("CallDelivered", callId, dialDigits, label);

                        } else {
                            userInterest.handleConnectionCleared(callId);
                            remove = true;
                        }

                        publishTraderLyncUserCallEvent(userInterest);
                    }

                } else {

                    if (disconnected == false)
                    {
                        if (traderLyncCall == null)
                        {
                            userInterest.handleCallOutgoing("CallBusy", callId, dialDigits, label);
                            publishTraderLyncUserCallEvent(userInterest);
                        }
                    } else {
                        userInterest.handleConnectionCleared(callId);
                        remove = true;
                    }
                }

                if (remove) userInterest.removeCallById(callId);
            }

        } catch (Exception e) {

            Log.error( "["+ site.getName() + "] " +  "Error in outgoingCallNotification ", e);
        }
    }


    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------



    public synchronized void publishTraderLyncCallEvent(TraderLyncInterest traderLyncInterest)
    {
        if ((ClusterManager.isClusteringEnabled() && ClusterManager.isSeniorClusterMember()) || !ClusterManager.isClusteringEnabled())
        {
            Log.debug( "["+ site.getName() + "] publishTraderLyncCallEvent - interest " + traderLyncInterest.getInterestId());

            Iterator it = traderLyncInterest.getUserInterests().values().iterator();

            while( it.hasNext() )
            {
                TraderLyncUserInterest traderLyncUserInterest = (TraderLyncUserInterest)it.next();
                publishTraderLyncUserCallEvent(traderLyncUserInterest);
            }
        }
    }

    public synchronized void publishTraderLyncUserCallEvent(TraderLyncUserInterest traderLyncUserInterest)
    {
        if ((ClusterManager.isClusteringEnabled() && ClusterManager.isSeniorClusterMember()) || !ClusterManager.isClusteringEnabled())
        {
            Log.debug( "["+ site.getName() + "] publishTraderLyncUserCallEvent - user interest " + traderLyncUserInterest.getInterestName() + " enabled: " + traderLyncUserInterest.getUser().enabled());

            if (traderLyncUserInterest.getUser().enabled())
            {
                if (traderLyncUserInterest.canPublish(this))
                {
                    publishTraderLyncUserInterestEvent(traderLyncUserInterest.getInterest(), traderLyncUserInterest);
                }

                updateCacheContent(traderLyncUserInterest);
            }
        }
    }


    private void publishTraderLyncUserInterestEvent(TraderLyncInterest traderLyncInterest, TraderLyncUserInterest traderLyncUserInterest)
    {
        Log.debug( "["+ site.getName() + "] publishTraderLyncUserInterestEvent - scan user interest " + traderLyncUserInterest.getUser().getUserId() + " " + traderLyncUserInterest.getInterest().getInterestId());

        if (isUserOnline(traderLyncUserInterest.getUser()))
        {
            Log.debug( "["+ site.getName() + "] publishTraderLyncUserInterestEvent - publish user interest " + traderLyncUserInterest.getUser().getUserId() + " " + traderLyncUserInterest.getInterest().getInterestId());

            String interestNode = traderLyncInterest.getInterestId() + traderLyncUserInterest.getUser().getUserNo();

            IQ iq = new IQ(IQ.Type.set);
            iq.setFrom(getName() + "." + getDomain());
            iq.setTo("pubsub." + getDomain());
            Element pubsub = iq.setChildElement("pubsub", "http://jabber.org/protocol/pubsub");
            Element publish = pubsub.addElement("publish").addAttribute("node", interestNode);
            Element item = publish.addElement("item").addAttribute("id", interestNode);
            Element calls = item.addElement("callstatus", "http://xmpp.org/protocol/openlink:01:00:00#call-status");
            boolean busy = traderLyncUserInterest.getBusyStatus();
            calls.addAttribute("busy", busy ? "true" : "false");

            if ("true".equals(traderLyncUserInterest.getCallFWD()))
            {
                calls.addAttribute("fwd", traderLyncUserInterest.getCallFWDDigits());
            }

            addTraderLyncCallsEvents(traderLyncInterest, traderLyncUserInterest, calls);

            if (calls.nodeCount() > 0)
            {
                sendPacket(iq);
            }

            JID profileJID = new JID(traderLyncUserInterest.getUser().getUserNo() + "@" + getDomain() + "/traderlync");

            Session session = (LocalClientSession) server.getSessionManager().getSession(profileJID);

            if (session != null)
            {

            }
        }
    }


    private void updateCacheContent(TraderLyncUserInterest traderLyncUserInterest)
    {
        Log.debug( "["+ site.getName() + "] updateCacheContent - user interest " + traderLyncUserInterest.getInterestName());

        Iterator it2 = traderLyncUserInterest.getCalls().values().iterator();

        while( it2.hasNext() )
        {
            TraderLyncCall traderLyncCall = (TraderLyncCall)it2.next();
            //wireLynkPlugin.updateCacheContent(traderLyncUserInterest.getInterest(), traderLyncUserInterest, traderLyncCall);
        }
    }


    private void addTraderLyncCallsEvents(TraderLyncInterest traderLyncInterest, TraderLyncUserInterest traderLyncUserInterest, Element calls)
    {
        Log.debug( "["+ site.getName() + "] addTraderLyncCallsEvents - user interest " + traderLyncUserInterest.getInterestName());

        Iterator it2 = traderLyncUserInterest.getCalls().values().iterator();

        while( it2.hasNext() )
        {
            TraderLyncCall traderLyncCall = (TraderLyncCall)it2.next();

            if (!"Unknown".equals(traderLyncCall.getState()) && !traderLyncCall.deleted)
            {
                Element call = calls.addElement("call");
                addTraderLyncCallEvents(traderLyncInterest, traderLyncUserInterest, call, traderLyncCall);

                Log.debug( "["+ site.getName() + "] addTraderLyncCallsEvents - user interest call " + traderLyncCall.getState());
            }
        }
    }

    public synchronized void addTraderLyncCallEvents(TraderLyncInterest traderLyncInterest, TraderLyncUserInterest traderLyncUserInterest, Element call, TraderLyncCall traderLyncCall)
    {
        Log.debug( "["+ site.getName() + "] addTraderLyncCallEvents - user interest " + traderLyncUserInterest.getInterestName() + " " + traderLyncCall.getCallID() + " " + traderLyncCall.getState());

        call.addElement("id").setText(traderLyncCall.getCallID());
        call.addElement("profile").setText(traderLyncUserInterest.getUser().getProfileName());
        call.addElement("interest").setText(traderLyncUserInterest.getInterestName());
        call.addElement("changed").setText(traderLyncCall.getStatus());
        call.addElement("state").setText(traderLyncCall.getState());
        call.addElement("direction").setText(traderLyncCall.getDirection());

        Element caller = call.addElement("caller");
        caller.addElement("number").setText(traderLyncCall.getCallerNumber(traderLyncInterest.getInterestType()));
        caller.addElement("name").setText(traderLyncCall.getCallerName(traderLyncInterest.getInterestType()));

        Element called = call.addElement("called");
        called.addElement("number").setText(traderLyncCall.getCalledNumber(traderLyncInterest.getInterestType()));
        called.addElement("name").setText(traderLyncCall.getCalledName(traderLyncInterest.getInterestType()));

        call.addElement("duration").setText(String.valueOf(traderLyncCall.getDuration()));

        Element actions = call.addElement("actions");

        Iterator it4 = traderLyncCall.getValidActions().iterator();

        while( it4.hasNext() )
        {
            String action = (String)it4.next();
            actions.addElement(action);
        }

        Element features  = call.addElement("features");
        addFeature(features, "priv_1", "Y".equals(traderLyncCall.getPrivacy()) ? "true" : "false");
        addFeature(features, "hs_1",  "1".equals(traderLyncCall.getHandset()) ? "true" : "false");
        addFeature(features, "hs_2",  "2".equals(traderLyncCall.getHandset()) ? "true" : "false");

        if (traderLyncCall.alerted)
        {
            addFeature(features, "alert_1",  "true");
            traderLyncCall.alerted = false;
        }

        Element participants  = call.addElement("participants");

        Iterator it3 = traderLyncInterest.getUserInterests().values().iterator();

        while( it3.hasNext() )
        {
            TraderLyncUserInterest traderLyncParticipant = (TraderLyncUserInterest)it3.next();

            if (isUserOnline(traderLyncParticipant.getUser()))
            {
                TraderLyncCall participantCall = traderLyncParticipant.getCallByLine(traderLyncCall.getLine());

                if (participantCall != null)
                {
                    Element participant  = participants.addElement("participant");
                    participant.addAttribute("jid", traderLyncParticipant.getUser().getUserId() + "@" + getDomain());

                    participant.addAttribute("type", participantCall.getParticipation());
                    participant.addAttribute("direction", participantCall.getDirection());

                    if (participantCall.firstTimeStamp != 0)
                    {
                        participant.addAttribute("timestamp", String.valueOf(new Date(participantCall.firstTimeStamp)));
                    }
                }
            }
        }
    }


    private void addFeature(Element features, String id, String value)
    {
        Element feature = features.addElement("feature");
        feature.addAttribute("id", id);
        feature.setText(value);
    }

    public synchronized void publishTraderLyncUserDeviceEvent(TraderLyncUser traderLyncUser)
    {
        Log.debug( "["+ site.getName() + "] publishTraderLyncUserDeviceEvent - " + traderLyncUser.getUserId());

        if (isUserOnline(traderLyncUser))
        {
            TraderLyncInterest traderLyncInterest = traderLyncUser.getDefaultInterest();

            if (traderLyncInterest != null)
            {
                String interestNode = traderLyncInterest.getInterestId() + traderLyncUser.getUserNo();

                IQ iq = new IQ(IQ.Type.set);
                iq.setFrom(getName() + "." + getDomain());
                iq.setTo("pubsub." + getDomain());
                Element pubsub = iq.setChildElement("pubsub", "http://jabber.org/protocol/pubsub");
                Element publish = pubsub.addElement("publish").addAttribute("node", interestNode);
                Element item = publish.addElement("item").addAttribute("id", interestNode);
                Element device = item.addElement("devicestatus", "http://xmpp.org/protocol/openlink:01:00:00#device-status");

                Element features  = device.addElement("features");
                addFeature(features, "icom_1", traderLyncUser.intercom() ? "true" : "false");

                sendPacket(iq);
            }
        }
    }

    public void createPubsubNode(String interestNode)
    {
        //Log.debug("["+site.getName()+"] createPubsubNode - " + interestNode);

        String domain = getDomain();

        IQ iq1 = new IQ(IQ.Type.set);
        iq1.setFrom(getName() + "." + domain);
        iq1.setTo("pubsub." + domain);
        Element pubsub1 = iq1.setChildElement("pubsub", "http://jabber.org/protocol/pubsub");
        Element create = pubsub1.addElement("create").addAttribute("node", interestNode);

        Element configure = pubsub1.addElement("configure");
        Element x = configure.addElement("x", "jabber:x:data").addAttribute("type", "submit");

        Element field1 = x.addElement("field");
        field1.addAttribute("var", "FORM_TYPE");
        field1.addAttribute("type", "hidden");
        field1.addElement("value").setText("http://jabber.org/protocol/pubsub#node_config");

        //Element field2 = x.addElement("field");
        //field2.addAttribute("var", "pubsub#persist_items");
        //field2.addElement("value").setText("1");

        Element field3 = x.addElement("field");
        field3.addAttribute("var", "pubsub#max_items");
        field3.addElement("value").setText("1");

        Log.debug("createPubsubNode " + iq1.toString());
        sendPacket(iq1);
    }

    public void getInterestSubscriptions(TraderLyncInterest traderLyncInterest, String userNo)
    {
        String interestNode = traderLyncInterest.getInterestId() + userNo;
        String domain = getDomain();

        Log.debug("["+site.getName()+"] getInterestSubscriptions  - " + interestNode);

        IQ iq2 = new IQ(IQ.Type.get);
        iq2.setFrom(getName() + "." + domain);
        iq2.setTo("pubsub." + domain);
        Element pubsub2 = iq2.setChildElement("pubsub", "http://jabber.org/protocol/pubsub#owner");
        Element subscriptions = pubsub2.addElement("subscriptions").addAttribute("node", interestNode);

        Log.debug("subscriptions " + iq2.toString());
        sendPacket(iq2);
    }

    class RosterItemComparator implements Comparator<RosterItem>
    {
        public int compare(RosterItem itemA, RosterItem itemB)
        {
            return itemA.getJid().toBareJID().compareTo(itemB.getJid().toBareJID());
        }
    }

    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------
    /**
     *
     *
     */
    private void sendMeetEvent(JID roomJID, String event, JSONObject json)
    {
        String nodeName = roomJID.getNode();
        JID jid = new JID(getName() + "." + getDomain());

        IQ iq = new IQ(IQ.Type.set);
        iq.setFrom(jid);
        iq.setTo("pubsub." + getDomain());
        Element pubsub = iq.setChildElement("pubsub", "http://jabber.org/protocol/pubsub");
        Element publish = pubsub.addElement("publish").addAttribute("node", nodeName);
        Element item = publish.addElement("item").addAttribute("id", nodeName);
        Element meet = item.addElement("meet", "http://xmpp.org/protocol/openlink:01:00:00#meet");

        json.put("event", event);
        meet.addAttribute("event", event);

        json.put("muc", roomJID.toString());
        meet.addAttribute("muc", roomJID.toString());

        meet.setText(json.toString());
        sendPacket(iq);
    }
    /**
     *
     *
     */
    public void roomCreated(JID roomJID)
    {
        Log.debug("TraderLyncPlugin roomCreated " + roomJID);

        createPubsubNode(roomJID.getNode());
        sendMeetEvent(roomJID, "room_created", new JSONObject());
    }
    /**
     *
     *
     */
    public void roomDestroyed(JID roomJID)
    {
        Log.debug("TraderLyncPlugin roomDestroyed " + roomJID);
        sendMeetEvent(roomJID, "room_destroyed", new JSONObject());
    }

    /**
     *
     *
     */
    public void occupantJoined(final JID roomJID, JID user, String nickname)
    {
        Log.debug("TraderLyncPlugin occupantJoined " + roomJID + " " + user + " " + nickname);

        JSONObject json = new JSONObject();
        json.put("user", user.toString());
        json.put("id", nickname);

        JSONObject vbJson = getVideoBridgeData(roomJID.getNode());
        if (vbJson != null) json.put("media", vbJson);

        sendMeetEvent(roomJID, "user_joined", json);

        final String roomName = roomJID.getNode();
    }
    /**
     *
     *
     */
    private JSONObject getVideoBridgeData(String roomName)
    {
        JSONObject json = new JSONObject();
        return json;
    }

    /**
     *
     *
     */
    public void occupantLeft(final JID roomJID, JID user)
    {
        Log.debug("TraderLyncPlugin occupantLeft " + roomJID + " " + user);

        JSONObject json = new JSONObject();
        json.put("user", user.toString());

        JSONObject vbJson = getVideoBridgeData(roomJID.getNode());
        if (vbJson != null) json.put("media", vbJson);

        sendMeetEvent(roomJID, "user_left", json);
    }
    /**
     *
     *
     */
    public void nicknameChanged(JID roomJID, JID user, String oldNickname, String newNickname)
    {
        Log.debug("TraderLyncPlugin nicknameChanged " + roomJID + " " + user+ " " + oldNickname + " " + newNickname);

        JSONObject json = new JSONObject();
        json.put("user", user.toString());
        json.put("old", oldNickname);
        json.put("new", newNickname);
        sendMeetEvent(roomJID, "id_changed", json);
    }
    /**
     *
     *
     */
    public void messageReceived(JID roomJID, JID user, String nickname, Message message)
    {
        Log.debug("TraderLyncPlugin messageReceived " + roomJID + " " + user + " " + nickname + " " + message);

        JSONObject json = new JSONObject();
        json.put("user", user.toString());
        json.put("id", nickname);

        JSONObject messageJSON = new JSONObject();

        messageJSON.put("from", message.getFrom().toString());
        messageJSON.put("to",   message.getTo().toString());
        messageJSON.put("type",     message.getType().toString());
        messageJSON.put("date", dateFormat.format(new Date()));
        messageJSON.put("body", message.getBody());
        messageJSON.put("subject", message.getSubject());
        messageJSON.put("thread", message.getThread());

        json.put("message", messageJSON);
        sendMeetEvent(roomJID, "message_recieved", json);
    }
    /**
     *
     *
     */
    public void roomSubjectChanged(JID roomJID, JID user, String newSubject)
    {
        Log.debug("TraderLyncPlugin roomSubjectChanged " + roomJID + " " + user + " " + newSubject);

        JSONObject json = new JSONObject();
        if (user != null) json.put("user", user.toString());
        json.put("subject", newSubject);
        sendMeetEvent(roomJID, "subject_changed", json);
    }
    /**
     *
     *
     */
    public void privateMessageRecieved(JID a, JID b, Message message)
    {
        Log.debug("TraderLyncPlugin privateMessageRecieved " + a + " " + b + " " + message);

        JSONObject json = new JSONObject();
        json.put("from", a.toString());
        json.put("to", b.toString());

        JSONObject messageJSON = new JSONObject();

        messageJSON.put("from", message.getFrom().toString());
        messageJSON.put("to",   message.getTo().toString());
        messageJSON.put("type",     message.getType().toString());
        messageJSON.put("date", dateFormat.format(new Date()));
        messageJSON.put("body", message.getBody());
        messageJSON.put("subject", message.getSubject());
        messageJSON.put("thread", message.getThread());

        json.put("message", messageJSON);
        sendMeetEvent(new JID(a.toBareJID()), "private_message_recieved", json);
    }
    //-------------------------------------------------------
    //
    //
    //
    //-------------------------------------------------------
    /**
     *
     *
     */
    private String processMeetAction(Element newCommand, JID userJID, JID meetingJID, String action, JSONObject payload)
    {
        Log.debug("TraderLyncPlugin processMeetAction " + userJID + " " + action + "\n" + payload);

        String errorMessage = null;

        if ("find_users, list_usergroups, add_user, delete_user, enable_user, disable_user, update_user, get_user".contains(action))
        {
            return processUserAction(newCommand, userJID, meetingJID, action, payload);
        }
        else

        if ("list_members, list_groups, maint_group, delete_group, get_group".contains(action))
        {
            return processGroupAction(newCommand, userJID, meetingJID, action, payload);
        }
        else

        if ("list_friends, add_friendship, update_friendship, delete_friendship".contains(action))
        {
            return processRosterAction(newCommand, userJID, meetingJID, action, payload);
        }
        else

        if ("search_history".contains(action))
        {
            return processSearchAction(newCommand, userJID, meetingJID, action, payload);
        }
        else

        if ("list_rooms, get_room, maint_room, delete_room".contains(action))
        {
            return processRoomAction(newCommand, userJID, meetingJID, action, payload);
        }

        else

        if ("list_bookmarks, get_bookmark, maint_bookmark, delete_bookmark".contains(action))
        {
            return processBookmarkAction(newCommand, userJID, meetingJID, action, payload);
        }
        else {
            return "unknown action " + action;
        }
    }


    private boolean isNull(String value)
    {
        return (value == null || "undefined".equals(value)  || "null".equals(value) || "".equals(value));
    }

    private String removeNull(String s)
    {
        if (s == null) {
            return "";
        }

        return s.trim();
    }

    private String jsonGetString(JSONObject json, String key)
    {
        String value = null;

        if (json.has(key)) value = json.getString(key);
        return value;
    }

    private JSONObject jsonGetObject(JSONObject json, String key)
    {
        JSONObject value = null;

        if (json.has(key)) value = json.getJSONObject(key);
        return value;
    }
    /**
     *
     *
     */
    private String processBookmarkAction(Element newCommand, JID userJID, JID meetingJID, String action, JSONObject json)
    {
        try {
            if ("list_bookmarks".equals(action))
            {
                JSONArray bookmarksJSON = new JSONArray();
                int i = 0;

                final Collection<Bookmark> bookmarks = BookmarkManager.getBookmarks();

                for (Bookmark bookmark : bookmarks)
                {
                    JSONObject bookmarkJSON = getJsonFromBookmark(bookmark);
                    bookmarksJSON.put(i++, bookmarkJSON);
                }

                addMeetExtension(newCommand, bookmarksJSON);
            }
            else

            if ("get_bookmark".equals(action))
            {
                try {
                    Bookmark bookmark = new Bookmark(Long.parseLong(jsonGetString(json, "id")));
                    addMeetExtension(newCommand, getJsonFromBookmark(bookmark));
                }
                catch (Exception e) {
                    return "Bookmark not found, " + e;
                }
            }
            else

            if ("maint_bookmark".equals(action))
            {
                return maintBookmark(json);
            }
            else

            if ("delete_bookmark".equals(action))
            {
                try {
                    BookmarkManager.deleteBookmark(Long.parseLong(jsonGetString(json, "id")));
                }
                catch (Exception e) {
                    return "Bookmark not found, " + e;
                }
            }

            return null;

        } catch (Exception e) {
            return "Bad json input " + e;
        }
    }

    /**
     *
     *
     */
    private String processRoomAction(Element newCommand, JID userJID, JID meetingJID, String action, JSONObject json)
    {
        try {
            if ("list_rooms".equals(action))
            {
                String serviceName = jsonGetString(json, "service_name");
                String channelType = jsonGetString(json, "channel_type");
                String roomSearch = jsonGetString(json, "room_search");
                String roomName = jsonGetString(json, "room_name");
                String roomOwner = jsonGetString(json, "room_owner");

                JSONArray roomsJSON = new JSONArray();
                int index = 0;

                if (isNull(channelType)) channelType = "all";

                List<MUCRoom> rooms = server.getMultiUserChatManager().getMultiUserChatService(serviceName).getChatRooms();

                for (MUCRoom chatRoom : rooms)
                {
                    if (isNull(roomSearch) == false) {
                        if (!chatRoom.getName().contains(roomSearch)) {
                            continue;
                        }
                    }

                    if (channelType.equals("all") || (channelType.equals("public") && chatRoom.isPublicRoom()))
                    {
                        roomsJSON.put(index++, getJsonFromRoomXml(chatRoom));
                    }
                }
                addMeetExtension(newCommand, roomsJSON);
            }
            else

            if ("get_room".equals(action))
            {
                String serviceName = jsonGetString(json, "service_name");
                String roomName = jsonGetString(json, "room_name");

                MUCRoom chatRoom = server.getMultiUserChatManager().getMultiUserChatService(serviceName).getChatRoom(roomName);

                if (chatRoom == null)
                {
                    return "Room not found";
                }

                addMeetExtension(newCommand, getJsonFromRoomXml(chatRoom));
            }
            else

            if ("maint_room".equals(action))
            {
                createRoom(json);
            }
            else

            if ("delete_room".equals(action))
            {
                String serviceName = jsonGetString(json, "service_name");
                String roomName = jsonGetString(json, "room_name");

                MUCRoom chatRoom = server.getMultiUserChatManager().getMultiUserChatService(serviceName).getChatRoom(roomName);

                if (chatRoom != null) {
                    chatRoom.destroyRoom(null, null);
                } else {
                    return "Room not found";
                }
            }

            return null;

        } catch (Exception e) {
            return "Bad json input " + e;
        }
    }
    /**
     *
     *
     */
    private String processSearchAction(Element newCommand, JID userJID, JID meetingJID, String action, JSONObject json)
    {
        try {
            return searchHistory(newCommand, json);

        } catch (Exception e) {
            return "Bad json input " + e;
        }
    }

    /**
     *
     *
     */
    private String processGroupAction(Element newCommand, JID userJID, JID meetingJID, String action, JSONObject json)
    {
        try {
            String groupname = jsonGetString(json, "groupname");
;
            if ("list_members".equals(action))
            {
                if (isNull(groupname) == false)
                {
                    Group group = GroupManager.getInstance().getGroup(groupname);

                    if (group != null)
                    {
                        JSONArray membersJSON = new JSONArray();
                        int i = 0;

                        for (JID memberJID : group.getMembers())
                        {
                            JSONObject memberJSON = new JSONObject();
                            memberJSON.put("jid", memberJID.toString());
                            memberJSON.put("name", memberJID.getNode());

                            membersJSON.put(i++, memberJSON);
                        }

                        addMeetExtension(newCommand, membersJSON);
                    }
                    else
                        return "group " + groupname + " not found";

                } else {
                    return "groupname not specified";
                }

            }
            else

            if ("list_groups".equals(action))
            {
                Collection<Group> groups = GroupManager.getInstance().getGroups();
                JSONArray groupsJSON = new JSONArray();
                int index = 0;

                for(Group group : groups)
                {
                    groupsJSON.put(index++, getJsonFromGroupXml(group.getName()));
                }

                addMeetExtension(newCommand, groupsJSON);
            }
            else

            if ("maint_group".equals(action))
            {
                return maintGroup(newCommand, json);
            }
            else

            if ("delete_group".equals(action))
            {
                if (isNull(groupname) == false)
                {
                    Group group = GroupManager.getInstance().getGroup(groupname);

                    if (group != null)
                    {
                        GroupManager.getInstance().deleteGroup(group);
                    }
                    else
                        return "group " + groupname + " not found";

                } else {
                    return "groupname not specified";
                }
            }
            else

            if ("get_group".equals(action))
            {
                if (isNull(groupname) == false)
                {
                    Group group = GroupManager.getInstance().getGroup(groupname);

                    if (group != null)
                    {
                        addMeetExtension(newCommand, getJsonFromGroupXml(groupname));
                    }
                    else
                        return "group " + groupname + " not found";

                } else {
                    return "groupname not specified";
                }
            }

            return null;

        } catch (Exception e) {
            return "Bad json input " + e;
        }
    }

    /**
     *
     *
     */
    private String processRosterAction(Element newCommand, JID userJID, JID meetingJID, String action, JSONObject json)
    {
        try {
            String username = jsonGetString(json, "username");
            username = username.trim().toLowerCase();
            username = JID.escapeNode(username);

            String password = jsonGetString(json, "password");
            String name = jsonGetString(json, "name");
            String item_jid = jsonGetString(json, "item_jid");
            String sub = jsonGetString(json, "subscription");
            String groupNames = jsonGetString(json, "groups");

            if ((action.equals("add_roster") || action.equals("update_roster") || action.equals("delete_roster")) &&
                (isNull(item_jid) || !(isNull(sub) || sub.equals("-1") || sub.equals("0") ||
                sub.equals("1") || sub.equals("2") || sub.equals("3"))))
            {
                return "Invalid parameters";
            }

            if ("add_friendship".equals(action))
            {
                addRosterItem(username, item_jid, name, sub, groupNames);
            }
            else

            if ("update_friendship".equals(action))
            {
                updateRosterItem(username, item_jid, name, sub, groupNames);
            }
            else

            if ("delete_friendship".equals(action))
            {
                deleteRosterItem(username, item_jid);
            }
            else

            if ("list_friends".equals(action))
            {
                Roster roster = rosterManager.getRoster(username);
                List<RosterItem> rosterItems = new ArrayList<RosterItem>(roster.getRosterItems());
                Collections.sort(rosterItems, new RosterItemComparator());

                JSONArray rosterJSON = new JSONArray();
                int i = 0;

                for (RosterItem item : rosterItems)
                {
                    JSONObject rosterItemJSON = new JSONObject();

                    rosterItemJSON.put("askStatus", item.getAskStatus());
                    rosterItemJSON.put("recvStatus", item.getRecvStatus());
                    rosterItemJSON.put("subStatus", item.getSubStatus());

                    List<String> groups = item.getGroups();

                    StringBuilder sb = new StringBuilder();

                    for (String s : item.getGroups())
                    {
                        sb.append(s);
                        sb.append(",");
                    }

                    rosterItemJSON.put("groups", sb.toString());
                    rosterItemJSON.put("name", item.getNickname());
                    rosterItemJSON.put("jid", item.getJid().toString());

                    rosterJSON.put(i++, rosterItemJSON);
                }
                addMeetExtension(newCommand, rosterJSON);
            }

            return null;

        } catch (Exception e) {
            return "Bad json input " + e;
        }
    }

    /**
     *
     *
     */
    private String processUserAction(Element newCommand, JID userJID, JID meetingJID, String action, JSONObject json)
    {
        String userId = userJID.getNode();

        try {
            String username = jsonGetString(json, "username");

            if (isNull(username))
            {
                return "username is not specified";
            }

            username = username.trim().toLowerCase();
            username = JID.escapeNode(username);

            if ("add_user, update_user".contains(action))
            {
                String password = jsonGetString(json, "password");
                String name = jsonGetString(json, "name");
                String email = jsonGetString(json, "email");
                String groupNames = jsonGetString(json, "groups");
                JSONObject properties = jsonGetObject(json, "properties");

                if ("add_user".equals(action))
                    createUser(username, password, name, email, groupNames, properties);
                else
                    updateUser(username, password, name, email, groupNames, properties);
            }
            else

            if ("delete_user".contains(action))
            {
                deleteUser(username);
            }
            else

            if ("enable_user".contains(action))
            {
                enableUser(username);
            }
            else

            if ("disable_user".contains(action))
            {
                deleteUser(username);
            }
            else

            if ("get_user".contains(action))
            {
                return getUserJson(newCommand, username);
            }
            else

            if ("find_users".contains(action))
            {
                String startindex = jsonGetString(json, "start");
                String maximium = jsonGetString(json, "range");

                String name = jsonGetString(json, "name");
                String email = jsonGetString(json, "email");
                JSONObject properties = jsonGetObject(json, "properties");

                listUsers(newCommand, username, startindex, maximium, name, email, properties);
            }
            else

            if ("list_usergroups".contains(action))
            {
                User user = getUser(username);
                Collection<Group> groups = GroupManager.getInstance().getGroups(user);
                JSONArray groupsJSON = new JSONArray();
                int index = 0;

                for(Group group : groups)
                {
                    groupsJSON.put(index++, getJsonFromGroupXml(group.getName()));
                }

                addMeetExtension(newCommand, groupsJSON);
            }
            return null;

        } catch (Exception e) {
            return "Bad json input " + e;
        }
    }
    /**
     *
     *
     */
    private String getUserJson(Element newCommand, String username)
    {
        try {
            User user = userManager.getUser(username);

            JSONObject userJSON = new JSONObject();

            userJSON.put("username", JID.unescapeNode(user.getUsername()));
            userJSON.put("name", user.isNameVisible() ? removeNull(user.getName()) : "");
            userJSON.put("email", user.isEmailVisible() ? removeNull(user.getEmail()) : "");

            for(Map.Entry<String, String> props : user.getProperties().entrySet())
            {
                userJSON.put(props.getKey(), props.getValue());
            }

            addMeetExtension(newCommand, userJSON);
            return null;

        } catch (Exception e) {
            return "Bad json input " + e;
        }
    }
    /**
     * Returns the the requested user or <tt>null</tt> if there are any
     * problems that don't throw an error.
     *
     * @param username the username of the local user to retrieve.
     * @return the requested user.
     * @throws UserNotFoundException if the requested user
     *         does not exist in the local server.
     */
    private User getUser(String username)
    {
        User xmppUser = null;
        try
        {
            xmppUser = userManager.getUser(JID.escapeNode(username));
        }
        catch ( UserNotFoundException e )
        {
            Log.debug( "getUser - Not a recognized user.", e );
        }
        return xmppUser;
    }
    /**
     *
     *
     */
    private void listUsers(Element newCommand, String username, String startindex, String maximium, String name, String email, JSONObject propertiesJSON)
    {
        int startIndex = 0;
        Collection<User> foundUsers = new ArrayList<User>();

        if (isNull(startindex) == false)
        {
            startIndex = Integer.parseInt(startindex);
        }

        int max = -1;

        if (isNull(maximium) == false)
        {
            max = Integer.parseInt(maximium);
        }

        if (isNull(username) == false)
        {
            if (max >= 0) {
                foundUsers.addAll(userManager.findUsers(new HashSet<String>(Arrays.asList("Username")), "%" + username + "%", startIndex, max));
            } else {
                foundUsers.addAll(userManager.findUsers(new HashSet<String>(Arrays.asList("Username")), "%" + username + "%"));
            }
        }

        if (isNull(name) == false)
        {
            if (max >= 0) {
                foundUsers.addAll(userManager.findUsers(new HashSet<String>(Arrays.asList("Name")), "%" + name + "%", startIndex, max));
            } else {
                foundUsers.addAll(userManager.findUsers(new HashSet<String>(Arrays.asList("Name")), "%" + name + "%"));
            }
        }

        if (isNull(email) == false)
        {
            if (max >= 0) {
                foundUsers.addAll(userManager.findUsers(new HashSet<String>(Arrays.asList("Email")), "%" + email + "%", startIndex, max));
            } else {
                foundUsers.addAll(userManager.findUsers(new HashSet<String>(Arrays.asList("Email")), "%" + email + "%"));
            }
        }

        if (propertiesJSON != null)
        {
            Iterator<?> keys = propertiesJSON.keys();

            while( keys.hasNext() )
            {
                String key = (String)keys.next();
                String value = propertiesJSON.getString(key);

                if (max >= 0) {
                    foundUsers.addAll(getUsersByProperty(key, value, startIndex, max));
                } else {
                    foundUsers.addAll(getUsersByProperty(key, value, 0, 0));
                }
            }
        }

        JSONArray usersJSON = new JSONArray();
        int index = 0;

        for (User user : foundUsers)
        {
            if (user != null) {

                JSONObject userJSON = new JSONObject();
                userJSON.put("username", JID.unescapeNode(user.getUsername()));
                userJSON.put("name", user.isNameVisible() ? removeNull(user.getName()) : "");
                userJSON.put("email", user.isEmailVisible() ? removeNull(user.getEmail()) : "");

                for(Map.Entry<String, String> props : user.getProperties().entrySet())
                {
                    userJSON.put(props.getKey(), props.getValue());
                }

                usersJSON.put(index++, userJSON);
            }
        }

        addMeetExtension(newCommand, usersJSON);
    }
    /**
     *
     *
     */
    private void addMeetExtension(Element newCommand, Object json)
    {
        Element iodata = newCommand.addElement("iodata", "urn:xmpp:tmp:io-data");
        iodata.addAttribute("type","output");
        Element childElement = iodata.addElement("out").addElement("meet", "http://xmpp.org/protocol/openlink:01:00:00#meet");
        childElement.setText(json.toString());
    }

    /**
     *
     *
     */
    private void createUser(String username, String password, String name, String email, String groupNames, JSONObject propertiesJSON) throws UserAlreadyExistsException, GroupAlreadyExistsException, UserNotFoundException, GroupNotFoundException
    {
        userManager.createUser(username, password, name, email);
        User user = userManager.getUser(username);

        if (propertiesJSON != null)
        {
            Iterator<?> keys = propertiesJSON.keys();

            while( keys.hasNext() )
            {
                String key = (String)keys.next();
                String value = propertiesJSON.getString(key);

                user.getProperties().put(key, value);
            }
        }

        if (isNull(groupNames) == false) {
            Collection<Group> groups = new ArrayList<Group>();
            StringTokenizer tkn = new StringTokenizer(groupNames, ",");

            while (tkn.hasMoreTokens())
            {
                String groupName = tkn.nextToken();
                Group group = null;

                try {
                    group = GroupManager.getInstance().getGroup(groupName);
                } catch (GroupNotFoundException e) {
                    // Create this group                    ;
                    group = GroupManager.getInstance().createGroup(groupName);
                    group.getProperties().put("sharedRoster.showInRoster", "onlyGroup");
                    group.getProperties().put("sharedRoster.displayName", groupName);
                    group.getProperties().put("sharedRoster.groupList", "");
                }
                groups.add(group);
            }
            for (Group group : groups) {
                group.getMembers().add(server.createJID(username, null));
            }
        }
    }

    /**
     *
     *
     */
    private void deleteUser(String username) throws UserNotFoundException, SharedGroupException
    {
        User user = getUser(username);
        userManager.deleteUser(user);

        rosterManager.deleteRoster(server.createJID(username, null));
    }

    /**
     * Lock Out on a given username
     *
     * @param username the username of the local user to disable.
     * @throws UserNotFoundException if the requested user
     *         does not exist in the local server.
     */
    private void disableUser(String username) throws UserNotFoundException
    {
        User user = getUser(username);
        LockOutManager.getInstance().disableAccount(username, null, null);
    }

    /**
     * Remove the lockout on a given username
     *
     * @param username the username of the local user to enable.
     * @throws UserNotFoundException if the requested user
     *         does not exist in the local server.
     */
    private void enableUser(String username) throws UserNotFoundException
    {
        User user = getUser(username);
        LockOutManager.getInstance().enableAccount(username);
    }

    /**
     *
     *
     */
    private void updateUser(String username, String password, String name, String email, String groupNames, JSONObject propertiesJSON)
            throws UserNotFoundException, GroupAlreadyExistsException
    {
        User user = getUser(username);

        if (isNull(password) == false) user.setPassword(password);
        if (isNull(name) == false) user.setName(name);
        if (isNull(email) == false) user.setEmail(email);

        if (propertiesJSON != null)
        {
            Iterator<?> keys = propertiesJSON.keys();

            while( keys.hasNext() )
            {
                String key = (String)keys.next();
                String value = propertiesJSON.getString(key);

                user.getProperties().put(key, value);
            }
        }

        if (isNull(groupNames) == false) {
            Collection<Group> newGroups = new ArrayList<Group>();
            StringTokenizer tkn = new StringTokenizer(groupNames, ",");

            while (tkn.hasMoreTokens())
            {
                String groupName = tkn.nextToken();
                Group group = null;

                try {
                    group = GroupManager.getInstance().getGroup(groupName);
                } catch (GroupNotFoundException e) {
                    // Create this group                    ;
                    group = GroupManager.getInstance().createGroup(groupName);
                    group.getProperties().put("sharedRoster.showInRoster", "onlyGroup");
                    group.getProperties().put("sharedRoster.displayName", groupName);
                    group.getProperties().put("sharedRoster.groupList", "");
                }

                newGroups.add(group);
            }

            Collection<Group> existingGroups = GroupManager.getInstance().getGroups(user);
            // Get the list of groups to add to the user
            Collection<Group> groupsToAdd =  new ArrayList<Group>(newGroups);
            groupsToAdd.removeAll(existingGroups);
            // Get the list of groups to remove from the user
            Collection<Group> groupsToDelete =  new ArrayList<Group>(existingGroups);
            groupsToDelete.removeAll(newGroups);

            // Add the user to the new groups
            for (Group group : groupsToAdd) {
                group.getMembers().add(server.createJID(username, null));
            }
            // Remove the user from the old groups
            for (Group group : groupsToDelete) {
                group.getMembers().remove(server.createJID(username, null));
            }
        }
    }
    /**
     * Add new roster item for specified user
     *
     * @param username the username of the local user to add roster item to.
     * @param itemJID the JID of the roster item to be added.
     * @param itemName the nickname of the roster item.
     * @param subscription the type of subscription of the roster item. Possible values are: -1(remove), 0(none), 1(to), 2(from), 3(both).
     * @param groupNames the name of a group to place contact into.
     * @throws UserNotFoundException if the user does not exist in the local server.
     * @throws UserAlreadyExistsException if roster item with the same JID already exists.
     * @throws SharedGroupException if roster item cannot be added to a shared group.
     */
    private void addRosterItem(String username, String itemJID, String itemName, String subscription, String groupNames) throws UserNotFoundException, UserAlreadyExistsException, SharedGroupException
    {
        getUser(username);
        Roster r = rosterManager.getRoster(username);
        JID j = new JID(itemJID);

        try {
            r.getRosterItem(j);
            throw new UserAlreadyExistsException(j.toBareJID());
        }
        catch (UserNotFoundException e) {
            //Roster item does not exist. Try to add it.
        }

        if (r != null) {
            List<String> groups = new ArrayList<String>();
            if (groupNames != null) {
                StringTokenizer tkn = new StringTokenizer(groupNames, ",");
                while (tkn.hasMoreTokens()) {
                    groups.add(tkn.nextToken());
                }
            }
            RosterItem ri = r.createRosterItem(j, itemName, groups, false, true);
            if (subscription == null) {
                subscription = "0";
            }
            ri.setSubStatus(RosterItem.SubType.getTypeFromInt(Integer.parseInt(subscription)));
            r.updateRosterItem(ri);
        }
    }

    /**
     * Update roster item for specified user
     *
     * @param username the username of the local user to update roster item for.
     * @param itemJID the JID of the roster item to be updated.
     * @param itemName the nickname of the roster item.
     * @param subscription the type of subscription of the roster item. Possible values are: -1(remove), 0(none), 1(to), 2(from), 3(both).
     * @param groupNames the name of a group.
     * @throws UserNotFoundException if the user does not exist in the local server or roster item does not exist.
     * @throws SharedGroupException if roster item cannot be added to a shared group.
     */
    private void updateRosterItem(String username, String itemJID, String itemName, String subscription, String groupNames) throws UserNotFoundException, SharedGroupException
    {
        getUser(username);
        Roster r = rosterManager.getRoster(username);
        JID j = new JID(itemJID);

        RosterItem ri = r.getRosterItem(j);

        List<String> groups = new ArrayList<String>();
        if (groupNames != null) {
            StringTokenizer tkn = new StringTokenizer(groupNames, ",");
            while (tkn.hasMoreTokens()) {
                groups.add(tkn.nextToken());
            }
        }

        ri.setGroups(groups);
        ri.setNickname(itemName);

        if (subscription == null) {
            subscription = "0";
        }
        ri.setSubStatus(RosterItem.SubType.getTypeFromInt(Integer.parseInt(subscription)));
        r.updateRosterItem(ri);
    }

    /**
     * Delete roster item for specified user. No error returns if nothing to delete.
     *
     * @param username the username of the local user to add roster item to.
     * @param itemJID the JID of the roster item to be deleted.
     * @throws UserNotFoundException if the user does not exist in the local server.
     * @throws SharedGroupException if roster item cannot be deleted from a shared group.
     */
    private void deleteRosterItem(String username, String itemJID) throws UserNotFoundException, SharedGroupException
    {
        getUser(username);
        Roster r = rosterManager.getRoster(username);
        JID j = new JID(itemJID);

        // No roster item is found. Uncomment the following line to throw UserNotFoundException.
        //r.getRosterItem(j);

        r.deleteRosterItem(j, true);
    }
    /**
     * Creates/Updates a workgroup
     *
     * @param Element
     *            the workgroup details
     */
    private String maintGroup(Element newCommand, JSONObject json)
    {
        String errorMessage = null;

        String groupname = jsonGetString(json, "groupname");
        String displayName = jsonGetString(json, "display_name");
        String description = jsonGetString(json, "group_description");
        String showInRoster = jsonGetString(json, "show_in_roster");
        String members = jsonGetString(json, "group_users");
        String admins = jsonGetString(json, "group_admins");
        String groupList = jsonGetString(json, "group_list");
        String properties = jsonGetString(json, "properties");

        if (isNull(groupname)) errorMessage = "group name is missing";
        if (isNull(displayName)) errorMessage = "display name is missing";
        if (isNull(members)) errorMessage = "list of user members is missing";
        if (isNull(showInRoster)) errorMessage = "show in roster rule is missing";
        if (isNull(description)) errorMessage = "description is missing";

        if (errorMessage == null)
        {
            if (GroupManager.getInstance().isReadOnly())
            {
                return "Groups are read only";
            }

            Group group = null;

            try {
                group = GroupManager.getInstance().createGroup(groupname);
            } catch (GroupAlreadyExistsException e) {

                try {
                    group = GroupManager.getInstance().getGroup(groupname);
                } catch (Exception e2) {
                    return "error adding users to groups";
                }
            }

            group.setDescription(description);
            StringTokenizer tkn1 = new StringTokenizer(members, ",");

            Collection<JID> users = group.getMembers();

            while (tkn1.hasMoreTokens())
            {
                String user = tkn1.nextToken();
                try {
                    users.add(new JID(user));
                } catch (Exception e) {
                    return "error adding users to groups";
                }
            }

            if ("nobody".equals(showInRoster))
            {
                group.getProperties().put("sharedRoster.showInRoster", "nobody");
                group.getProperties().put("sharedRoster.displayName", " ");
                group.getProperties().put("sharedRoster.groupList", " ");
            }
            else {
                if (isNull(groupList) == false) {
                    showInRoster = "onlyGroup";
                }
                group.getProperties().put("sharedRoster.showInRoster", showInRoster);
                group.getProperties().put("sharedRoster.displayName", displayName);

                if (isNull(groupList) == false)
                {
                    group.getProperties().put("sharedRoster.groupList", groupList);
                } else {
                    group.getProperties().put("sharedRoster.groupList", " ");
                }
            }

            if (isNull(properties) == false)
            {
                JSONObject propertiesJSON = new JSONObject(JID.unescapeNode(properties.trim()));

                if (propertiesJSON != null)
                {
                    Iterator<?> keys = propertiesJSON.keys();

                    while( keys.hasNext() )
                    {
                        String key = (String)keys.next();
                        String value = propertiesJSON.getString(key);

                        group.getProperties().put(key, value);
                    }
                }
            }
        }
        return errorMessage;
    }

    private JSONObject getJsonFromGroupXml(String groupname)
    {
        JSONObject groupJSON = new JSONObject();

        try {
            Group group = GroupManager.getInstance().getGroup(groupname);

            boolean isSharedGroup = RosterManager.isSharedGroup(group);
            Map<String, String> properties = group.getProperties();
            String showInRoster = (isSharedGroup ? properties.get("sharedRoster.showInRoster") : "");

            groupJSON.put("name", group.getName());
            groupJSON.put("desc", group.getDescription());
            groupJSON.put("count", group.getMembers().size() + group.getAdmins().size());
            groupJSON.put("shared", String.valueOf(isSharedGroup));
            groupJSON.put("display", (isSharedGroup ? properties.get("sharedRoster.displayName") : ""));
            groupJSON.put("specified_groups", String.valueOf("onlyGroup".equals(showInRoster) && properties.get("sharedRoster.groupList").trim().length() > 0));
            groupJSON.put("visibility", showInRoster);
            groupJSON.put("groups", (isSharedGroup ? properties.get("sharedRoster.groupList") : ""));

            for(Map.Entry<String, String> props : properties.entrySet())
            {
                groupJSON.put(props.getKey(), props.getValue());
            }

            JSONArray membersJSON = new JSONArray();
            JSONArray adminsJSON = new JSONArray();
            int i = 0;

            for (JID memberJID : group.getMembers())
            {
                JSONObject memberJSON = new JSONObject();
                memberJSON.put("jid", memberJID.toString());
                memberJSON.put("name", memberJID.getNode());
                membersJSON.put(i++, memberJSON);
            }

            groupJSON.put("members", membersJSON);
            i = 0;

            for (JID memberJID : group.getAdmins())
            {
                JSONObject adminJSON = new JSONObject();
                adminJSON.put("jid", memberJID.toString());
                adminJSON.put("name", memberJID.getNode());
                adminsJSON.put(i++, adminJSON);
            }
            groupJSON.put("admins", adminsJSON);

        } catch (Exception e) {
            Log.error("getJsonFromGroupXml", e);
        }

        return groupJSON;
    }

    /**
     * Searches chat history
     *
     * @param Element
     *            the search parameters
     */
    private String searchHistory(Element newCommand, JSONObject json)
    {
        String errorMessage = null;
        JSONArray conversationsJSON = new JSONArray();

        /*
        try {
            Collection<Conversation> conversations = null;

            String query = jsonGetString(json, "keywords");
            String participant1 = jsonGetString(json, "from");
            String participant2 = jsonGetString(json, "to");
            String startDate = jsonGetString(json, "start_date");
            String endDate = jsonGetString(json, "end_date");
            String roomName = jsonGetString(json, "room_name");
            String serviceName = jsonGetString(json, "service_name");

            ArchiveSearch search = new ArchiveSearch();
            JID participant1JID = null;
            JID participant2JID = null;

            int start = 0;

            try {
                start = Integer.parseInt(jsonGetString(json, "start"));
            }
            catch (Exception e) {
                start = 0;
            }

            int range = 100;

            try {
                range = Integer.parseInt(jsonGetString(json, "range"));
            }
            catch (Exception e) {
                range = 100;
            }

            String serverName = server.getServerInfo().getXMPPDomain();

            if (!isNull(participant1) && participant1.length() > 0) {
                int position = participant1.lastIndexOf("@");
                if (position > -1) {
                    String node = participant1.substring(0, position);
                    participant1JID = new JID(JID.escapeNode(node) + participant1.substring(position));
                } else {
                    participant1JID = new JID(JID.escapeNode(participant1), serverName, null);
                }
            }

            if (!isNull(participant2) && participant2.length() > 0) {
                int position = participant2.lastIndexOf("@");
                if (position > -1) {
                    String node = participant2.substring(0, position);
                    participant2JID = new JID(JID.escapeNode(node) + participant2.substring(position));
                } else {
                    participant2JID = new JID(JID.escapeNode(participant2), serverName, null);
                }
            }

            if (!isNull(startDate) && startDate.length() > 0) {
                DateFormat formatter = new SimpleDateFormat("MM/dd/yy");
                try {
                    Date date = formatter.parse(startDate);
                    search.setDateRangeMin(date);
                }
                catch (Exception e) {
                    return "Invalid start_date " + e;
                }
            }

            if (!isNull(endDate) && endDate.length() > 0) {
                DateFormat formatter = new SimpleDateFormat("MM/dd/yy");
                try {
                    Date date = formatter.parse(endDate);
                    // The user has chosen an end date and expects that any conversation
                    // that falls on that day will be included in the search results. For
                    // example, say the user choose 6/17/2006 as an end date. If a conversation
                    // occurs at 5:33 PM that day, it should be included in the results. In
                    // order to make this possible, we need to make the end date one millisecond
                    // before the next day starts.
                    date = new Date(date.getTime() + JiveConstants.DAY - 1);
                    search.setDateRangeMax(date);
                }
                catch (Exception e) {
                    return "searchHistory error " + e;
                }
            }

            if (!isNull(query) && query.length() > 0) {
                search.setQueryString(query);
            }

            if (participant1JID != null && participant2JID != null) {
                search.setParticipants(participant1JID, participant2JID);
            } else if (participant1JID != null) {
                search.setParticipants(participant1JID);
            } else if (participant2JID != null) {
                search.setParticipants(participant2JID);
            }

            if (!isNull(roomName)) {
                MUCRoom chatRoom = server.getMultiUserChatManager().getMultiUserChatService(serviceName).getChatRoom(roomName);
                search.setRoom(chatRoom.getJID());
            }

            search.setSortOrder(ArchiveSearch.SortOrder.ascending);

            conversations = archiveSearcher.search(search);
            int numPages = (int) Math.ceil((double) conversations.size() / (double) range);
            int curPage = (start / range) + 1;

            int i = 1;
            int z = 0;
            int end = start + range + 1;

            for (Conversation conversation : conversations)
            {
                if(i == end){
                    break;
                }
                else if(i < start){
                    i++;
                    continue;
                }

                JSONObject conversationJSON = new JSONObject();
                conversationJSON.put("date", dateFormat.format(conversation.getStartDate()));
                conversationJSON.put("id", conversation.getConversationID());
                conversationJSON.put("is_external", String.valueOf(conversation.isExternal()));
                conversationJSON.put("start_date", String.valueOf(conversation.getStartDate()));
                conversationJSON.put("last_activity", String.valueOf(conversation.getLastActivity()));
                conversationJSON.put("message_count", String.valueOf(conversation.getMessageCount()));
                conversationJSON.put("room_id", conversation.getRoom() != null ? conversation.getRoom() : null);
                conversationJSON.put("pages", String.valueOf(numPages));
                conversationJSON.put("page", String.valueOf(curPage));

                Map<String, JID> participants = getParticipants(conversation);
                JSONArray participantsJSON = new JSONArray();
                int p = 0;

                Iterator iter = participants.keySet().iterator();

                while (iter.hasNext())
                {
                    String name = (String)iter.next();
                    JSONObject participantJSON = new JSONObject();
                    participantJSON.put("name", name);

                    participantsJSON.put(p++, participantJSON);
                }

                conversationJSON.put("participants", participantsJSON);

                JSONArray messagesJSON = new JSONArray();
                int m = 0;

                for (ArchivedMessage message : conversation.getMessages())
                {
                    JSONObject messageJSON = new JSONObject();
                    messageJSON.put("from", message.getFromJID().toString());
                    messageJSON.put("to", message.getToJID().toString());
                    messageJSON.put("date", dateFormat.format(message.getSentDate()));
                    messageJSON.put("body", message.getBody());
                    messageJSON.put("is_room_event", String.valueOf(message.isRoomEvent()));

                    messagesJSON.put(m++, messageJSON);
                }

                conversationJSON.put("messages", messagesJSON);

                conversationsJSON.put(z++, conversationJSON);
            }

        } catch (Exception e) {
            return "searchHistory error " + e;
        }
        */
        addMeetExtension(newCommand, conversationsJSON);
        return null;
    }

    /**
     * bookmark to json
     *
     * @param
     *
     * @return the json
     */
    private JSONObject getJsonFromBookmark(Bookmark bookmark)
    {
        Log.debug("getJsonFromBookmark " + bookmark);

        JSONObject bookmarkJSON = new JSONObject();

        bookmarkJSON.put("type",    bookmark.getType().toString());
        bookmarkJSON.put("global",  String.valueOf(bookmark.isGlobalBookmark()));
        bookmarkJSON.put("value",   bookmark.getValue());
        bookmarkJSON.put("name",    bookmark.getName());
        bookmarkJSON.put("autojoin", bookmark.getProperty("autojoin"));
        bookmarkJSON.put("id",      bookmark.getBookmarkID());

        JSONArray usersJSON = new JSONArray();
        int j = 0;

        for (String user : bookmark.getUsers())
        {
            JSONObject userJSON = new JSONObject();
            userJSON.put("user", user);
            usersJSON.put(j++, userJSON);
        }

        bookmarkJSON.put("users", usersJSON);

        JSONArray groupsJSON = new JSONArray();
        int k = 0;

        for (String group : bookmark.getGroups())
        {
            JSONObject groupJSON = new JSONObject();
            groupJSON.put("group", group);
            groupsJSON.put(k++, groupJSON);
        }

        bookmarkJSON.put("groups", groupsJSON);

        return bookmarkJSON;
    }

    /**
     * Convert to muc room entity.
     *
     * @param room
     *            the room
     * @return the mUC room entity
     */
    private JSONObject getJsonFromRoomXml(MUCRoom room)
    {
        Log.debug("getJsonFromRoomXml " + room);

        JSONObject roomJSON = new JSONObject();

        roomJSON.put("naturalName", room.getNaturalLanguageName());
        roomJSON.put("roomName", room.getName());
        roomJSON.put("description", room.getDescription());
        roomJSON.put("subject", room.getSubject());
        roomJSON.put("canAnyoneDiscoverJID", String.valueOf(room.canAnyoneDiscoverJID()));
        roomJSON.put("canChangeNickname", String.valueOf(room.canChangeNickname()));
        roomJSON.put("canOccupantsChangeSubject", String.valueOf(room.canOccupantsChangeSubject()));
        roomJSON.put("canOccupantsInvite", String.valueOf(room.canOccupantsInvite()));
        roomJSON.put("publicRoom", String.valueOf(room.isPublicRoom()));
        roomJSON.put("password", room.getPassword());
        roomJSON.put("persistent", String.valueOf(room.isPersistent()));
        roomJSON.put("registrationEnabled", String.valueOf(room.isRegistrationEnabled()));
        roomJSON.put("logEnabled", String.valueOf(room.isLogEnabled()));
        roomJSON.put("loginRestrictedToNickname", String.valueOf(room.isLoginRestrictedToNickname()));
        roomJSON.put("maxUsers", String.valueOf(room.getMaxUsers()));
        roomJSON.put("membersOnly", String.valueOf(room.isMembersOnly()));
        roomJSON.put("moderated", String.valueOf(room.isModerated()));
        roomJSON.put("creationDate", String.valueOf(room.getCreationDate()));
        roomJSON.put("modificationDate", String.valueOf(room.getModificationDate()));

        JSONArray broadcastPresenceRoles = new JSONArray();

        List<String> roles = room.getRolesToBroadcastPresence();
        int index = 0;

        for (String role : roles)
        {
            JSONObject roleJSON = new JSONObject();
            roleJSON.put("broadcastPresenceRole", role);
            broadcastPresenceRoles.put(index++, roleJSON);
        }

        roomJSON.put("broadcastPresenceRoles", broadcastPresenceRoles);
        return roomJSON;

    }

    /**
     * Creates the room.
     *
     * @param roomJSON
     *            the muc room details
     * @param serviceName
     *            the service name
     * @param owner
     *            the owner
     * @throws NotAllowedException
     *             the not allowed exception
     */
    private void createRoom(JSONObject json) throws NotAllowedException
    {
        String serviceName = jsonGetString(json, "service_name");
        String roomName = jsonGetString(json, "room_name");
        String roomOwner = jsonGetString(json, "room_owner");

        MUCRoom room = server.getMultiUserChatManager().getMultiUserChatService(serviceName)
                .getChatRoom(roomName, server.createJID(roomOwner, null));

        room.setNaturalLanguageName(jsonGetString(json, "naturalName"));
        room.setSubject(jsonGetString(json, "subject"));
        room.setDescription(jsonGetString(json, "description"));
        room.setPassword(jsonGetString(json, "password"));
        room.setPersistent(jsonGetString(json, "persistent").equals("true"));
        room.setPublicRoom(jsonGetString(json, "publicRoom").equals("true"));
        room.setRegistrationEnabled(jsonGetString(json, "registrationEnabled").equals("true"));
        room.setCanAnyoneDiscoverJID(jsonGetString(json, "canAnyoneDiscoverJID").equals("true"));
        room.setCanOccupantsChangeSubject(jsonGetString(json, "canOccupantsChangeSubject").equals("true"));
        room.setCanOccupantsInvite(jsonGetString(json, "canOccupantsInvite").equals("true"));
        room.setChangeNickname(jsonGetString(json, "canChangeNickname").equals("true"));
        room.setCreationDate(new Date(jsonGetString(json, "creationDate")));
        room.setModificationDate(new Date(jsonGetString(json, "modificationDate")));
        room.setLogEnabled(jsonGetString(json, "logEnabled").equals("true"));
        room.setLoginRestrictedToNickname(jsonGetString(json, "loginRestrictedToNickname").equals("true"));
        room.setMaxUsers(Integer.parseInt(jsonGetString(json, "maxUsers")));
        room.setMembersOnly(jsonGetString(json, "membersOnly").equals("true"));
        room.setModerated(jsonGetString(json, "moderated").equals("true"));

        JSONArray rolesJSON = json.getJSONArray("broadcastPresenceRoles");
        List<String> roles = new ArrayList<String>();

        for(int j = 0; j < rolesJSON.length(); j++)
        {
            JSONObject role = rolesJSON.getJSONObject(j);
            roles.add(role.getString("broadcastPresenceRole"));

        }
        room.setRolesToBroadcastPresence(roles);
    }

    /**
     * Creates/Updates a bookmark
     *
     * @param bookmarkJSON
     *            the bookmark details
     */
    private String maintBookmark(JSONObject bookmarkJSON)
    {
        String bookmarkID = bookmarkJSON.getString("id");
        String type = bookmarkJSON.getString("type");
        String name = bookmarkJSON.getString("name");
        String value = bookmarkJSON.getString("value");

        Bookmark bookmark = null;

        try {

            if (bookmarkID == null) {
                if ("url".equals(type)) {
                    bookmark = new Bookmark(Bookmark.Type.url, name, value);
                    bookmark.setProperty("url", value);

                } else if ("group_chat".equals(type)) {
                    bookmark = new Bookmark(Bookmark.Type.group_chat, name, value);

                    if ("true".equals(bookmarkJSON.getString("autojoin"))) {
                        bookmark.setProperty("autojoin", "true");
                    }
                    else {
                        bookmark.deleteProperty("autojoin");
                    }

                }
                else {
                    return "Bookmark type invalid";
                }
            }
            else {
                try {
                    bookmark = new Bookmark(Long.parseLong(bookmarkID));
                    bookmark.setName(name);
                    bookmark.setValue(bookmarkJSON.getString("value"));
                }
                catch (Exception e) {
                    return "Bookmark not found, " + e;
                }
            }

            List<String> userCollection = new ArrayList<String>();
            List<String> groupCollection = new ArrayList<String>();

            StringTokenizer tkn1 = new StringTokenizer(bookmarkJSON.getString("users"), ",");
            while (tkn1.hasMoreTokens()) {
                userCollection.add(tkn1.nextToken());
            }

            bookmark.setUsers(userCollection);

            StringTokenizer tkn2 = new StringTokenizer(bookmarkJSON.getString("groups"), ",");
            while (tkn2.hasMoreTokens()) {
                groupCollection.add(tkn2.nextToken());
            }

            bookmark.setGroups(groupCollection);

            if ("true".equals(bookmarkJSON.getString("global"))) {
                bookmark.setGlobalBookmark(true);
            }
            else {
                bookmark.setGlobalBookmark(false);
            }
        }
        catch (Exception e) {
            return "Invalid bookmark details, " + e;
        }

        return null;
    }

    /**
     * Gets the user objects by property key and or value.
     *
     * @param propertyName
     *            the property name
     * @param propertyValue
     *            the property value (can be null)
     * @return the username by property
     */
    public List<User> getUsersByProperty(String propertyName, String propertyValue, int startIndex, int max)   // TODO implement startIndex, and max
    {
        List<User> users = new ArrayList<User>();
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            con = DbConnectionManager.getConnection();
            // Load property by key and value
            if (isNull(propertyValue) == false) {
                pstmt = con.prepareStatement("SELECT username FROM ofUserProp WHERE name=? AND propValue=?");
                pstmt.setString(1, propertyName);
                pstmt.setString(2, propertyValue);
            } else {
                // Load property by key
                pstmt = con.prepareStatement("SELECT username FROM ofUserProp WHERE name=?");
                pstmt.setString(1, propertyName);
            }
            rs = pstmt.executeQuery();
            while (rs.next()) {
                users.add(getUser(rs.getString(1)));
            }
        } catch (Exception e) {
            Log.error("getUsernameByProperty", e);

        } finally {
            DbConnectionManager.closeConnection(rs, pstmt, con);
        }
        return users;
    }

    private void setupPrivateStorage(String userName)
    {
        String tscJID = getName() + "." + getDomain();
        try
        {
            Document document = DocumentHelper.parseText("<openlink xmlns=\"http://xmpp.org/protocol/openlink:01:00:00#tsc\"></openlink>");

            if (document != null)
            {
                Element searchElement = document.getRootElement();
                Element olElement = privateStorage.get(userName, searchElement);

                boolean foundTSC = false;

                for ( Iterator i = olElement.elementIterator( "tsc" ); i.hasNext(); )
                {
                    Element tsc = (Element) i.next();

                    if (tscJID.equals(tsc.getText()))
                    {
                        Log.debug("addUserTSC - found " + tscJID + " " + userName);
                        foundTSC = true;
                        break;
                    }
                }

                if (!foundTSC) {
                    Log.debug("addUserTSC - adding " + tscJID + " " + userName);

                    synchronized (privateStorage)
                    {
                        olElement = privateStorage.get(userName, searchElement);
                        Element tsc = olElement.addElement("tsc");
                        tsc.setText(tscJID);
                        tsc.addAttribute("name", "Belfry");
                        privateStorage.add(userName, olElement);
                    }
                }
            }
        }
        catch(Exception e)
        {
            Log.error("setupPrivateStorage " + tscJID, e);
        }
    }

}

