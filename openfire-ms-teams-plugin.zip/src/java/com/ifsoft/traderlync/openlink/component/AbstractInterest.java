package com.ifsoft.traderlync.openlink.component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractInterest
{
    private static final Logger Log = LoggerFactory.getLogger(AbstractInterest.class);

}
