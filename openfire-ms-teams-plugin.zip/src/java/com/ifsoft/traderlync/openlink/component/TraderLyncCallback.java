package com.ifsoft.traderlync.openlink.component;

import java.util.Date;

public class TraderLyncCallback extends AbstractCallback
{
	private String remoteHandset 			= null;
	private String localHandset				= null;
	private String virtualDeviceId			= null;
	private String virtualUserId			= null;
	private TraderLyncUser traderLyncUser		= null;
	private Date timestamp					= null;

    public TraderLyncCallback()
    {

    }

	public Date getTimestamp()
	{
		return timestamp;
	}

	public void setTimestamp(Date timestamp)
	{
		this.timestamp = timestamp;
	}

	public String getRemoteHandset()
	{
		return remoteHandset;
	}

	public void setRemoteHandset(String remoteHandset)
	{
		this.remoteHandset = remoteHandset;
	}

	public String getLocalHandset()
	{
		return localHandset;
	}

	public void setLocalHandset(String localHandset)
	{
		this.localHandset = localHandset;
	}

	public String getVirtualDeviceId()
	{
		return virtualDeviceId;
	}

	public void setVirtualDeviceId(String virtualDeviceId)
	{
		this.virtualDeviceId = virtualDeviceId;
	}

	public String getVirtualUserId()
	{
		return virtualUserId;
	}

	public void setVirtualUserId(String virtualUserId)
	{
		this.virtualUserId = virtualUserId;
	}


	public TraderLyncUser getTraderLyncUser()
	{
		return traderLyncUser;
	}

	public void setTraderLyncUser(TraderLyncUser traderLyncUser)
	{
		this.traderLyncUser = traderLyncUser;
	}


}

