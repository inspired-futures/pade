package com.ifsoft.traderlync.openlink.component;

public class TraderLyncGroupMember extends AbstractGroupMember
{

}

