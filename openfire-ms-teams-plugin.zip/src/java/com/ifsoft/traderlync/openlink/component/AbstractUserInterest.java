package com.ifsoft.traderlync.openlink.component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractUserInterest
{
    private static final Logger Log = LoggerFactory.getLogger(AbstractUserInterest.class);

}
