package com.ifsoft.traderlync.openlink.component;

import java.util.*;

public class TraderLyncCall extends AbstractCall
{
    public String speaker = "00";
    public boolean traderLyncTransferFlag = false;
    private boolean callbackActive = false;
    private boolean voiceDropActive = false;
    private boolean callbackAvailable = false;
    private String callProgressFlag = null;
    private TraderLyncUserInterest traderLyncUserInterest;

    public String previousCalledNumber = null;
    public String previousCalledLabel = null;
    public boolean alerted = false;


    public void setVoiceDropActive(boolean voiceDropActive)
    {
        this.voiceDropActive = voiceDropActive;
    }

    public boolean getVoiceDropActive()
    {
        return voiceDropActive;
    }

    public void setCallbackActive(boolean callbackActive)
    {
        this.callbackActive = callbackActive;
    }

    public boolean getCallbackActive()
    {
        return callbackActive;
    }

    public void setCallbackAvailable(boolean callbackAvailable)
    {
        this.callbackAvailable = callbackAvailable;
    }

    public boolean getCallbackAvailable()
    {
        return callbackAvailable;
    }

    public void setCallProgress(String callProgressFlag)
    {
        this.callProgressFlag = callProgressFlag;
    }

    public String getCallProgress()
    {
        return callProgressFlag;
    }

    public void setTraderLyncUserInterest(TraderLyncUserInterest traderLyncUserInterest)
    {
        this.traderLyncUserInterest = traderLyncUserInterest;
    }

    public TraderLyncUserInterest getTraderLyncUserInterest()
    {
        return traderLyncUserInterest;
    }

    public void clear()
    {
        callProgressFlag = null;
        previousCalledNumber = null;
        proceedingDigitsLabel = null;
        traderLyncTransferFlag = false;

        super.clear();
    }

    @Override protected void setCallFailedActions()
    {
        validActions.add("ClearConnection");
        validActions.add("ClearCall");
    }

    @Override protected void setCallOriginatedActions()
    {
        validActions.add("ClearConnection");
        validActions.add("SendDigits");
        validActions.add("ClearCall");
    }

    @Override protected void setIntercomEstablishedActions()
    {
        validActions.add("ClearConnection");
        validActions.add("ClearCall");
    }

    @Override protected void setCallEstablishedActions()
    {
        String interestValue = traderLyncUserInterest.getInterest().getInterestId();
        String defaultInterest = traderLyncUserInterest.getUser().getDefaultInterest().getInterestId();

        if (interestValue.contains("skype4b"))
        {
            if (defaultInterest.equals(interestValue))
            {
                validActions.add("ClearConnection");
                validActions.add("HoldCall");
                validActions.add("TransferCall");
                validActions.add("SendDigit");
                validActions.add("ClearCall");

                if ("N".equals(getPrivacy()))
                {
                    validActions.add("AddThirdParty");
                    validActions.add("RemoveThirdParty");
                }
            }
            validActions.add("ClearCall");

        } else {
            validActions.add("ClearConnection");
            validActions.add("HoldCall");
            //validActions.add("TransferCall");

            validActions.add("SendDigit");
            validActions.add("ClearCall");

            if ("N".equals(getPrivacy()))
            {
                validActions.add("AddThirdParty");
                validActions.add("RemoveThirdParty");
            }

            validActions.add("IntercomTransfer");
            validActions.add("SingleStepTransfer");

            if("Y".equals(getPrivacy()))
                validActions.add("PublicCall");
            else
                validActions.add("PrivateCall");


            if ("N".equals(getPrivacy()))
            {
                if (getVoiceDropActive())
                {
                    validActions.add("StartVoiceDrop");
                    validActions.add("StopVoiceDrop");
                }
            }

            if (traderLyncUserInterest.getInterest().useGateway)
            {
                validActions.add("AlertCall");
            }
        }
    }

    @Override protected void setCallDeliveredActions()
    {
        validActions.add("ClearConnection");
        validActions.add("HoldCall");

        if (!platformIntercom)
        {
            if("Y".equals(getPrivacy()))
                validActions.add("PublicCall");
            else
                validActions.add("PrivateCall");

            validActions.add("SendDigit");
            validActions.add("ClearCall");
        }

    }

    @Override protected void setCallBusyActions()
    {
        if("N".equals(getPrivacy()))
        {
            if (delivered && "Outgoing".equals(direction) || "Incoming".equals(direction))
            {
                validActions.add("JoinCall");
                validActions.add("AddThirdParty");
                validActions.add("RemoveThirdParty");
            }
        }

        //validActions.add("ClearCall");
    }

    @Override protected void setCallHeldActions()
    {
        validActions.add("RetrieveCall");
    }


    @Override protected void setCallHeldElsewhereActions()
    {
        if("N".equals(getPrivacy()))
        {
            validActions.add("RetrieveCall");
        }

        //validActions.add("ClearCall");
    }

    @Override protected void setCallConferencedActions()
    {
        String interestValue = traderLyncUserInterest.getInterest().getInterestId();
        String defaultInterest = traderLyncUserInterest.getUser().getDefaultInterest().getInterestId();

        if (interestValue.contains("skype4b"))
        {
            if (defaultInterest.equals(interestValue))
            {
                validActions.add("AddThirdParty");
                validActions.add("RemoveThirdParty");
                validActions.add("ClearConnection");
                validActions.add("ClearCall");
            }

        } else {

            if (localConferenced  && !getCallbackActive())
            {
                validActions.add("ClearConference");
                validActions.add("ClearCall");

            } else {

                validActions.add("ClearConnection");
                validActions.add("ClearCall");
                validActions.add("AddThirdParty");
                validActions.add("RemoveThirdParty");
            }

            if (traderLyncUserInterest.getInterest().useGateway)
            {
                validActions.add("AlertCall");
            }
        }
    }
}