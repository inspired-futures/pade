package com.ifsoft.traderlync.openlink.component;

import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractCallback
{
    private static final Logger Log = LoggerFactory.getLogger(AbstractCallback.class);

}

