package com.ifsoft.traderlync.openlink.component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.xmpp.component.Component;
import org.xmpp.component.AbstractComponent;
import org.xmpp.component.ComponentException;
import org.xmpp.component.ComponentManager;
import org.xmpp.component.ComponentManagerFactory;

import org.xmpp.packet.JID;
import java.util.List;

public abstract class AbstractTSComponent extends AbstractComponent
{
    private static final Logger Log = LoggerFactory.getLogger(AbstractTSComponent.class);

    public AbstractTSComponent(int maxThreadpoolSize, int maxQueueSize, boolean enforceIQResult)
    {
        super(maxThreadpoolSize, maxQueueSize, enforceIQResult);
    }

}
