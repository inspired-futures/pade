package com.ifsoft.traderlync.openlink.component;

import java.io.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractGroupMember
{
    private static final Logger Log = LoggerFactory.getLogger(AbstractGroupMember.class);

    private String abstractMemberID         = null;

    public String getMemberID() {
        return abstractMemberID;
    }

    public void setMemberID(String abstractMemberID) {
        this.abstractMemberID = abstractMemberID;
    }
}

