package com.ifsoft.traderlync.openlink.component;


public class TraderLyncSubscriber extends AbstractSubscriber
{

}