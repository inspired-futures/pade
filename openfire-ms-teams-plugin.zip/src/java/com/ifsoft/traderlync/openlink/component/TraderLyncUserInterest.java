package com.ifsoft.traderlync.openlink.component;

import java.io.Serializable;
import java.util.*;
import org.xmpp.packet.JID;
import org.jivesoftware.util.Log;

import com.ifsoft.traderlync.openlink.calllog.*;


public class TraderLyncUserInterest extends AbstractUserInterest
{

    private TraderLyncUser traderLyncUser;
    private TraderLyncInterest traderLyncInterest;
    private String defaultInterest;
    private String callFWD = "false";
    private String callFWDDigits = "";
    private Map<String, TraderLyncCall> traderLyncCalls;
    private Map<String, TraderLyncSubscriber> traderLyncSubscribers;
    private int maxNumCalls = 0;

    public String activeCallId = null;
    public String ivCallId = null;
    public String memberId = null;


    public TraderLyncUserInterest()
    {
        defaultInterest = "false";
        traderLyncCalls = Collections.synchronizedMap( new HashMap<String, TraderLyncCall>());
        traderLyncSubscribers = Collections.synchronizedMap( new HashMap<String, TraderLyncSubscriber>());
    }

    public String getInterestName() {
        return traderLyncInterest.getInterestId() + traderLyncUser.getUserNo();
    }

    public void handleCallInfo(String sCallNo, String sTraderLyncLineNo, String sTraderLyncLineName, String sNewLineState, String speakerCount, String handsetCount, String direction, String sPrivacyOn, String sRealDDI, String lineType, String sELC)
    {
        TraderLyncCall traderLyncCall = createCallById(sCallNo);
        traderLyncCall.start();
        traderLyncCall.uuid = sTraderLyncLineNo;
        traderLyncCall.label = sTraderLyncLineName;
        traderLyncCall.console = getUser().getDeviceNo();
        traderLyncCall.handset = getUser().getHandsetNo();
        traderLyncCall.direction = "I".equals(direction) ? "Incoming" : "Outgoing";
        traderLyncCall.setPrivacy(sPrivacyOn);

        if ("I".equals(sNewLineState))
        {
            traderLyncCall.setState("ConnectionCleared");
        }

        if ("R".equals(sNewLineState))
        {
            traderLyncCall.setState("CallDelivered");
            traderLyncCall.direction = "Incoming";
        }

        if ("C".equals(sNewLineState) || "A".equals(sNewLineState))
        {
            traderLyncCall.setState("CallEstablished");
        }

        if ("H".equals(sNewLineState))
        {
            traderLyncCall.setState("CallHeld");
        }

        if ("F".equals(sNewLineState))
        {
            traderLyncCall.setState("CallConferenced");
        }

        traderLyncCall.setValidActions();
    }

    public void handleCallELC(String sCallNo, String sTraderLyncLineNo, String sTraderLyncLineName, String sTraderLyncConsoleNo, String sTraderLyncUserNo, String sHandsetNo, String sELC, String sConnectOrDisconnect)
    {
        TraderLyncCall traderLyncCall = createCallById(sCallNo);
        traderLyncCall.uuid = sTraderLyncLineNo;

        Log.debug("handleCallELC " + traderLyncCall.callid + " "  + sConnectOrDisconnect);

        if("C".equals(sConnectOrDisconnect))
        {
            traderLyncCall.localConferenced = true;
            traderLyncCall.setState("CallConferenced");

        } else {
            traderLyncCall.localConferenced = false;
            traderLyncCall.setState("CallEstablished");
        }

        traderLyncCall.setValidActions();

    }

    public void handleBusyLine(String sCallNo, String sTraderLyncLineNo, String sTraderLyncLineName, String sTraderLyncConsoleNo, String sTraderLyncUserNo, String sOldLineState, String sNewLineState,
            String sHandsetOrSpeaker, String sSpeakerNo, String sHandsetNo, String sConnectOrDisconnect)
    {

    }

    public void handleConnectionCleared(String sCallNo)
    {
        TraderLyncCall traderLyncCall = createCallById(sCallNo);
        traderLyncCall.setState("ConnectionCleared");
        traderLyncCall.setValidActions();
        traderLyncCall.participation = "Inactive";
        traderLyncCall.endDuration();

        traderLyncCall.clear();

        getUser().setIntercom(false);

        ivCallId = null;
    }

    public void handleCallOutgoing(String state, String sCallNo, String digits, String sTraderLyncLabel)
    {
        TraderLyncCall traderLyncCall = createCallById(sCallNo);

        // we already have set the interest no/name

        if("D".equals(getInterest().getInterestType()))
        {
            traderLyncCall.setCLI(digits);
            traderLyncCall.setCLILabel(sTraderLyncLabel);
        } else {
            //traderLyncCall.setCLI(digits);
            traderLyncCall.ddiLabel = sTraderLyncLabel;
        }
        traderLyncCall.label = sTraderLyncLabel;
        traderLyncCall.direction = "Outgoing";
        traderLyncCall.connectState = state;
        traderLyncCall.setState(state);
        traderLyncCall.setValidActions();
        traderLyncCall.startDuration();
        if ("CallBusy".equals(state) == false) traderLyncCall.startParticipation();
    }

    public void handleCallIncoming(String sCallNo, String from, String to, String label)
    {
        TraderLyncCall traderLyncCall = createCallById(sCallNo);
        traderLyncCall.start();

        traderLyncCall.ddi = to;
        traderLyncCall.setCLI(from);

        if("D".equals(getInterest().getInterestType()))
        {
            traderLyncCall.ddiLabel = getInterest().getInterestLabel();
            traderLyncCall.setCLILabel(label);
        } else {
            traderLyncCall.ddiLabel = label;
            traderLyncCall.setCLILabel(getInterest().getInterestLabel());
        }

        traderLyncCall.label = getInterest().getInterestLabel();
        traderLyncCall.direction = "Incoming";
        traderLyncCall.connectState = "CallEstablished";
        traderLyncCall.setState("CallDelivered");
        traderLyncCall.setValidActions();
        traderLyncCall.startDuration();
    }

    public void handleCallIntercom(String sCallNo, String from, String to, boolean muted)
    {
        Log.debug("setCurrentCall " + sCallNo);

        TraderLyncCall traderLyncCall = createCallById(sCallNo);
        traderLyncCall.start();
        traderLyncCall.label = getInterest().getInterestLabel();

        traderLyncCall.ddi = to;
        traderLyncCall.setCLI(from);

        setCurrentCall(traderLyncCall);

        traderLyncCall.setState("IntercomEstablished");
        if (muted) traderLyncCall.addValidAction("StartSpeaking");
        traderLyncCall.addValidAction("ClearConnection");
        traderLyncCall.addValidAction("ClearCall");
        traderLyncCall.startDuration();
        traderLyncCall.participation = "Active";
        traderLyncCall.startParticipation();
    }

    public void handleCallConnected(String sCallNo)
    {
        Log.debug("setCurrentCall " + sCallNo);

        TraderLyncCall traderLyncCall = createCallById(sCallNo);
        traderLyncCall.start();
        traderLyncCall.label = getInterest().getInterestLabel();

        setCurrentCall(traderLyncCall);

        traderLyncCall.setState("CallEstablished");
        traderLyncCall.setValidActions();
        traderLyncCall.startDuration();
        traderLyncCall.participation = "Active";
        traderLyncCall.startParticipation();
    }


    public void handleCallPrivate(String sCallNo, String sPrivacyOn)
    {
        TraderLyncCall traderLyncCall = getCallById(sCallNo);

        if (traderLyncCall != null)
        {
            traderLyncCall.setPrivacy(sPrivacyOn);
            traderLyncCall.setValidActions();
        }
    }


    public void handleCallPrivateElsewhere(String sCallNo, String sPrivacyOn)
    {
        TraderLyncCall traderLyncCall = getCallById(sCallNo);

        if (traderLyncCall != null)
        {
            traderLyncCall.setPrivacy(sPrivacyOn);
            traderLyncCall.setValidActions();
        }
    }

    public void handleCallAlerted(String sCallNo, boolean status)
    {
        TraderLyncCall traderLyncCall = getCallById(sCallNo);

        if (traderLyncCall != null)
        {
            traderLyncCall.alerted = status;
        }
    }

    public void handleCallAbandoned(String sCallNo)
    {
        TraderLyncCall traderLyncCall = getCallById(sCallNo);

        if (traderLyncCall != null)
        {
            traderLyncCall.setState("CallMissed");
            traderLyncCall.setValidActions();
            traderLyncCall.clear();
        }
    }

    public void handleCallConferenced(String sCallNo)
    {
        TraderLyncCall traderLyncCall = createCallById(sCallNo);

        if (traderLyncCall != null)
        {
            setCurrentCall(traderLyncCall);

            traderLyncCall.setState("CallConferenced");
            traderLyncCall.setValidActions();
            traderLyncCall.startDuration();
            traderLyncCall.participation = "Active";
            traderLyncCall.startParticipation();
        }
    }



    public TraderLyncCall getCurrentCall(String handset)
    {
        TraderLyncCall traderLyncCall = null;

        TraderLyncCall intercomCall = getUser().getCurrentICMCall();
        TraderLyncCall traderLyncCall1 = getUser().getCurrentHS1Call();
        TraderLyncCall traderLyncCall2 = getUser().getCurrentHS2Call();

        if ("1".equals(handset))
            traderLyncCall = traderLyncCall1;

        else if ("2".equals(handset))
            traderLyncCall = traderLyncCall2;

        else if ("0".equals(handset))
            traderLyncCall = intercomCall;

        else if ("3".equals(handset))
            traderLyncCall = traderLyncCall1;

        return traderLyncCall;
    }

    private void setCurrentCall(TraderLyncCall traderLyncCall)
    {
        Log.debug("setCurrentCall " + traderLyncCall.getCallID() + " " + traderLyncCall.handset + " " + traderLyncCall.speaker);

        traderLyncCall.console = getUser().getDeviceNo();

        if ("1".equals(traderLyncCall.handset))
            getUser().setCurrentHS1Call(traderLyncCall);

        else if ("2".equals(traderLyncCall.handset))
            getUser().setCurrentHS2Call(traderLyncCall);

        else if ("65".equals(traderLyncCall.speaker))
            getUser().setCurrentICMCall(traderLyncCall);

        else if ("3".equals(traderLyncCall.handset))
            getUser().setCurrentHS1Call(traderLyncCall);
    }

    public void handleCallBusy(String sCallNo)
    {
        TraderLyncCall traderLyncCall = getCallById(sCallNo);

        if (traderLyncCall != null)
        {
            traderLyncCall.start();
            traderLyncCall.setState("CallBusy");
            traderLyncCall.delivered = true;
            traderLyncCall.setValidActions();
            traderLyncCall.participation = "Inactive";
        }
    }


    public void handleCallFailed(String sCallNo, String sTraderLyncLineNo, String sTraderLyncLineName, String sTraderLyncConsoleNo, String sTraderLyncUserNo, String sOldLineState, String sNewLineState,
            String sHandsetOrSpeaker, String sSpeakerNo, String sHandsetNo, String sConnectOrDisconnect)
    {
        TraderLyncCall traderLyncCall = getCallById(sCallNo);

        if (traderLyncCall != null)
        {
            traderLyncCall.clear();

            traderLyncCall.uuid = sTraderLyncLineNo;
            traderLyncCall.label = sTraderLyncLineName;
            traderLyncCall.setState("CallFailed");
            traderLyncCall.setValidActions();
            traderLyncCall.participation = "Inactive";
        }
    }

    public void handleCallHeld(String sCallNo)
    {
        TraderLyncCall traderLyncCall = getCallById(sCallNo);

        if (traderLyncCall != null)
        {
            traderLyncCall.setState("CallHeld");
            traderLyncCall.setValidActions();
            traderLyncCall.participation = "Inactive";
            traderLyncCall.endDuration();
        }
    }

    public void handleTransfer(String sCallNo, String sTraderLyncLineNo, String sTraderLyncConsoleNo, String sTraderLyncUserNo, String sTransferUserNo)
    {
        TraderLyncCall traderLyncCall = getCallById(sCallNo);

        if (traderLyncCall != null)
        {
            traderLyncCall.traderLyncTransferFlag = true;
        }
    }

    public void handleCallProgress(String sCallNo, String sTraderLyncLineNo, String sChannelNo, String sTraderLyncFlag)
    {
        TraderLyncCall traderLyncCall = getCallById(sCallNo);

        if (traderLyncCall != null)
        {
            traderLyncCall.setCallProgress(sTraderLyncFlag);

            if ("Outgoing".equals(traderLyncCall.direction))
            {
                if("CallOriginated".equals(traderLyncCall.getState()))
                {
                    if("0".equals(sTraderLyncFlag))
                    {
                        if("D".equals(getInterest().getInterestType()))
                        {
                            traderLyncCall.setState("CallDelivered");

                        } else
                            traderLyncCall.setState("CallEstablished");

                    } else if("4".equals(sTraderLyncFlag) || "1".equals(sTraderLyncFlag)) {

                        traderLyncCall.setState("CallEstablished");

                    } else
                        traderLyncCall.setState("CallFailed");
                } else

                if("CallDelivered".equals(traderLyncCall.getState()))
                {
                    if("2".equals(sTraderLyncFlag))
                    {
                        traderLyncCall.setState("CallEstablished");

                    } else if("4".equals(sTraderLyncFlag) || "1".equals(sTraderLyncFlag)) {

                        traderLyncCall.setState("CallEstablished");

                    } else
                        traderLyncCall.setState("CallFailed");
                }

                traderLyncCall.setValidActions();
            }

            if("CallEstablished".equals(traderLyncCall.getState()))
            {
                traderLyncCall.startDuration();
            }
        }
    }

    public void handleCallProceeding(TraderLyncComponent component, String sCallNo, String sTraderLyncLineNo, String sDigits, String sEndFlag)
    {
        TraderLyncCall traderLyncCall = getCallById(sCallNo);

        if (traderLyncCall != null)
        {
            traderLyncCall.proceedingDigitsBuffer = (new StringBuilder()).append(traderLyncCall.proceedingDigitsBuffer).append(sDigits.trim()).toString();

            if("Y".equals(sEndFlag) && !"".equals(traderLyncCall.proceedingDigitsBuffer))
            {
                traderLyncCall.proceedingDigits = traderLyncCall.proceedingDigitsBuffer;
                traderLyncCall.proceedingDigitsBuffer = "";
                traderLyncCall.proceedingDigitsLabel = traderLyncCall.proceedingDigits;

                String cononicalNumber = traderLyncCall.proceedingDigits;

                try
                {
                    cononicalNumber = component.formatCanonicalNumber(traderLyncCall.proceedingDigits);
                }
                catch(Exception e) { }

                //if(component.traderLyncLdapService.cliLookupTable.containsKey(cononicalNumber))
                //  traderLyncCall.proceedingDigitsLabel = (String)component.traderLyncLdapService.cliLookupTable.get(cononicalNumber);
            }
        }
    }


    public void handleCallMoved(String sCallNo, String sTraderLyncLineNo, String sTraderLyncLineNo2)
    {
        TraderLyncCall traderLyncCall = getCallById(sCallNo);

        if (traderLyncCall != null)
        {
            traderLyncCall.uuid = sTraderLyncLineNo2;
        }
    }

    public void handleRecallTransfer(String sCallNo, String sTraderLyncLineNo, String sTraderLyncLineNo2, String transferStatusFlag)
    {
        TraderLyncCall traderLyncCall = getCallById(sCallNo);

        if (traderLyncCall != null)
        {
            if("0".equals(transferStatusFlag))
            {
                traderLyncCall.setState("CallTransferring");
                traderLyncCall.transferFlag = false;

            } else if("1".equals(transferStatusFlag)) {

                traderLyncCall.setState("CallEstablished");
                traderLyncCall.transferFlag = false;

                if (traderLyncCall.previousCalledNumber != null)
                {
                    Iterator<TraderLyncUserInterest> it3 = getInterest().getUserInterests().values().iterator();

                    while( it3.hasNext() )
                    {
                        TraderLyncUserInterest theUserInterest = (TraderLyncUserInterest)it3.next();
                        TraderLyncCall theCall = theUserInterest.getCallByLine(traderLyncCall.getLine());

                        if (theCall != null)
                        {
                            theCall.proceedingDigits = traderLyncCall.previousCalledNumber;
                            theCall.proceedingDigitsLabel = traderLyncCall.previousCalledLabel;
                        }
                    }
                }

            } else if("2".equals(transferStatusFlag)) {

                traderLyncCall.setState("CallTransferred");

            }

            traderLyncCall.setValidActions();
        }
    }

    public String getDefault()
    {
        return defaultInterest;
    }

    public void setDefault(String defaultInterest)
    {
        this.defaultInterest = defaultInterest;
    }

    public TraderLyncUser getUser()
    {
        return traderLyncUser;
    }

    public void setUser(TraderLyncUser traderLyncUser)
    {
        this.traderLyncUser = traderLyncUser;
    }

    public Map<String, TraderLyncSubscriber> getSubscribers()
    {
        return traderLyncSubscribers;
    }

    public void setSubscribers(Map<String, TraderLyncSubscriber> traderLyncSubscribers)
    {
        this.traderLyncSubscribers = traderLyncSubscribers;
    }

    public boolean isSubscribed(JID subscriber)
    {
        return traderLyncSubscribers.containsKey(subscriber.getNode());
    }


    public TraderLyncSubscriber getSubscriber(JID subscriber)
    {
        TraderLyncSubscriber traderLyncSubscriber = null;

        if (traderLyncSubscribers.containsKey(subscriber.getNode()))
        {
            traderLyncSubscriber = (TraderLyncSubscriber)traderLyncSubscribers.get(subscriber.getNode());
        } else
        {
            traderLyncSubscriber = new TraderLyncSubscriber();
            traderLyncSubscriber.setJID(subscriber);
            traderLyncSubscribers.put(subscriber.getNode(), traderLyncSubscriber);
        }
        return traderLyncSubscriber;
    }

    public void removeSubscriber(JID subscriber)
    {
        traderLyncSubscribers.remove(subscriber.getNode());
    }

    public boolean canPublish(TraderLyncComponent component)
    {
        if (traderLyncSubscribers.size() == 0)
        {
            return false;
        }

        boolean anySubscriberOnline = false;

        Iterator<TraderLyncSubscriber> iter = traderLyncSubscribers.values().iterator();

        while( iter.hasNext() )
        {
            TraderLyncSubscriber subscriber = (TraderLyncSubscriber)iter.next();

            if (subscriber.getOnline() || component.isComponent(subscriber.getJID()))
            {
                anySubscriberOnline = true;
                break;
            }
        }

        return anySubscriberOnline;
    }

    public TraderLyncInterest getInterest()
    {
        return traderLyncInterest;
    }

    public void setInterest(TraderLyncInterest traderLyncInterest)
    {
        this.traderLyncInterest = traderLyncInterest;
    }


    public synchronized TraderLyncCall createCallById(String callID)
    {
        Log.debug("createCallById " + callID);

        TraderLyncCall traderLyncCall = null;

        if(traderLyncCalls.containsKey(callID))
        {
            traderLyncCall = (TraderLyncCall)traderLyncCalls.get(callID);

        } else {

            activeCallId = callID;

            traderLyncCall = new TraderLyncCall();
            traderLyncCall.callid = callID;
            traderLyncCall.uuid = callID;
            traderLyncCall.setTraderLyncUserInterest(this);

            if("D".equals(getInterest().getInterestType())) // a bit convuluted. with D type, interest is the source, with D type, interest is the destination
            {
                traderLyncCall.ddi = getInterest().getInterestValue();
                traderLyncCall.ddiLabel = getInterest().getInterestLabel();
            } else {
                traderLyncCall.ddi = getInterest().getInterestId();
                traderLyncCall.ddiLabel = getInterest().getInterestId();

                traderLyncCall.setCLILabel(getInterest().getInterestLabel());
                traderLyncCall.setCLI(getInterest().getInterestValue());
            }

            traderLyncCall.initialiseDuration();

            traderLyncCalls.put(callID, traderLyncCall);
        }
        return traderLyncCall;
    }


    public TraderLyncCall getCallById(String callID)
    {
        TraderLyncCall traderLyncCall = null;

        if(traderLyncCalls.containsKey(callID))
        {
            traderLyncCall = (TraderLyncCall)traderLyncCalls.get(callID);
        }

        return traderLyncCall;
    }

    public TraderLyncCall getCallByLine(String uuid)
    {
        TraderLyncCall lineCall = null;

        Iterator it2 = traderLyncCalls.values().iterator();

        while( it2.hasNext() )
        {
            TraderLyncCall traderLyncCall = (TraderLyncCall)it2.next();

            if (uuid.equals(traderLyncCall.uuid))
            {
                lineCall = traderLyncCall;
                break;
            }
        }

        return  lineCall;
    }

    public TraderLyncCall removeCallById(String callID)
    {
        TraderLyncCall traderLyncCall = null;

        if(traderLyncCalls.containsKey(callID))
        {
            traderLyncCall = (TraderLyncCall)traderLyncCalls.get(callID);
            traderLyncCalls.remove(callID);

            if (activeCallId != null && activeCallId.equals(callID)) activeCallId = null;
        }

        return traderLyncCall;
    }

    public Map<String, TraderLyncCall> getCalls()
    {
        return traderLyncCalls;
    }


    public boolean isLineActive(String uuid)
    {
        TraderLyncCall traderLyncCall1 = getUser().getCurrentHS1Call();
        TraderLyncCall traderLyncCall2 = getUser().getCurrentHS2Call();

        boolean active = false;

        if (traderLyncCall1 != null && !"".equals(traderLyncCall1.uuid))
        {
            if (uuid.equals(String.valueOf(Long.parseLong(traderLyncCall1.uuid))))
                active = true;
        }

        if (traderLyncCall2 != null && !"".equals(traderLyncCall2.uuid))
        {
            if (uuid.equals(String.valueOf(Long.parseLong(traderLyncCall2.uuid))))
                active = true;
        }

        return active;
    }

    public boolean getHandsetBusyStatus()
    {
        TraderLyncCall traderLyncCall1 = getUser().getCurrentHS1Call();
        TraderLyncCall traderLyncCall2 = getUser().getCurrentHS2Call();

        if (traderLyncCall1 == null && traderLyncCall2 == null)
            return false;

        Iterator it2 = traderLyncCalls.values().iterator();
        boolean busy1 = false;
        boolean busy2 = false;

        while( it2.hasNext() )
        {
            TraderLyncCall traderLyncCall = (TraderLyncCall)it2.next();

            if (traderLyncCall1 != null && traderLyncCall.getCallID().equals(traderLyncCall1.getCallID()))
            {
                busy1 = true;
            }

            if (traderLyncCall2 != null && traderLyncCall.getCallID().equals(traderLyncCall2.getCallID()))
            {
                busy2 = true;
            }
        }

        return  busy1 && busy2;
    }

    public int getActiveCalls()
    {
        Iterator it2 = traderLyncCalls.values().iterator();
        int calls = 0;

        while( it2.hasNext() )
        {
            TraderLyncCall traderLyncCall = (TraderLyncCall)it2.next();

            if (! "ConnectionCleared".equals(traderLyncCall.getState()))
            {
                calls++;
            }
        }

        return calls;
    }

    public boolean getBusyStatus()
    {
        return (getActiveCalls() >= getMaxNumCalls());
    }

    public String getCallFWD() {
        return callFWD;
    }

    public void setCallFWD(String callFWD) {
        this.callFWD = callFWD;
    }

    public String getCallFWDDigits() {
        return callFWDDigits;
    }

    public void setCallFWDDigits(String callFWDDigits) {
        this.callFWDDigits = callFWDDigits;
    }

    public void setMaxNumCalls(int maxNumCalls) {
        this.maxNumCalls = maxNumCalls;
    }

    public int getMaxNumCalls() {
        return maxNumCalls;
    }

    public void logCall(TraderLyncCall traderLyncCall, String domain, long site)
    {
        String callId =  traderLyncCall.getCallID() + "-" + System.currentTimeMillis();
        String tscId = traderLyncCall.line;

        Log.debug("writing call record " + callId + " " + tscId + " " + traderLyncCall.getState());

        CallLogger.getLogger().logCall(tscId, callId, getUser().getProfileName(), getInterestName(), traderLyncCall.getState(), traderLyncCall.direction, traderLyncCall.creationTimeStamp, traderLyncCall.getDuration(), traderLyncCall.getCallerNumber(getInterest().getInterestType()), traderLyncCall.getCallerName(getInterest().getInterestType()), traderLyncCall.getCalledNumber(getInterest().getInterestType()), traderLyncCall.getCalledName(getInterest().getInterestType()));

        Iterator it3 = getInterest().getUserInterests().values().iterator();

        while( it3.hasNext() )
        {
            TraderLyncUserInterest traderLyncParticipant = (TraderLyncUserInterest)it3.next();

            TraderLyncCall participantCall = traderLyncParticipant.getCallByLine(traderLyncCall.getLine());

            if (participantCall != null)
            {
                Log.debug("writing call participant record " + callId + " " + traderLyncParticipant.getUser().getUserId() + " " + participantCall.getState());

                if ("CallMissed".equals(participantCall.getState()))
                {
                    CallLogger.getLogger().logParticipant(tscId, callId, traderLyncParticipant.getUser().getUserId() + "@" + traderLyncParticipant.getUser().getUserNo() + "." + domain, participantCall.direction, participantCall.firstParticipation, participantCall.creationTimeStamp, participantCall.getRingDuration());
                }
                else {
                    CallLogger.getLogger().logParticipant(tscId, callId, traderLyncParticipant.getUser().getUserId() + "@" + traderLyncParticipant.getUser().getUserNo() + "." + domain, participantCall.direction, participantCall.firstParticipation, participantCall.firstTimeStamp, participantCall.getDuration());
                }
            }
        }
    }
}
