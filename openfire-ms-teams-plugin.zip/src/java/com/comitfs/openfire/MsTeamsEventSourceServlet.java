package com.comitfs.openfire;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

import org.slf4j.*;
import org.slf4j.Logger;

import org.eclipse.jetty.servlets.EventSource;
import org.eclipse.jetty.servlets.EventSourceServlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jivesoftware.openfire.http.HttpBindManager;

public class MsTeamsEventSourceServlet extends EventSourceServlet
{
    private static final Logger Log = LoggerFactory.getLogger(MsTeamsEventSourceServlet.class);
    private static final long serialVersionUID = 1L;
    public static MsTeamsEventSource source;

    @Override protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      writeHeader(response);
      super.doGet(request, response);
    }

    @Override protected EventSource newEventSource(final HttpServletRequest req)
    {
        source = new MsTeamsEventSource();
        return source;
    }

    private void writeHeader(HttpServletResponse response)
    {
        try {
            response.setHeader("Content-Type", "text/event-stream");

            HttpBindManager boshManager = HttpBindManager.getInstance();

            response.setHeader("Access-Control-Allow-Origin", boshManager.getCORSAllowOrigin());
            response.setHeader("Access-Control-Allow-Headers", HttpBindManager.HTTP_BIND_CORS_ALLOW_HEADERS_DEFAULT + ", Authorization");
            response.setHeader("Access-Control-Allow-Credentials", "true");
            response.setHeader("Access-Control-Allow-Methods", HttpBindManager.HTTP_BIND_CORS_ALLOW_METHODS_DEFAULT);

        }
        catch(Exception e)
        {
            Log.debug("download - servlet writeHeader Error: " + e.toString());
        }
    }

    public class MsTeamsEventSource implements EventSource
    {
        private Emitter emitter;

        public void onOpen(Emitter emitter)
        {
            try {
                this.emitter = emitter;
                //this.emitter.data("hello world");
                this.emitter.event("sse-event", "hello world");
            } catch (Exception e) {
                Log.error("onOpen", e);
            }
        }

        public void emitEvent(String dataToSend)
        {
            try {
                //this.emitter.data(dataToSend);
                this.emitter.event("sse-event", dataToSend);
            } catch (Exception e) {
                Log.error("emitEvent", e);
            }
        }

        public void onClose()
        {
        }
    }
}