package com.comitfs.openfire;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import org.slf4j.*;
import org.slf4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jivesoftware.openfire.SessionManager;
import org.jivesoftware.openfire.XMPPServer;
import org.jivesoftware.openfire.http.HttpBindManager;

import com.ifsoft.traderlync.openlink.component.*;
import net.sf.json.*;
import org.xmpp.packet.JID;

public class WebhookServlet extends HttpServlet {
    private static final Logger Log = LoggerFactory.getLogger(WebhookServlet.class);
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Log.info(String.format("handling: %s on %s", req.getRequestURI(), WebhookServlet.class.getSimpleName()));
        Log.info("HTTP Headers");

        writeHeader(resp);
        resp.setStatus(HttpServletResponse.SC_ACCEPTED);

        Collections.list(req.getHeaderNames())
            .stream()
            .map(header -> header + ": " + req.getHeader(header))
            .forEach(Log::debug);

        String body = req.getReader().lines().collect(Collectors.joining());
        Log.info("HTTP Payload\n" + body);

        JSONObject call = new JSONObject(body);
        Log.info("HTTP JSON\n" + call);
        MsTeams.self.outgoingCall(call);
    }

    private void writeHeader(HttpServletResponse response)
    {

        try {
            HttpBindManager boshManager = HttpBindManager.getInstance();

            response.setHeader("Access-Control-Allow-Origin", boshManager.getCORSAllowOrigin());
            response.setHeader("Access-Control-Allow-Headers", HttpBindManager.HTTP_BIND_CORS_ALLOW_HEADERS_DEFAULT + ", Authorization");
            response.setHeader("Access-Control-Allow-Credentials", "true");
            response.setHeader("Access-Control-Allow-Methods", HttpBindManager.HTTP_BIND_CORS_ALLOW_METHODS_DEFAULT);

        }
        catch(Exception e)
        {
            Log.debug("download - servlet writeHeader Error: " + e.toString());
        }
    }
}