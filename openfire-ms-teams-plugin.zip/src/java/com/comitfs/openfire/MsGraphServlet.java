package com.comitfs.openfire;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import org.slf4j.*;
import org.slf4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jivesoftware.openfire.SessionManager;
import org.jivesoftware.openfire.XMPPServer;
import org.jivesoftware.openfire.http.HttpBindManager;

import com.ifsoft.traderlync.openlink.component.*;
import net.sf.json.*;
import org.xmpp.packet.JID;
import org.apache.commons.text.StringEscapeUtils;

public class MsGraphServlet extends HttpServlet {
    private static final Logger Log = LoggerFactory.getLogger(MsGraphServlet.class);
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Log.info(String.format("handling: %s on %s", req.getRequestURI(), MsGraphServlet.class.getSimpleName()));
        Log.info("HTTP Headers");

        Collections.list(req.getHeaderNames())
            .stream()
            .map(header -> header + ": " + req.getHeader(header))
            .forEach(Log::info);

        String validationToken = req.getParameter("validationToken");

        if (validationToken != null)
        {
            Log.info("validationToken\n" + validationToken);
            resp.setHeader("content-type", "text/plain");
            resp.getOutputStream().print(StringEscapeUtils.escapeHtml4(validationToken));
            resp.setStatus(HttpServletResponse.SC_ACCEPTED);

        }
        else {
            resp.setStatus(HttpServletResponse.SC_ACCEPTED);
            String body = req.getReader().lines().collect(Collectors.joining());
            JSONObject json = new JSONObject(body);
            Log.info("HTTP Payload\n" + json);

            if (json.has("value"))
            {
                JSONArray array = json.getJSONArray("value");

                for (int i = 0; i < array.length(); i++)
                {
                    JSONObject value = array.getJSONObject(i);
                    JSONObject resourceData = value.getJSONObject("resourceData");

                    if (resourceData.has("@odata.type") && resourceData.getString("@odata.type").equals("#microsoft.graph.call"))
                    {
                        Log.info("commsNotifications\n" + value);

                        if (value.has("resourceUrl"))
                        {
                            try {
                                String changeType = value.getString("changeType");

                                if ("created".equals(changeType))
                                {
                                    String resourceUrl = value.getString("resourceUrl");
                                    String callId = resourceUrl.split("/")[3];

                                    if (resourceData.has("source") && resourceData.has("callRoutes"))
                                    {
                                        JSONArray callRoutes = resourceData.getJSONArray("callRoutes");
                                        JSONObject callRoute = callRoutes.getJSONObject(0);
                                        JSONObject original = callRoute.getJSONObject("original");

                                        JSONObject source = resourceData.getJSONObject("source");
                                        JSONObject identity = source.getJSONObject("identity");
                                        String callChainId = resourceData.getString("callChainId");

                                        if (identity.has("phone") && original.has("phone"))
                                        {
                                            String calleeId = original.getJSONObject("phone").getString("id");
                                            String callerId = identity.getJSONObject("phone").getString("id");
                                            Log.info("commsNotifications - resourceUrl " + resourceUrl + " " + callerId + " " + callId + " " + callChainId);

                                            MsTeams.self.redirectCall(callId, callerId, calleeId, callChainId);
                                        }
                                        else {
                                            MsTeams.self.rejectCall(callId);
                                        }
                                    }
                                    else {
                                        MsTeams.self.rejectCall(callId);
                                    }
                                }

                            } catch (Exception e) {
                                Log.error("sendServerMessage failed", e);
                            }
                        }
                    }
                    else

                    if (resourceData.has("oDataType") && resourceData.getString("oDataType").equals("#microsoft.graph.callrecord"))
                    {
                        String resource = value.getString("resource");
                        MsTeams.self.getCallRecord(resource);
                    }

                }
            }
            else

            if (json.has("channelData") && json.has("serviceUrl") && json.has("from"))
            {
                String auth = req.getHeader("Authorization");
                MsTeams.self.getChatMessage(auth, json);
            }
        }
    }
}