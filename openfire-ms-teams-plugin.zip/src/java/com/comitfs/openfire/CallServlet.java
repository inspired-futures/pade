package com.comitfs.openfire;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import org.slf4j.*;
import org.slf4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jivesoftware.openfire.SessionManager;
import org.jivesoftware.openfire.XMPPServer;
import org.jivesoftware.openfire.http.HttpBindManager;

import com.ifsoft.traderlync.openlink.component.*;
import net.sf.json.*;
import org.xmpp.packet.JID;
import org.apache.commons.text.StringEscapeUtils;

public class CallServlet extends HttpServlet {
    private static final Logger Log = LoggerFactory.getLogger(CallServlet.class);
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Log.info(String.format("handling: %s on %s", req.getRequestURI(), CallServlet.class.getSimpleName()));
        Log.info("HTTP Headers");

        Collections.list(req.getHeaderNames())
            .stream()
            .map(header -> header + ": " + req.getHeader(header))
            .forEach(Log::info);

        String validationToken = req.getParameter("validationToken");
        String callid = req.getParameter("callid");

        if (validationToken != null)
        {
            Log.info("validationToken\n" + validationToken);
            resp.setHeader("content-type", "text/plain");
            resp.getOutputStream().print(StringEscapeUtils.escapeHtml4(validationToken));
            resp.setStatus(HttpServletResponse.SC_ACCEPTED);

        }
        else {
            resp.setStatus(HttpServletResponse.SC_ACCEPTED);
            String body = req.getReader().lines().collect(Collectors.joining());
            Log.info("HTTP Payload " + callid + "\n" + body);

            try {
                //SessionManager sessionManager = XMPPServer.getInstance().getSessionManager();
                //String message = req.getRequestURI() + "\n" + body;
                //sessionManager.sendServerMessage(null, null, message);
            } catch (Exception e) {
                Log.error("sendServerMessage failed", e);
            }
        }
    }
}