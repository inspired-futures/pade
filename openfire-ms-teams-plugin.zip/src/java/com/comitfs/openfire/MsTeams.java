package com.comitfs.openfire;

import java.io.File;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.*;
import java.util.concurrent.*;

import org.jivesoftware.openfire.container.*;
import org.jivesoftware.openfire.http.HttpBindManager;
import org.jivesoftware.openfire.XMPPServer;
import org.jivesoftware.openfire.user.User;
import org.jivesoftware.openfire.user.UserNotFoundException;
import org.jivesoftware.openfire.group.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.eclipse.jetty.apache.jsp.JettyJasperInitializer;
import org.eclipse.jetty.plus.annotation.ContainerInitializer;
import org.eclipse.jetty.server.handler.ContextHandlerCollection;
import org.eclipse.jetty.servlet.*;
import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.webapp.WebAppContext;
import org.eclipse.jetty.util.security.*;
import org.eclipse.jetty.security.*;
import org.eclipse.jetty.security.authentication.*;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.microsoft.graph.requests.extensions.*;
import com.microsoft.graph.auth.confidentialClient.*;
import com.microsoft.graph.models.extensions.Subscription;
import com.microsoft.graph.models.extensions.*;
import com.microsoft.graph.models.generated.*;
import com.microsoft.graph.auth.enums.*;
import com.microsoft.graph.authentication.*;
import com.microsoft.graph.httpcore.*;

import com.microsoft.bot.connector.authentication.SimpleCredentialProvider;
import com.microsoft.bot.connector.authentication.SimpleChannelProvider;
import com.microsoft.bot.connector.authentication.CredentialProvider;
import com.microsoft.bot.connector.authentication.JwtTokenValidation;
import com.microsoft.bot.connector.authentication.MicrosoftAppCredentials;
import com.microsoft.bot.connector.rest.RestConnectorClient;
import com.microsoft.bot.schema.*;

import org.apache.tomcat.InstanceManager;
import org.apache.tomcat.SimpleInstanceManager;

import org.xmpp.component.ComponentManager;
import org.xmpp.component.ComponentManagerFactory;

import org.jivesoftware.util.*;
import com.ifsoft.traderlync.openlink.component.Site;
import com.ifsoft.traderlync.openlink.component.*;
import org.xmpp.packet.JID;
import org.xmpp.packet.Message;

import com.google.gson.Gson;
import org.apache.http.HttpResponse;
import nl.martijndwars.webpush.*;
import com.google.gson.JsonObject;
import net.sf.json.*;

public class MsTeams implements Plugin
{
    private static final Logger Log = LoggerFactory.getLogger(MsTeams.class);
    public static MsTeams self;

    private ComponentManager componentManager;
    private TraderLyncComponent traderLyncComponent = null;
    private WebAppContext context;

    //private String clientId  = "d4de7bf7-11ee-437d-b225-b01397d6a744";
    //private String clientSecret = "HAG0t.680x~8pDMPJ~5D~jVb2AST-eEZfR";

    private String clientId  = "2bc0e78e-4f70-41b1-bbdc-023c88cce69c";
    private String clientSecret = "8XTIVX4bX.X123SP8gJkdIDDee~P7Y2_-e";
    private String tenantId = "a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e";
    private String botId = "7b0e71d9-7c83-48b3-8a66-60cb930a99b8";
    private String pTeamId = "a:1e1WMceUCbRtIVgGLKRPOMuFl9l_AOcLTnM8eHkDVEhxgbYGWfhOi9HJS9kn4fUC5LEIG18oUQkMsjNOS1u0FfkYiV8TiYRAoysW6oxSQ3mG8HMIF3xgX94ngJXUbh8Q_";
    private String publicUrl = "https://pade.chat:5443/apps"; //eg https://c2ddde53.ngrok.io no trailing slash
    private String resource = "communications/callRecords";
    private String changeType = "created";

    private NationalCloud endpoint = NationalCloud.Global;
    private List scopes = Arrays.asList("https://graph.microsoft.com/.default");
    private IGraphServiceClient graphClient;

    private String webClientId = null;
    private String webAgentPhone = "442081428949";
    private String webClientPhone = "447825589457";
    private String webClientName = "JJ Garland";

    private ObjectMapper objectMapper;
    private CredentialProvider credentialProvider;
    private MicrosoftAppCredentials credentials;
    private Map<String, Activity> conversations;

    public void destroyPlugin()
    {
        if (componentManager != null) {
            try {
                traderLyncComponent.componentDestroyed();
                componentManager.removeComponent("traderlynk");
            } catch (Exception e) {
                Log.error(e.getMessage(), e);
            }
        }
        traderLyncComponent = null;
        HttpBindManager.getInstance().removeJettyHandler(context);
    }

    public void initializePlugin(final PluginManager manager, final File pluginDirectory)
    {
        self = this;
        componentManager = ComponentManagerFactory.getComponentManager();

        Site site = new Site();
        site.setSiteID(1);
        site.setName( XMPPServer.getInstance().getServerInfo().getXMPPDomain());
        traderLyncComponent = new TraderLyncComponent(site);

        try {
            componentManager.addComponent("traderlynk", traderLyncComponent);
            traderLyncComponent.componentEnable();

        } catch (Exception e) {
            Log.error(e.getMessage(), e);
        }

        context = new WebAppContext(null, pluginDirectory.getPath() + "/classes/apps", "/apps");
        context.setClassLoader(this.getClass().getClassLoader());
        final List<ContainerInitializer> initializers = new ArrayList<>();
        initializers.add(new ContainerInitializer(new JettyJasperInitializer(), null));
        context.setAttribute("org.eclipse.jetty.containerInitializers", initializers);
        context.setAttribute(InstanceManager.class.getName(), new SimpleInstanceManager());
        context.setWelcomeFiles(new String[]{"index.html"});
        HttpBindManager.getInstance().addJettyHandler(context);

        ClientCredentialProvider authProvider = new ClientCredentialProvider(clientId, scopes, clientSecret, tenantId, endpoint);
        graphClient = GraphServiceClient.builder().authenticationProvider(authProvider).buildClient();
        graphClient.setServiceRoot("https://graph.microsoft.com/v1.0");

        objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false).findAndRegisterModules();
        credentialProvider = new SimpleCredentialProvider(clientId, clientSecret);
        credentials = new MicrosoftAppCredentials(clientId, clientSecret);
        conversations  = new ConcurrentHashMap<String, Activity>();
        Log.info("Bot Connector initialised");
    }

    public void subscribe()
    {
        Subscription subscription = new Subscription();
        subscription.changeType = this.changeType;
        subscription.notificationUrl = this.publicUrl + "/notify-call-records";
        subscription.resource = this.resource;
        subscription.expirationDateTime = Calendar.getInstance();
        subscription.clientState = "secretClientValue";
        subscription.expirationDateTime.add(Calendar.HOUR, 1);
        subscription = graphClient.subscriptions().buildRequest().post(subscription);
        Log.info("Subscribed to entity with subscription id " + subscription.id);
    }

    public void sendChatMessage(Activity activity, String body, Activity newActivity)
    {
        RestConnectorClient connector = new RestConnectorClient(activity.getServiceUrl(), credentials);

        if (newActivity == null)
        {
            newActivity = new Activity(ActivityTypes.MESSAGE); //Activity.clone(activity);
            ChannelAccount bot = new ChannelAccount(activity.getRecipient().getId(), activity.getRecipient().getName(), RoleTypes.BOT, botId);
            ChannelAccount user = new ChannelAccount(activity.getFrom().getId(), activity.getFrom().getName(), RoleTypes.USER, activity.getFrom().getAadObjectId());
            newActivity.setText(body);
            newActivity.setRecipient(user);
            newActivity.setFrom(bot);
            newActivity.setTextFormat(TextFormatTypes.MARKDOWN);
        }

        connector.getConversations().sendToConversation(activity.getConversation().getId(), newActivity);
        Log.info("sendChatMessage to " + activity.getFrom().getAadObjectId() + " " + activity.getServiceUrl() + "\n" + body);
    }

    public void sendBotMessage(String from, String body)
    {
        Activity activity = conversations.get(from);
        if (activity != null) sendChatMessage(activity, body, null);
    }

    public void sendAllBotNotification(String body)
    {
        for (Activity activity : conversations.values())
        {
            sendChatMessage(activity, body, null);
        }
    }

    public void getChatMessage(String authHeader, JSONObject json)
    {
        JSONObject fromObj = json.getJSONObject("from");
        String from = fromObj.getString("id");
        if (fromObj.has("aadObjectId")) from = fromObj.getString("aadObjectId");

        String body = json.toString();
        Log.info("getChatMessage from " + from + "\n" + body);

        Activity activity = conversations.get(from);

        if (activity == null)
        {
            try {
                activity = objectMapper.readValue(body, Activity.class);
                JwtTokenValidation.authenticateRequest(activity, authHeader, credentialProvider, new SimpleChannelProvider());
                conversations.put(from, activity);
            } catch (Exception ex) {
                Log.error("Failed to get activity", ex);
            }
        }

        String text = json.getString("text");
        String channelId = json.getString("channelId");

        if ("msteams".equals(channelId)) {

            if (webClientId != null) {

                if ("info".equals(text)) {
                    sendCallCardToActivity(activity, webClientPhone, "Chat Conversation");
                } else {
                    forwardToWebClient(json);
                }
            } else {
                sendChatMessage(activity, "_Ok_", null);
            }
        } else {
            webClientId = fromObj.getString("id");

            if (!forwardToAgents(json)) sendChatMessage(activity, "_No customer representative is available_", null);
        }
    }

    private void forwardToWebClient(JSONObject json)
    {
        String text = json.getString("text");
        String name = json.getJSONObject("from").getString("name");

        Activity activity = conversations.get(webClientId);

        if (activity != null)
        {
            sendChatMessage(activity, "**" + name + "**: " + text, null);
        }
    }

    private boolean forwardToAgents(JSONObject json)
    {
        boolean forwarded = false;

        try {
            org.jivesoftware.openfire.group.Group group = GroupManager.getInstance().getGroup(webAgentPhone);

            if (group != null)
            {
                for (JID memberJID : group.getMembers())
                {
                    forwarded = forwarded || forwardToAgent(memberJID.getNode(), json);
                }

                for (JID memberJID : group.getAdmins())
                {
                    forwarded = forwarded || forwardToAgent(memberJID.getNode(), json);
                }
            }

        } catch (Exception e) {
            Log.error("forwardToAgents failed", e);
        }
        return forwarded;
    }

    private boolean forwardToAgent(String username, JSONObject json)
    {
        try
        {
            User xmppUser = XMPPServer.getInstance().getUserManager().getUser(username);
            Map<String, String> userProperties = xmppUser.getProperties();
            String userObject = userProperties.get("msteams.object.id");

            if (userObject != null)
            {
                String text = json.getString("text");
                Activity activity = conversations.get(userObject);

                if (activity != null)
                {
                    sendChatMessage(activity, "**" + webClientName + "**: " + text, null);
                    return true;
                }
            }
        } catch (Exception e) {
            Log.error("forwardToAgent failed", e);
        }
        return false;
    }

    public void getCallRecord(String resource)
    {
        graphClient.setServiceRoot("https://graph.microsoft.com/v1.0");
        JsonObject response = graphClient.customRequest("/" + resource + "?$expand=sessions($expand=segments)").buildRequest().get();
        JSONObject call = new JSONObject(response.toString());
        Log.info("Call Record\n" + call);
        String farParty = "Outgoing";
        String callId = call.getString("id");
        boolean missed = true;
        boolean outgoing = false;
        boolean incoming = false;

        if (call.has("organizer"))
        {
            JSONObject organizer = call.getJSONObject("organizer");
            try {
                if (organizer.has("phone")) farParty = organizer.getJSONObject("phone").getString("id");
                incoming = true;
            } catch (Exception e) {}
        }

        if (call.has("sessions"))
        {
            JSONObject session = call.getJSONArray("sessions").getJSONObject(0);
            JSONObject segment = session.getJSONArray("segments").getJSONObject(0);

            if (incoming)
            {
                JSONArray media = segment.getJSONArray("media");
                if (media.length() > 0) missed = false;
            }
            else {
                try {
                    farParty = segment.getJSONObject("callee").getJSONObject("identity").getJSONObject("phone").getString("id");
                    callId = farParty;
                    outgoing = true;
                } catch (Exception e) {
                    try {
                        farParty = segment.getJSONObject("callee").getJSONObject("identity").getJSONObject("user").getString("id");
                        callId = farParty;
                        outgoing = true;
                    } catch (Exception e1) {}
                }
            }
        }

        if (incoming || outgoing)
        {
            Log.info("processing call " + callId + " " + missed + " " + incoming + " " + outgoing + " " + farParty);

            sendNotification("**Call Record**", farParty);
            traderLyncComponent.hangupEvent(callId, missed);
        }
        else {
            Log.warn("Ignoring call \n" + call);
        }
    }

    public void rejectCall(String callId)
    {
        RejectReason reason = RejectReason.NONE;
        graphClient.setServiceRoot("https://graph.microsoft.com/v1.0");
        graphClient.communications().calls(callId).reject(reason,null).buildRequest().post();
    }

    public void redirectCall(String callId, String callerId, String calleeId, String callChainId)
    {
        LinkedList<InvitationParticipantInfo> targetsList = new LinkedList<InvitationParticipantInfo>();

        try {
            String destination = calleeId.substring(1);
            String source = callerId.substring(1);
            org.jivesoftware.openfire.group.Group group = GroupManager.getInstance().getGroup(destination); // remove prefix +

            if (group != null)
            {
                String callee = group.getName();

                traderLyncComponent.ringingEvent(source, destination, callChainId, null);

                for (JID memberJID : group.getMembers())
                {
                    targetsList.add(createTarget(memberJID.getNode(), source));
                }

                for (JID memberJID : group.getAdmins())
                {
                    targetsList.add(createTarget(memberJID.getNode(), source));
                }

                String callbackUri = publicUrl + "/calls?callid=" + callId;
                graphClient.setServiceRoot("https://graph.microsoft.com/v1.0");
                graphClient.communications().calls(callId).redirect(targetsList,null,callbackUri).buildRequest().post();
            }

        } catch (Exception e) {
            Log.error("redirectCall failed", e);
        }
    }

    public void outgoingCall(JSONObject call)
    {
        Log.info("outgoingCall " + call);

        String destination = call.getString("destination").substring(1);
        String username = call.getString("username");

        try
        {
            User xmppUser = XMPPServer.getInstance().getUserManager().getUser(username);
            Map<String, String> userProperties = xmppUser.getProperties();
            String userObject = userProperties.get("msteams.object.id");

            if (userObject != null)
            {
                String userInterest =  userProperties.get("msteams.phone.number") + username;
                sendCallCard(userObject, destination, "Outgoing Call");
                traderLyncComponent.makeCall(null, userInterest, "1", null, null, destination, destination);
            }
        }
        catch (Exception e)
        {
            Log.error( "outgoingCall - failed", e );
        }
    }

    private InvitationParticipantInfo createTarget(String username, String source)
    {
        InvitationParticipantInfo target = new InvitationParticipantInfo();

        try
        {
            User xmppUser = XMPPServer.getInstance().getUserManager().getUser(username);
            Map<String, String> userProperties = xmppUser.getProperties();
            String userObject = userProperties.get("msteams.object.id");

            if (userObject != null)
            {
                IdentitySet identity = new IdentitySet();
                Identity user = new Identity();
                user.displayName = xmppUser.getName();
                user.id = userObject;
                identity.user = user;
                target.identity = identity;

                sendCallCard(userObject, source, "Incoming Call");
            }
        }
        catch ( UserNotFoundException e )
        {
            Log.debug( "Not a recognized user.", e );
        }
        return target;
    }

    private void sendCallCard(String userObject, String source, String prefix)
    {
        Activity activity = conversations.get(userObject);

        if (activity != null)
        {
            sendCallCardToActivity(activity, source, prefix);
        }
    }

    private void sendCallCardToActivity(Activity activity, String source, String prefix)
    {
        String callerName = source;
        String callerNotify = "yellow";
        String callerTitle = "";
        String callerOrg = "";
        String callerResearch = "";

        if (traderLyncComponent.reverseSpeeedDials.containsKey(source))
        {
            JSONObject json = traderLyncComponent.reverseSpeeedDials.get(source);
            callerName = json.getString("name");
            callerNotify = json.getString("notification");
            callerTitle = json.getString("title");
            callerOrg = json.getString("org");
            callerResearch = json.getString("research");
        }

        try {
            Activity newActivity = new Activity(ActivityTypes.MESSAGE);
            ChannelAccount bot = new ChannelAccount(activity.getRecipient().getId(), activity.getRecipient().getName(), RoleTypes.BOT, botId);
            ChannelAccount recepient = new ChannelAccount(activity.getFrom().getId(), activity.getFrom().getName(), RoleTypes.USER, activity.getFrom().getAadObjectId());
            newActivity.setRecipient(recepient);
            newActivity.setFrom(bot);

            ThumbnailCard thumbnailCard = new ThumbnailCard();
            thumbnailCard.setTitle(prefix + " : " + callerName);
            thumbnailCard.setSubtitle(callerTitle + ", " + callerOrg);
            thumbnailCard.setText(callerResearch);
            thumbnailCard.setImage(new CardImage(publicUrl + "/smart-call/" + callerNotify + "-notification.png"));

            if (!"".equals(callerResearch))
            {
                List<CardAction> buttons = new ArrayList<>();
                CardAction accept = new CardAction();
                accept.setTitle("View Caller Details ");
                String encodedContext = URLEncoder.encode("{\"subEntityId\":\"" + source + "\"}", "UTF-8");
                accept.setValue("https://teams.microsoft.com/l/entity/a37600c5-4e19-40ff-8728-8b997755a8d9/ubs.smartapp.smartcall?label=Smart%32Call&context=" + encodedContext);
                accept.setType(ActionTypes.OPEN_URL);
                accept.setDisplayText("Displaying details for " + callerName);
                buttons.add(accept);
                thumbnailCard.setButtons(buttons);
            }

            newActivity.setAttachments(new ArrayList<>());
            newActivity.getAttachments().add(thumbnailCard.toAttachment());

            sendChatMessage(activity, "", newActivity);
        } catch (Exception err) {
            Log.error("InvitationParticipantInfo failed", err);
        }
    }

    public void sendNotification(String notification, String callerId)
    {
        String username = "dele_olajide.net";
        try
        {
            User xmppUser = XMPPServer.getInstance().getUserManager().getUser(JID.escapeNode(username));
            Map<String, String> userProperties = xmppUser.getProperties();
            String userObject = userProperties.get("msteams.object.id");

            if (userObject != null)
            {
                sendBotMessage(userObject, notification + " " + callerId);
            }

        }
        catch ( UserNotFoundException e )
        {
            Log.debug( "Not a recognized user.", e );
        }
    }

    private void webPush( final User user, final String body, String callerId, Message.Type msgtype )
    {
        try {
            for (String key : user.getProperties().keySet())
            {
                if (key.startsWith("webpush.subscribe."))
                {
                    String publicKey = user.getProperties().get("vapid.public.key");
                    String privateKey = user.getProperties().get("vapid.private.key");

                    if (publicKey == null) publicKey = JiveGlobals.getProperty("vapid.public.key", null);
                    if (privateKey == null) privateKey = JiveGlobals.getProperty("vapid.private.key", null);

                    if (publicKey != null && privateKey != null)
                    {
                        PushService pushService = new PushService()
                            .setPublicKey(publicKey)
                            .setPrivateKey(privateKey)
                            .setSubject("mailto:admin@" + XMPPServer.getInstance().getServerInfo().getXMPPDomain());

                        nl.martijndwars.webpush.Subscription subscription = new Gson().fromJson(user.getProperties().get(key), nl.martijndwars.webpush.Subscription.class);
                        Stanza stanza = new Stanza(msgtype == Message.Type.chat ? "chat" : "groupchat", callerId, body);
                        Notification notification = new Notification(subscription, (new Gson().toJson(stanza)).toString());
                        HttpResponse response = pushService.send(notification);
                        int statusCode = response.getStatusLine().getStatusCode();

                        Log.debug( "For user '{}', Web push notification response '{}'", user.toString(), response.getStatusLine().getStatusCode() );
                    }
                }
            }
        } catch (Exception e) {
            Log.warn( "An exception occurred while trying send a web push for user '{}'.", new Object[] { user, e } );
        }
    }
}