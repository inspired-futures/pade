function catcalc(cal) 
{
	var endDateField = $('endDate');
	var startDateField = $('startDate');

	var endTime = new Date(endDateField.value);
	var startTime = new Date(startDateField.value);
	
	if(endTime.getTime() < startTime.getTime()){
	    alert("");
	    startDateField.value = "";
	}
}
   

function grayOut(ele) {
    if (ele.value == 'Any') {
	ele.style.backgroundColor = "#FFFBE2";
    }
    else {
	ele.style.backgroundColor = "#ffffff";
    }
}

function hover(oRow) 
{
    oRow.style.background = "#A6CAF0";
    oRow.style.cursor = "pointer";
}

function noHover(oRow) 
{
    oRow.style.background = "white";
}

function submitFormAgain(start, range){
    document.f.start.value = start;
    document.f.range.value = range;
    document.f.parseRange.value = "true";
    document.f.submit();
}

function loaded()
{
	Calendar.setup(
	{
		inputField  : "startDate",         // ID of the input field
		ifFormat    : "%m/%d/%y",    // the date format
		button      : "startDateTrigger",       // ID of the button
		onUpdate    :  catcalc
	});

	Calendar.setup(
	{
		inputField  : "endDate",         // ID of the input field
		ifFormat    : "%m/%d/%y",    // the date format
		button      : "endDateTrigger",       // ID of the button
		onUpdate    :  catcalc
	});
}
 