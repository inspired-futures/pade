(function() {
  $(function() {
    FastClick.attach(document.body);
    return $(document).foundation();
  });

}).call(this);