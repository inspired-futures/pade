Feature parity with SfB can only be claimed if a replacement for UCMA, or at the very least the Lync SDK (client SDK) is provided.

The Bot Framework plus Graph/Calling API is a clumsy solution.

Unlike UCMA or Slack, a bot can not listen into a conversation without being @mentioned which defeats the essence of cognitive assistance bots as well as other sentiment analysis or assistive productivity applications. Microsoft has substituted its notion of privacy controls in this implementation for what a company ought to be able to decide for its own tenant.

The HTTP based architecture is perceptibly slow compared to the socket based architecture of UCMA and the local inter process communication based architecture of the Lync client SDK. It has many moving parts ( Teams client <> Teams/O365 <> Bot Framework <> Bot), each a http based connection with associated connections set up/tear down to deliver a basic message.

Finally, presence updates are atrociously slow which is a deal breaker for contact center apps that rely on agent presence/availability.

deep-linking-example

https://teams.microsoft.com/l/chat/0/0?users=dele@comitfs.com&topicName=Prep%20For%20Meeting%20Tomorrow&message=Hi%20folks%2C%20kicking%20off%20a%20chat%20about%20our%20meeting%20tomorrow

-------------------------------------------------------------------------------------------------------------

app/client id - d4de7bf7-11ee-437d-b225-b01397d6a744
directory tennant id - a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e
object id - e6b76654-b435-482e-89db-f5ba21f838bb

token endpoint - https://login.microsoftonline.com/common/oauth2/v2.0/token

secret - HAG0t.680x~8pDMPJ~5D~jVb2AST-eEZfR

https://login.microsoftonline.com/a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e/oauth2/v2.0/token

client_id=d4de7bf7-11ee-437d-b225-b01397d6a744
scope=https%3A%2F%2Fgraph.microsoft.com%2F.default
client_secret=HAG0t.680x~8pDMPJ~5D~jVb2AST-eEZfR
grant_type=client_credentials

eyJ0eXAiOiJKV1QiLCJub25jZSI6IlVwSVROaWxMbV9GX0x3bC04ZUJ6Mi1fVWF6TE83eXJHZjlFWFBPeUswWFkiLCJhbGciOiJSUzI1NiIsIng1dCI6Imh1Tjk1SXZQZmVocTM0R3pCRFoxR1hHaXJuTSIsImtpZCI6Imh1Tjk1SXZQZmVocTM0R3pCRFoxR1hHaXJuTSJ9.eyJhdWQiOiJodHRwczovL2dyYXBoLm1pY3Jvc29mdC5jb20iLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9hODNlYzk2Zi04MmIwLTQ1NmUtOTBhMi1hNmJhMWNlN2ZjNGUvIiwiaWF0IjoxNTk0OTIwNzQ3LCJuYmYiOjE1OTQ5MjA3NDcsImV4cCI6MTU5NDkyNDY0NywiYWlvIjoiRTJCZ1lDakpFUkxndTFiNCtzV1hhNC9xZlV0NUFBPT0iLCJhcHBfZGlzcGxheW5hbWUiOiJjb21pdGZzLWRlbW8iLCJhcHBpZCI6ImQ0ZGU3YmY3LTExZWUtNDM3ZC1iMjI1LWIwMTM5N2Q2YTc0NCIsImFwcGlkYWNyIjoiMSIsImlkcCI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0L2E4M2VjOTZmLTgyYjAtNDU2ZS05MGEyLWE2YmExY2U3ZmM0ZS8iLCJvaWQiOiJjN2QwYWQ2YS01MjNhLTQwMmUtYTQ3ZC05MWE5MDExNmE0YjUiLCJyb2xlcyI6WyJDYWxscy5Kb2luR3JvdXBDYWxsLkFsbCIsIkNhbGxzLkluaXRpYXRlR3JvdXBDYWxsLkFsbCIsIkNhbGxzLkpvaW5Hcm91cENhbGxBc0d1ZXN0LkFsbCIsIkNhbGxSZWNvcmRzLlJlYWQuQWxsIiwiQ2hhdC5SZWFkLkFsbCIsIkNoYXQuUmVhZFdyaXRlLkFsbCIsIkNoYXQuUmVhZEJhc2ljLkFsbCIsIkNhbGxzLkFjY2Vzc01lZGlhLkFsbCIsIkNhbGxzLkluaXRpYXRlLkFsbCJdLCJzdWIiOiJjN2QwYWQ2YS01MjNhLTQwMmUtYTQ3ZC05MWE5MDExNmE0YjUiLCJ0ZW5hbnRfcmVnaW9uX3Njb3BlIjoiRVUiLCJ0aWQiOiJhODNlYzk2Zi04MmIwLTQ1NmUtOTBhMi1hNmJhMWNlN2ZjNGUiLCJ1dGkiOiJaSEw5aWFlVGtFZXVRVlo5U25EVkFBIiwidmVyIjoiMS4wIiwieG1zX3RjZHQiOjEzMzA4MDYwNzN9.BxSvo9nSB-uXpLfjTwyNkZz9JGnmS2aVEIoznr4sjnbVj_khRDGFe3Yh__IAahFfFuDhEM3qbIX3Ir9ZK3jdPycfOxpww6MMvayg2517Wi6eoZEi8GZPscwU0GLwzJoF5RWsdA64kYApHShkh-pNfhwdI-sD-FX3FIF0F7StPQu3-crwJDyQZxrwvdyKn9MlYSyYo5mVasT3GJAO3652aTW1-INxDW1Z_941a-NZNm0ZFXL-scAOeYgswABSguO-88ypNkfrFIPHyIBxctA3e5udTbhCywnetVg1WXm0_uQHcawS5VU8LVFJMb8Umhvj5UF1QVkpPZcKB5jDH_ea7Q


-------------------------------------------------------------------------------------------------------------

            "team id": "e7dac6d7-53aa-4a22-9843-55931c5a8b02",
            channel id - 19:f8bbad41d134450f80e07e3f3ce8d36e@thread.tacv2
            
https://graph.microsoft.com/v1.0/teams/e7dac6d7-53aa-4a22-9843-55931c5a8b02/channels            
            
https://graph.microsoft.com/beta/teams/{group-id-for-teams}/channels/e7dac6d7-53aa-4a22-9843-55931c5a8b02/messages            


https://graph.microsoft.com/beta/teams/e7dac6d7-53aa-4a22-9843-55931c5a8b02/channels/19:f8bbad41d134450f80e07e3f3ce8d36e@thread.tacv2/messages

me id = 83ec482c-3bc5-4116-acee-e081cc720630
https://graph.microsoft.com/beta/users/83ec482c-3bc5-4116-acee-e081cc720630/chats

https://graph.microsoft.com/beta/users/83ec482c-3bc5-4116-acee-e081cc720630/chats/19:34fdaa50-5486-47ae-8ae2-0aa1ebd424c5_83ec482c-3bc5-4116-acee-e081cc720630@unq.gbl.spaces/messages


            "id": "19:34fdaa50-5486-47ae-8ae2-0aa1ebd424c5_83ec482c-3bc5-4116-acee-e081cc720630@unq.gbl.spaces
            
            
document.querySelectorAll(".ts-sym.app-title-bar-button.calling-sharing-panel-dialog")[1].click() 

-------------------------------------------------------------------------------------------------------------


document.body.addEventListener("click", function(evt)
{
    const h2 = document.getElementById("chat-header-title");
    const span = document.querySelector(".federation-chat-header>span"); 
    const img = document.querySelector("profile-picture>img");   
    const button = evt.target.querySelector(".icons-filled");

    console.log("WWWWWWWWWWWWWWW target", button, evt.target);    
        
    if (h2 && span && img && button)
    {   
        const name = h2.getAttribute("title");
        const destination = span.getAttribute("title"); 
        const source = img.getAttribute("upn"); 
        const body = {name: name, source: source, destination: destination};        
        
        fetch("https://pade.chat:5443/apps/webhook", {method: "POST", body: JSON.stringify(body)}).then(function(response)
        {
            console.debug('connection ok', response);

        }).catch(function (err) {
            console.error('connection error', err);
        });
    }
});
var eventSource = new EventSource("https://pade.chat:5443/apps/sse");

eventSource.onmessage = function(event)
{
    console.info("Server-Sent Event: " + event.data);
};
eventSource.addEventListener('open', function(e)
{
    console.info("Server-Sent Event opened: ", e);
});

eventSource.addEventListener('sse-event', function(event)
{
    console.info("Server-Sent Event: " + event.data);
});

eventSource.onerror = function(e)
{
    console.error(e);
};

-------------------------------------------------------------------------------------------------------------

        mainWindow.webContents.openDevTools();
        //const code = `top.addEventListener("message", function(evt){console.log("smart app command", evt);eval(evt.data)});`;
        const code = `document.body.addEventListener("click", function(evt) { const h2 = document.getElementById("chat-header-title"); const span = document.querySelector(".federation-chat-header>span");  const img = document.querySelector("profile-picture>img");    const button = evt.target.querySelector(".icons-filled"); console.log("WWWWWWWWWWWWWWW target", button, evt.target);     if (h2 && span && img && button) {    const name = h2.getAttribute("title"); const destination = span.getAttribute("title");  const source = img.getAttribute("upn");  const body = {name: name, source: source, destination: destination};         fetch("https://pade.chat:5443/apps/webhook", {method: "POST", body: JSON.stringify(body)}).then(function(response) { console.debug('connection ok', response); }).catch(function (err) { console.error('connection error', err); }); } }); var eventSource = new EventSource("https://pade.chat:5443/apps/sse"); eventSource.onmessage = function(event) { console.info("Server-Sent Event: " + event.data); }; eventSource.addEventListener('open', function(e) { console.info("Server-Sent Event opened: ", e); }); eventSource.addEventListener('sse-event', function(event) { console.info("Server-Sent Event: " + event.data); }); eventSource.onerror = function(e) { console.error(e); };`;
        mainWindow.webContents.executeJavaScript(code, true);

-------------------------------------------------------------------------------------------------------------


Import-Module SkypeOnlineConnector
$userCredential = Get-Credential
$sfbSession = New-CsOnlineSession -Credential $userCredential
Import-PSSession $sfbSession


-------------------------------------------------------------------------------------------------------------

New-CsOnlineApplicationInstance -UserPrincipalName smartcall@olajide.net -ApplicationId "d4de7bf7-11ee-437d-b225-b01397d6a744" -DisplayName "UBS Smart Call"
New-CsOnlineApplicationInstance -UserPrincipalName ubsdemo@olajide.net -ApplicationId "1167cb51-58de-496c-80f5-241f9ead5fb5" -DisplayName "UBS Demo"

RunspaceId        : 79300c31-0392-485c-b277-d40c5417676d
ObjectId          : a90d3648-2309-4e85-8918-0ec00108b946
TenantId          : a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e
UserPrincipalName : smartcall@olajide.net
ApplicationId     : d4de7bf7-11ee-437d-b225-b01397d6a744
DisplayName       : UBS Smart Call
PhoneNumber       :

Sync-CsOnlineApplicationInstance -ObjectId a90d3648-2309-4e85-8918-0ec00108b946

powerbot comitfs-demo
1167cb51-58de-496c-80f5-241f9ead5fb5
bot-id 453c603c-072a-4fac-8551-264e2569c808
tenant id - a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e

-------------------------------------------------------------------------------------------------------------

BOT Framework

app/client-id - 2bc0e78e-4f70-41b1-bbdc-023c88cce69c
tenant id - a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e
password - 8XTIVX4bX.X123SP8gJkdIDDee~P7Y2_-e

New-CsOnlineApplicationInstance -UserPrincipalName smartcall@olajide.net -ApplicationId "2bc0e78e-4f70-41b1-bbdc-023c88cce69c" -DisplayName "UBS Smart Call"
Sync-CsOnlineApplicationInstance -ObjectId 7b0e71d9-7c83-48b3-8a66-60cb930a99b8

Set-CsOnlineVoiceApplicationInstance -Identity smartcall@olajide.net -TelephoneNumber ?+442081428949
Get-CsOnlineTelephoneNumber -TelephoneNumber +442081428949
-------------------------------------------------------------------------------------------------------------
2020.08.04 15:49:33 INFO [Jetty-QTP-BOSH-1676441]: com.comitfs.openfire.MsGraphServlet - handling: /apps/notify-call-records on MsGraphServlet
2020.08.04 15:49:33 INFO [Jetty-QTP-BOSH-1676441]: com.comitfs.openfire.MsGraphServlet - HTTP Headers
2020.08.04 15:49:33 INFO [Jetty-QTP-BOSH-1676441]: com.comitfs.openfire.MsGraphServlet - Authorization: Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6Imo4SjBlZGt3OTMyZ2lUdDU1dnY3WWxxZG43ZyIsInR5cCI6IkpXVCIsIng1dCI6Imo4SjBlZGt3OTMyZ2lUdDU1dnY3WWxxZG43ZyJ9.eyJ0aWQiOiJhODNlYzk2Zi04MmIwLTQ1NmUtOTBhMi1hNmJhMWNlN2ZjNGUiLCJhcHBpZCI6IjI2YTE4ZWJjLWNkZjctNGE2YS05MWNiLWJlYjM1MjgwNWU4MSIsIm5iZiI6MTU5NjU1NjE3MiwiZXhwIjoxNTk2NTU2NDcyLCJpc3MiOiJodHRwczovL2FwaS5ib3RmcmFtZXdvcmsuY29tIiwiYXVkIjoiMmJjMGU3OGUtNGY3MC00MWIxLWJiZGMtMDIzYzg4Y2NlNjljIn0.bUzqkqQXjpz5XXyTC1xrVsuplcNt_X3nL3Ctv2DtlBPVbCa_2rLUEJlPC2y-Ksspgdjlk6EqYmEhIpC4eTZuD23WqWR40rCeD39lUyZu08zjqlLhFlIr9pDIdQ2BTFydsRtwrJCVLMCWK4cmfvMhJFUXshSEUCmIFlv6jBlJCtyUIcPqsK_1fPCmLfxIUtWkGVSEX-yCZ9uKVhSwc8wEkjvA7n-UFJu6x4knX05W-m_S27Fb_X9CTdHVmRYEhqasbaT4rnvtxrPHA6-OejG8bu2i4Fr7cdKksNQGLF6QkjVM9yik3IR9cwG3yxbjsMXRNQi-5Uvel3TlksgpN4h80g
2020.08.04 15:49:33 INFO [Jetty-QTP-BOSH-1676441]: com.comitfs.openfire.MsGraphServlet - X-Microsoft-Skype-Message-ID: 42edd253-9dd1-4854-b8b4-88c892cb42d3
2020.08.04 15:49:33 INFO [Jetty-QTP-BOSH-1676441]: com.comitfs.openfire.MsGraphServlet - Accept: application/json
2020.08.04 15:49:33 INFO [Jetty-QTP-BOSH-1676441]: com.comitfs.openfire.MsGraphServlet - X-Microsoft-Skype-Callee-Region: emea
2020.08.04 15:49:33 INFO [Jetty-QTP-BOSH-1676441]: com.comitfs.openfire.MsGraphServlet - User-Agent: Microsoft-Skype/3.0 (Calling/1.0)
2020.08.04 15:49:33 INFO [Jetty-QTP-BOSH-1676441]: com.comitfs.openfire.MsGraphServlet - Connection: keep-alive
2020.08.04 15:49:33 INFO [Jetty-QTP-BOSH-1676441]: com.comitfs.openfire.MsGraphServlet - Host: pade.chat:5443
2020.08.04 15:49:33 INFO [Jetty-QTP-BOSH-1676441]: com.comitfs.openfire.MsGraphServlet - Content-Length: 1955
2020.08.04 15:49:33 INFO [Jetty-QTP-BOSH-1676441]: com.comitfs.openfire.MsGraphServlet - X-Microsoft-Skype-Chain-ID: 9a8810cb-4be9-4c9d-8690-0e22fcfe53ff
2020.08.04 15:49:33 INFO [Jetty-QTP-BOSH-1676441]: com.comitfs.openfire.MsGraphServlet - Content-Type: application/json
2020.08.04 15:49:33 INFO [Jetty-QTP-BOSH-1676441]: com.comitfs.openfire.MsGraphServlet - HTTP Payload
{"@odata.type":"#microsoft.graph.commsNotifications","value":[{"@odata.type":"#microsoft.graph.commsNotification","changeType":"created","resource":"/app/calls/631f0300-0420-4e00-ab49-9524783075ed","resourceUrl":"/communications/calls/631f0300-0420-4e00-ab49-9524783075ed","resourceData":{"@odata.type":"#microsoft.graph.call","state":"incoming","direction":"incoming","callbackUri":"https://pade.chat:5443/apps/notify-call-records","callRoutes":[{"@odata.type":"#microsoft.graph.callRoute","routingType":"lookup","original":{"@odata.type":"#microsoft.graph.identitySet","phone":{"@odata.type":"#microsoft.graph.identity","id":"+442081428949","identityProvider":"None"}},"final":{"@odata.type":"#microsoft.graph.identitySet","applicationInstance":{"@odata.type":"#microsoft.graph.identity","id":"7b0e71d9-7c83-48b3-8a66-60cb930a99b8","identityProvider":"AAD"}}}],"source":{"@odata.type":"#microsoft.graph.participantInfo","id":"ce3e5bc0-a781-4af0-9e9a-f7efd4c9d13c","identity":{"@odata.type":"#microsoft.graph.identitySet","phone":{"@odata.type":"#microsoft.graph.identity","id":"+447825589457","tenantId":"00000000-0000-0000-0000-000000000000","identityProvider":"None"}},"endpointType":"default"},"targets":[{"@odata.type":"#microsoft.graph.invitationParticipantInfo","identity":{"@odata.type":"#microsoft.graph.identitySet","applicationInstance":{"@odata.type":"#microsoft.graph.identity","id":"7b0e71d9-7c83-48b3-8a66-60cb930a99b8","tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e","identityProvider":"AAD"}},"endpointType":"default","id":"2386440b-8fb2-44d6-b396-d68d13f5183e","region":"emea","languageId":null}],"tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e","myParticipantId":"2386440b-8fb2-44d6-b396-d68d13f5183e","callChainId":"9a8810cb-4be9-4c9d-8690-0e22fcfe53ff","incomingContext":{"@odata.type":"#microsoft.graph.incomingContext","sourceParticipantId":"ce3e5bc0-a781-4af0-9e9a-f7efd4c9d13c"},"id":"631f0300-0420-4e00-ab49-9524783075ed"}}]}

2020.08.04 18:06:57 INFO [Jetty-QTP-BOSH-1750236]: com.comitfs.openfire.MsGraphServlet - handling: /apps/notify-call-records on MsGraphServlet
2020.08.04 18:06:57 INFO [Jetty-QTP-BOSH-1750236]: com.comitfs.openfire.MsGraphServlet - HTTP Headers
2020.08.04 18:06:57 INFO [Jetty-QTP-BOSH-1750236]: com.comitfs.openfire.MsGraphServlet - Authorization: Bearer ew0KICAiYWxnIjogIlJTMjU2IiwNCiAgImtpZCI6ICJ5QVZ0OVBxaTZFcnh2ZUJLTlZ3c21EZ1ZDMGsiLA0KICAieDV0IjogInlBVnQ5UHFpNkVyeHZlQktOVndzbURnVkMwayIsDQogICJ0eXAiOiAiSldUIg0KfQ.ew0KICAic2VydmljZXVybCI6ICJodHRwczovL3dlYmNoYXQuYm90ZnJhbWV3b3JrLmNvbS8iLA0KICAibmJmIjogMTU5NjU2NDQxNywNCiAgImV4cCI6IDE1OTY1NjUwMTcsDQogICJpc3MiOiAiaHR0cHM6Ly9hcGkuYm90ZnJhbWV3b3JrLmNvbSIsDQogICJhdWQiOiAiMmJjMGU3OGUtNGY3MC00MWIxLWJiZGMtMDIzYzg4Y2NlNjljIg0KfQ.FFgSdO13h8FJDYCbbx7yitxwUD1RAtutGs-IT-cDYxxeHdcAbncIiGLeek1BzGFBiM3-UEc9mQBq02IzrcDtLolDGEUtAkrkg1K8ms6QZS8dR55654CEoQc-iYbDib4ekaq91Vz4Ld4p7fj6a6-qk8QdhmDCb2hEjxTH3ixi3OTewfAicw4xpZtaGIschDV0RZhgEFJQRKlKtSUWMpmHmr-WxuGR0cFHEpcaZwuwM2-h8Jn2id73sN4V0lf1eoPWAekRp2GUrho2DPd5oDN9_23Q5lEqoRBrVsTR7kI4hDL0nm_3UXZ2zwtwOId_7NU582RaiCLRg5JlMlPFc4ZKfg
2020.08.04 18:06:57 INFO [Jetty-QTP-BOSH-1750236]: com.comitfs.openfire.MsGraphServlet - x-ms-conversation-id: EAva16jKiEve73NTE4GZk-a
2020.08.04 18:06:57 INFO [Jetty-QTP-BOSH-1750236]: com.comitfs.openfire.MsGraphServlet - User-Agent: BF-DirectLine (Microsoft-BotFramework/3.2 +https://botframework.com/ua)
2020.08.04 18:06:57 INFO [Jetty-QTP-BOSH-1750236]: com.comitfs.openfire.MsGraphServlet - Connection: keep-alive
2020.08.04 18:06:57 INFO [Jetty-QTP-BOSH-1750236]: com.comitfs.openfire.MsGraphServlet - Host: pade.chat:5443
2020.08.04 18:06:57 INFO [Jetty-QTP-BOSH-1750236]: com.comitfs.openfire.MsGraphServlet - Content-Length: 627
2020.08.04 18:06:57 INFO [Jetty-QTP-BOSH-1750236]: com.comitfs.openfire.MsGraphServlet - Request-Id: |ffe107aefc77d345a2cc25950a815d49.f474de83_14.1.
2020.08.04 18:06:57 INFO [Jetty-QTP-BOSH-1750236]: com.comitfs.openfire.MsGraphServlet - Content-Type: application/json; charset=UTF-8
2020.08.04 18:06:57 INFO [Jetty-QTP-BOSH-1750236]: com.comitfs.openfire.MsGraphServlet - HTTP Payload
{"type":"message","id":"EAva16jKiEve73NTE4GZk-a|0000000","timestamp":"2020-08-04T18:06:57.6005002Z","serviceUrl":"https://webchat.botframework.com/","channelId":"webchat","from":{"id":"83ec482c-3bc5-4116-acee-e081cc720630","name":"You"},"conversation":{"id":"EAva16jKiEve73NTE4GZk-a"},"recipient":{"id":"ubs_smart_call@Aerg4d_3T0M","name":"UBS Smart Call"},"textFormat":"plain","locale":"en-US","text":"hello","entities":[{"type":"ClientCapabilities","requiresBotState":true,"supportsListening":true,"supportsTts":true}],"channelData":{"clientActivityID":"1596564417583li5dtokh5o","clientTimestamp":"2020-08-04T18:06:57.586Z"}}

-------------------------------------------------------------------------------------------------------------
----------------Incoming call notification-----------------

{
   "resourceUrl":"/communications/calls/ea1f0300-971f-4a80-9c2c-eb8ec1a876f4",
   "resource":"/app/calls/ea1f0300-971f-4a80-9c2c-eb8ec1a876f4",
   "@odata.type":"#microsoft.graph.commsNotification",
   "changeType":"created",
   "resourceData":{
      "incomingContext":{
         "@odata.type":"#microsoft.graph.incomingContext",
         "sourceParticipantId":"51a71bc0-f78f-41ad-aa9f-b9515de22078"
      },
      "@odata.type":"#microsoft.graph.call",
      "callbackUri":"https://pade.chat:5443/apps/notify-call-records",
      "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
      "callChainId":"f3abdc34-44ae-4f71-bed8-1202d00403ed",
      "state":"incoming",
      "source":{
         "endpointType":"default",
         "@odata.type":"#microsoft.graph.participantInfo",
         "identity":{
            "phone":{
               "@odata.type":"#microsoft.graph.identity",
               "tenantId":"00000000-0000-0000-0000-000000000000",
               "id":"+447825589457",
               "identityProvider":"None"
            },
            "@odata.type":"#microsoft.graph.identitySet"
         },
         "id":"51a71bc0-f78f-41ad-aa9f-b9515de22078"
      },
      "id":"ea1f0300-971f-4a80-9c2c-eb8ec1a876f4",
      "myParticipantId":"2422766a-5359-4d6b-9155-9101caffcb05",
      "callRoutes":[
         {
            "original":{
               "phone":{
                  "@odata.type":"#microsoft.graph.identity",
                  "id":"+442081428949",
                  "identityProvider":"None"
               },
               "@odata.type":"#microsoft.graph.identitySet"
            },
            "routingType":"lookup",
            "@odata.type":"#microsoft.graph.callRoute",
            "final":{
               "@odata.type":"#microsoft.graph.identitySet",
               "applicationInstance":{
                  "@odata.type":"#microsoft.graph.identity",
                  "id":"7b0e71d9-7c83-48b3-8a66-60cb930a99b8",
                  "identityProvider":"AAD"
               }
            }
         }
      ],
      "targets":[
         {
            "endpointType":"default",
            "@odata.type":"#microsoft.graph.invitationParticipantInfo",
            "identity":{
               "@odata.type":"#microsoft.graph.identitySet",
               "applicationInstance":{
                  "@odata.type":"#microsoft.graph.identity",
                  "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
                  "id":"7b0e71d9-7c83-48b3-8a66-60cb930a99b8",
                  "identityProvider":"AAD"
               }
            },
            "languageId":null,
            "id":"2422766a-5359-4d6b-9155-9101caffcb05",
            "region":"emea"
         }
      ],
      "direction":"incoming"
   }
}

----------------call record notification-----------------
{
   "value":[
      {
         "resource":"communications/callRecords/f3abdc34-44ae-4f71-bed8-1202d00403ed",
         "changeType":"created",
         "resourceData":{
            "oDataType":"#microsoft.graph.callrecord",
            "id":"f3abdc34-44ae-4f71-bed8-1202d00403ed",
            "oDataId":"communications/callRecords/f3abdc34-44ae-4f71-bed8-1202d00403ed"
         },
         "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
         "clientState":"secretClientValue",
         "subscriptionId":"499927d0-d099-46df-9c23-441dc9917d10",
         "subscriptionExpirationDateTime":"2020-08-07T18:01:24.273+00:00"
      }
   ]
}

----------------call record details-----------------
{
   "@odata.context":"https://graph.microsoft.com/v1.0/$metadata#communications/callRecords(sessions(segments()))/$entity",
   "id":"f3abdc34-44ae-4f71-bed8-1202d00403ed",
   "version":1,
   "type":"peerToPeer",
   "modalities":[
      "audio"
   ],
   "lastModifiedDateTime":"2020-08-07T17:16:49.7013304Z",
   "startDateTime":"2020-08-07T17:04:31.8822068Z",
   "endDateTime":"2020-08-07T17:05:01.9843209Z",
   "joinWebUrl":null,
   "organizer":{
      "user":null,
      "acsUser":null,
      "spoolUser":null,
      "phone":{
         "id":"+447825589457",
         "displayName":null,
         "tenantId":null
      },
      "guest":null,
      "encrypted":null,
      "onPremises":null,
      "acsApplicationInstance":null,
      "spoolApplicationInstance":null,
      "applicationInstance":null,
      "application":null,
      "device":null
   },
   "participants":[
      {
         "user":null,
         "acsUser":null,
         "spoolUser":null,
         "phone":{
            "id":"+447825589457",
            "displayName":null,
            "tenantId":null
         },
         "guest":null,
         "encrypted":null,
         "onPremises":null,
         "acsApplicationInstance":null,
         "spoolApplicationInstance":null,
         "applicationInstance":null,
         "application":null,
         "device":null
      },
      {
         "acsUser":null,
         "spoolUser":null,
         "phone":null,
         "guest":null,
         "encrypted":null,
         "onPremises":null,
         "acsApplicationInstance":null,
         "spoolApplicationInstance":null,
         "applicationInstance":null,
         "application":null,
         "device":null,
         "user":{
            "id":"7b0e71d9-7c83-48b3-8a66-60cb930a99b8",
            "displayName":null,
            "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e"
         }
      }
   ],
   "sessions@odata.context":"https://graph.microsoft.com/v1.0/$metadata#communications/callRecords('f3abdc34-44ae-4f71-bed8-1202d00403ed')/sessions(segments())",
   "sessions":[
      {
         "id":"f3abdc34-44ae-4f71-bed8-1202d00403ed",
         "modalities":[
            "audio"
         ],
         "startDateTime":"2020-08-07T17:04:31.8822068Z",
         "endDateTime":"2020-08-07T17:05:01.9843209Z",
         "failureInfo":null,
         "caller":{
            "@odata.type":"#microsoft.graph.callRecords.participantEndpoint",
            "feedback":null,
            "userAgent":{
               "@odata.type":"#microsoft.graph.callRecords.serviceUserAgent",
               "headerValue":null,
               "applicationVersion":null,
               "role":"mediationServer"
            },
            "identity":{
               "user":null,
               "acsUser":null,
               "spoolUser":null,
               "phone":{
                  "id":"+447825589457",
                  "displayName":null,
                  "tenantId":null
               },
               "guest":null,
               "encrypted":null,
               "onPremises":null,
               "acsApplicationInstance":null,
               "spoolApplicationInstance":null,
               "applicationInstance":null,
               "application":null,
               "device":null
            }
         },
         "callee":{
            "@odata.type":"#microsoft.graph.callRecords.participantEndpoint",
            "feedback":null,
            "userAgent":{
               "@odata.type":"#microsoft.graph.callRecords.clientUserAgent",
               "headerValue":"SkypeSpaces/1415/1.0.0.2020071017/os=windows; osVer=10; deviceType=computer; browser=edgeChromium; browserVer=84.0/TsCallingVersion=2020.24.01.5/Ovb=9788b934d5009dbdc68550bd35c663fbf07ac952",
               "applicationVersion":null,
               "platform":"web",
               "productFamily":"teams"
            },
            "identity":{
               "acsUser":null,
               "spoolUser":null,
               "phone":null,
               "guest":null,
               "encrypted":null,
               "onPremises":null,
               "acsApplicationInstance":null,
               "spoolApplicationInstance":null,
               "applicationInstance":null,
               "application":null,
               "device":null,
               "user":{
                  "id":"7b0e71d9-7c83-48b3-8a66-60cb930a99b8",
                  "displayName":null,
                  "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e"
               }
            }
         },
         "segments@odata.context":"https://graph.microsoft.com/v1.0/$metadata#communications/callRecords('f3abdc34-44ae-4f71-bed8-1202d00403ed')/sessions('f3abdc34-44ae-4f71-bed8-1202d00403ed')/segments",
         "segments":[
            {
               "id":"f3abdc34-44ae-4f71-bed8-1202d00403ed",
               "startDateTime":"2020-08-07T17:04:31.8822068Z",
               "endDateTime":"2020-08-07T17:05:01.9843209Z",
               "failureInfo":null,
               "caller":{
                  "@odata.type":"#microsoft.graph.callRecords.participantEndpoint",
                  "feedback":null,
                  "userAgent":{
                     "@odata.type":"#microsoft.graph.callRecords.serviceUserAgent",
                     "headerValue":null,
                     "applicationVersion":null,
                     "role":"mediationServer"
                  },
                  "identity":{
                     "user":null,
                     "acsUser":null,
                     "spoolUser":null,
                     "phone":{
                        "id":"+447825589457",
                        "displayName":null,
                        "tenantId":null
                     },
                     "guest":null,
                     "encrypted":null,
                     "onPremises":null,
                     "acsApplicationInstance":null,
                     "spoolApplicationInstance":null,
                     "applicationInstance":null,
                     "application":null,
                     "device":null
                  }
               },
               "callee":{
                  "@odata.type":"#microsoft.graph.callRecords.participantEndpoint",
                  "feedback":null,
                  "userAgent":{
                     "@odata.type":"#microsoft.graph.callRecords.clientUserAgent",
                     "headerValue":"SkypeSpaces/1415/1.0.0.2020071017/os=windows; osVer=10; deviceType=computer; browser=edgeChromium; browserVer=84.0/TsCallingVersion=2020.24.01.5/Ovb=9788b934d5009dbdc68550bd35c663fbf07ac952",
                     "applicationVersion":null,
                     "platform":"web",
                     "productFamily":"teams"
                  },
                  "identity":{
                     "acsUser":null,
                     "spoolUser":null,
                     "phone":null,
                     "guest":null,
                     "encrypted":null,
                     "onPremises":null,
                     "acsApplicationInstance":null,
                     "spoolApplicationInstance":null,
                     "applicationInstance":null,
                     "application":null,
                     "device":null,
                     "user":{
                        "id":"7b0e71d9-7c83-48b3-8a66-60cb930a99b8",
                        "displayName":null,
                        "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e"
                     }
                  }
               },
               "media":[
                  {
                     "label":"main-audio",
                     "callerNetwork":{
                        "ipAddress":"10.201.0.",
                        "subnet":"",
                        "linkSpeed":1000000000,
                        "connectionType":"wired",
                        "port":null,
                        "reflexiveIPAddress":"10.201.0.",
                        "relayIPAddress":"",
                        "relayPort":null,
                        "macAddress":"",
                        "wifiMicrosoftDriver":"",
                        "wifiMicrosoftDriverVersion":"",
                        "wifiVendorDriver":"",
                        "wifiVendorDriverVersion":"",
                        "wifiChannel":null,
                        "wifiBand":"unknown",
                        "basicServiceSetIdentifier":"",
                        "wifiRadioType":"unknown",
                        "wifiSignalStrength":null,
                        "wifiBatteryCharge":null,
                        "dnsSuffix":"",
                        "sentQualityEventRatio":null,
                        "receivedQualityEventRatio":null,
                        "delayEventRatio":null,
                        "bandwidthLowEventRatio":null
                     },
                     "calleeNetwork":{
                        "ipAddress":"10.0.138.176",
                        "subnet":"10.0.136.0",
                        "linkSpeed":4294967295,
                        "connectionType":"wired",
                        "port":49810,
                        "reflexiveIPAddress":"10.0.138.176",
                        "relayIPAddress":null,
                        "relayPort":null,
                        "macAddress":null,
                        "wifiMicrosoftDriver":null,
                        "wifiMicrosoftDriverVersion":null,
                        "wifiVendorDriver":null,
                        "wifiVendorDriverVersion":null,
                        "wifiChannel":null,
                        "wifiBand":"unknown",
                        "basicServiceSetIdentifier":null,
                        "wifiRadioType":"unknown",
                        "wifiSignalStrength":null,
                        "wifiBatteryCharge":null,
                        "dnsSuffix":null,
                        "sentQualityEventRatio":null,
                        "receivedQualityEventRatio":null,
                        "delayEventRatio":null,
                        "bandwidthLowEventRatio":null
                     },
                     "callerDevice":{
                        "captureDeviceName":"",
                        "captureDeviceDriver":"",
                        "renderDeviceName":"",
                        "renderDeviceDriver":"",
                        "sentSignalLevel":null,
                        "receivedSignalLevel":null,
                        "sentNoiseLevel":null,
                        "receivedNoiseLevel":null,
                        "initialSignalLevelRootMeanSquare":-20.6194,
                        "cpuInsufficentEventRatio":null,
                        "renderNotFunctioningEventRatio":null,
                        "captureNotFunctioningEventRatio":null,
                        "deviceGlitchEventRatio":null,
                        "lowSpeechToNoiseEventRatio":null,
                        "lowSpeechLevelEventRatio":null,
                        "deviceClippingEventRatio":null,
                        "howlingEventCount":0,
                        "renderZeroVolumeEventRatio":null,
                        "renderMuteEventRatio":null,
                        "micGlitchRate":null,
                        "speakerGlitchRate":null
                     },
                     "calleeDevice":{
                        "captureDeviceName":null,
                        "captureDeviceDriver":null,
                        "renderDeviceName":null,
                        "renderDeviceDriver":null,
                        "sentSignalLevel":null,
                        "receivedSignalLevel":null,
                        "sentNoiseLevel":null,
                        "receivedNoiseLevel":null,
                        "initialSignalLevelRootMeanSquare":null,
                        "cpuInsufficentEventRatio":null,
                        "renderNotFunctioningEventRatio":null,
                        "captureNotFunctioningEventRatio":null,
                        "deviceGlitchEventRatio":null,
                        "lowSpeechToNoiseEventRatio":null,
                        "lowSpeechLevelEventRatio":null,
                        "deviceClippingEventRatio":null,
                        "howlingEventCount":0,
                        "renderZeroVolumeEventRatio":null,
                        "renderMuteEventRatio":null,
                        "micGlitchRate":null,
                        "speakerGlitchRate":null
                     },
                     "streams":[
                        {
                           "streamId":"3724015916",
                           "startDateTime":"2020-08-07T17:04:31.8434395Z",
                           "endDateTime":"2020-08-07T17:05:02.0711473Z",
                           "streamDirection":"callerToCallee",
                           "averageAudioDegradation":0.01194,
                           "averageJitter":"PT0.002S",
                           "maxJitter":"PT0.003S",
                           "averagePacketLossRate":0,
                           "maxPacketLossRate":0,
                           "averageRatioOfConcealedSamples":0.0006662225,
                           "maxRatioOfConcealedSamples":0.001,
                           "averageRoundTripTime":"PT0.015S",
                           "maxRoundTripTime":"PT0.016S",
                           "packetUtilization":1505,
                           "averageBandwidthEstimate":5074100,
                           "wasMediaBypassed":false,
                           "postForwardErrorCorrectionPacketLossRate":null,
                           "averageVideoFrameLossPercentage":null,
                           "averageReceivedFrameRate":null,
                           "lowFrameRateRatio":null,
                           "averageVideoPacketLossRate":null,
                           "averageVideoFrameRate":null,
                           "lowVideoProcessingCapabilityRatio":null,
                           "averageAudioNetworkJitter":"PT0.008S",
                           "maxAudioNetworkJitter":"PT0.035S"
                        },
                        {
                           "streamId":"3221757635",
                           "startDateTime":"2020-08-07T17:04:31.8434395Z",
                           "endDateTime":"2020-08-07T17:05:02.0711473Z",
                           "streamDirection":"calleeToCaller",
                           "averageAudioDegradation":0,
                           "averageJitter":"PT0.001S",
                           "maxJitter":"PT0.001S",
                           "averagePacketLossRate":0,
                           "maxPacketLossRate":0,
                           "averageRatioOfConcealedSamples":0.00135318,
                           "maxRatioOfConcealedSamples":0,
                           "averageRoundTripTime":"PT0.018S",
                           "maxRoundTripTime":"PT0.019S",
                           "packetUtilization":1481,
                           "averageBandwidthEstimate":null,
                           "wasMediaBypassed":false,
                           "postForwardErrorCorrectionPacketLossRate":null,
                           "averageVideoFrameLossPercentage":null,
                           "averageReceivedFrameRate":null,
                           "lowFrameRateRatio":null,
                           "averageVideoPacketLossRate":null,
                           "averageVideoFrameRate":null,
                           "lowVideoProcessingCapabilityRatio":null,
                           "averageAudioNetworkJitter":"PT0.005S",
                           "maxAudioNetworkJitter":"PT0.01S"
                        }
                     ]
                  }
               ]
            }
         ]
      }
   ]
}    
-------------------------------------------------------------------------------------------------------------

dele

msteams.phone.number:   ‪+442045228153‬
msteams.user.id:    83ec482c-3bc5-4116-acee-e081cc720630

florence
msteams.phone.number:   ‪+442045228532‬
msteams.user.id:    ba9e081a-5748-40ca-8fd5-ab9c74dae3d1

-------------------------------------------------------------------------------------------------------------

--- outgoing telephone call -----

{
   "sessions@odata.context":"https://graph.microsoft.com/v1.0/$metadata#communications/callRecords('5fb40d79-03ed-4cc4-a0b7-664204f6aa7d')/sessions(segments())",
   "sessions":[
      {
         "segments@odata.context":"https://graph.microsoft.com/v1.0/$metadata#communications/callRecords('5fb40d79-03ed-4cc4-a0b7-664204f6aa7d')/sessions('5fb40d79-03ed-4cc4-a0b7-664204f6aa7d')/segments",
         "caller":{
            "feedback":null,
            "@odata.type":"#microsoft.graph.callRecords.participantEndpoint",
            "identity":{
               "spoolUser":null,
               "encrypted":null,
               "application":null,
               "acsUser":null,
               "phone":{
                  "displayName":null,
                  "tenantId":null,
                  "id":"+447825589457"
               },
               "spoolApplicationInstance":null,
               "applicationInstance":null,
               "acsApplicationInstance":null,
               "guest":null,
               "user":null,
               "device":null,
               "onPremises":null
            },
            "userAgent":{
               "applicationVersion":null,
               "role":"mediationServer",
               "@odata.type":"#microsoft.graph.callRecords.serviceUserAgent",
               "headerValue":null
            }
         },
         "modalities":[
            "audio"
         ],
         "startDateTime":"2020-08-09T16:44:31.8912797Z",
         "callee":{
            "feedback":null,
            "@odata.type":"#microsoft.graph.callRecords.participantEndpoint",
            "identity":{
               "spoolUser":null,
               "encrypted":null,
               "application":null,
               "acsUser":null,
               "phone":null,
               "spoolApplicationInstance":null,
               "applicationInstance":null,
               "acsApplicationInstance":null,
               "guest":null,
               "device":null,
               "user":{
                  "displayName":null,
                  "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
                  "id":"7b0e71d9-7c83-48b3-8a66-60cb930a99b8"
               },
               "onPremises":null
            },
            "userAgent":{
               "applicationVersion":null,
               "productFamily":"teams",
               "@odata.type":"#microsoft.graph.callRecords.clientUserAgent",
               "headerValue":"SkypeSpaces/1415/1.0.0.2020071017/os=windows; osVer=10; deviceType=computer; browser=edgeChromium; browserVer=84.0/TsCallingVersion=2020.24.01.5/Ovb=9788b934d5009dbdc68550bd35c663fbf07ac952",
               "platform":"web"
            }
         },
         "id":"5fb40d79-03ed-4cc4-a0b7-664204f6aa7d",
         "endDateTime":"2020-08-09T16:44:40.3132247Z",
         "failureInfo":null,
         "segments":[
            {
               "caller":{
                  "feedback":null,
                  "@odata.type":"#microsoft.graph.callRecords.participantEndpoint",
                  "identity":{
                     "spoolUser":null,
                     "encrypted":null,
                     "application":null,
                     "acsUser":null,
                     "phone":{
                        "displayName":null,
                        "tenantId":null,
                        "id":"+447825589457"
                     },
                     "spoolApplicationInstance":null,
                     "applicationInstance":null,
                     "acsApplicationInstance":null,
                     "guest":null,
                     "user":null,
                     "device":null,
                     "onPremises":null
                  },
                  "userAgent":{
                     "applicationVersion":null,
                     "role":"mediationServer",
                     "@odata.type":"#microsoft.graph.callRecords.serviceUserAgent",
                     "headerValue":null
                  }
               },
               "startDateTime":"2020-08-09T16:44:31.8912797Z",
               "callee":{
                  "feedback":null,
                  "@odata.type":"#microsoft.graph.callRecords.participantEndpoint",
                  "identity":{
                     "spoolUser":null,
                     "encrypted":null,
                     "application":null,
                     "acsUser":null,
                     "phone":null,
                     "spoolApplicationInstance":null,
                     "applicationInstance":null,
                     "acsApplicationInstance":null,
                     "guest":null,
                     "device":null,
                     "user":{
                        "displayName":null,
                        "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
                        "id":"7b0e71d9-7c83-48b3-8a66-60cb930a99b8"
                     },
                     "onPremises":null
                  },
                  "userAgent":{
                     "applicationVersion":null,
                     "productFamily":"teams",
                     "@odata.type":"#microsoft.graph.callRecords.clientUserAgent",
                     "headerValue":"SkypeSpaces/1415/1.0.0.2020071017/os=windows; osVer=10; deviceType=computer; browser=edgeChromium; browserVer=84.0/TsCallingVersion=2020.24.01.5/Ovb=9788b934d5009dbdc68550bd35c663fbf07ac952",
                     "platform":"web"
                  }
               },
               "id":"5fb40d79-03ed-4cc4-a0b7-664204f6aa7d",
               "media":[
                  {
                     "callerNetwork":{
                        "wifiVendorDriver":"",
                        "subnet":"",
                        "wifiMicrosoftDriverVersion":"",
                        "wifiRadioType":"unknown",
                        "bandwidthLowEventRatio":null,
                        "receivedQualityEventRatio":null,
                        "wifiBand":"unknown",
                        "ipAddress":"10.20.124.",
                        "wifiMicrosoftDriver":"",
                        "basicServiceSetIdentifier":"",
                        "linkSpeed":1000000000,
                        "reflexiveIPAddress":"10.20.124.",
                        "sentQualityEventRatio":null,
                        "relayIPAddress":"",
                        "connectionType":"wired",
                        "wifiBatteryCharge":null,
                        "wifiSignalStrength":null,
                        "macAddress":"",
                        "relayPort":null,
                        "port":null,
                        "dnsSuffix":"",
                        "delayEventRatio":null,
                        "wifiVendorDriverVersion":"",
                        "wifiChannel":null
                     },
                     "calleeNetwork":{
                        "wifiVendorDriver":"Marvell AVASTAR Wireless-AC Network Controller",
                        "subnet":"192.168.1.0",
                        "wifiMicrosoftDriverVersion":"Microsoft:10.0.19041.1",
                        "wifiRadioType":"unknown",
                        "bandwidthLowEventRatio":null,
                        "receivedQualityEventRatio":null,
                        "wifiBand":"unknown",
                        "ipAddress":"192.168.1.0",
                        "wifiMicrosoftDriver":"",
                        "basicServiceSetIdentifier":null,
                        "linkSpeed":null,
                        "reflexiveIPAddress":null,
                        "sentQualityEventRatio":null,
                        "relayIPAddress":"52.114.255.222",
                        "connectionType":"unknown",
                        "wifiBatteryCharge":0,
                        "wifiSignalStrength":0,
                        "macAddress":null,
                        "relayPort":3479,
                        "port":50005,
                        "dnsSuffix":null,
                        "delayEventRatio":null,
                        "wifiVendorDriverVersion":"Marvell Semiconductors, Inc.:15.68.17018.116",
                        "wifiChannel":0
                     },
                     "callerDevice":{
                        "receivedNoiseLevel":null,
                        "captureNotFunctioningEventRatio":null,
                        "howlingEventCount":0,
                        "renderMuteEventRatio":null,
                        "renderZeroVolumeEventRatio":null,
                        "deviceGlitchEventRatio":null,
                        "renderNotFunctioningEventRatio":null,
                        "deviceClippingEventRatio":null,
                        "receivedSignalLevel":null,
                        "renderDeviceDriver":"",
                        "captureDeviceName":"",
                        "micGlitchRate":null,
                        "cpuInsufficentEventRatio":null,
                        "speakerGlitchRate":null,
                        "lowSpeechToNoiseEventRatio":null,
                        "lowSpeechLevelEventRatio":null,
                        "captureDeviceDriver":"",
                        "sentSignalLevel":null,
                        "sentNoiseLevel":null,
                        "renderDeviceName":"",
                        "initialSignalLevelRootMeanSquare":90.97652
                     },
                     "calleeDevice":{
                        "receivedNoiseLevel":null,
                        "captureNotFunctioningEventRatio":null,
                        "howlingEventCount":null,
                        "renderMuteEventRatio":null,
                        "renderZeroVolumeEventRatio":null,
                        "deviceGlitchEventRatio":null,
                        "renderNotFunctioningEventRatio":null,
                        "deviceClippingEventRatio":null,
                        "receivedSignalLevel":null,
                        "renderDeviceDriver":null,
                        "captureDeviceName":null,
                        "micGlitchRate":null,
                        "cpuInsufficentEventRatio":null,
                        "speakerGlitchRate":null,
                        "lowSpeechToNoiseEventRatio":null,
                        "lowSpeechLevelEventRatio":null,
                        "captureDeviceDriver":null,
                        "sentSignalLevel":null,
                        "sentNoiseLevel":null,
                        "renderDeviceName":null,
                        "initialSignalLevelRootMeanSquare":null
                     },
                     "streams":[
                        {
                           "averageAudioDegradation":null,
                           "streamId":"2732229879",
                           "averageVideoFrameLossPercentage":null,
                           "maxAudioNetworkJitter":null,
                           "maxJitter":"PT0.002S",
                           "averageVideoPacketLossRate":null,
                           "maxRoundTripTime":"PT0.015S",
                           "lowVideoProcessingCapabilityRatio":null,
                           "postForwardErrorCorrectionPacketLossRate":null,
                           "maxPacketLossRate":0,
                           "averageRatioOfConcealedSamples":0,
                           "streamDirection":"callerToCallee",
                           "wasMediaBypassed":false,
                           "maxRatioOfConcealedSamples":null,
                           "averageReceivedFrameRate":null,
                           "averageBandwidthEstimate":53200836,
                           "endDateTime":"2020-08-09T16:44:40.4784992Z",
                           "averageVideoFrameRate":null,
                           "averageRoundTripTime":"PT0.015S",
                           "startDateTime":"2020-08-09T16:44:31.9792596Z",
                           "averagePacketLossRate":0,
                           "averageAudioNetworkJitter":null,
                           "lowFrameRateRatio":null,
                           "averageJitter":"PT0.002S",
                           "packetUtilization":420
                        },
                        {
                           "averageAudioDegradation":null,
                           "streamId":"2610765685",
                           "averageVideoFrameLossPercentage":null,
                           "maxAudioNetworkJitter":"PT0.007S",
                           "maxJitter":"PT0S",
                           "averageVideoPacketLossRate":null,
                           "maxRoundTripTime":null,
                           "lowVideoProcessingCapabilityRatio":null,
                           "postForwardErrorCorrectionPacketLossRate":null,
                           "maxPacketLossRate":0,
                           "averageRatioOfConcealedSamples":0.007389163,
                           "streamDirection":"calleeToCaller",
                           "wasMediaBypassed":false,
                           "maxRatioOfConcealedSamples":null,
                           "averageReceivedFrameRate":null,
                           "averageBandwidthEstimate":null,
                           "endDateTime":"2020-08-09T16:44:40.4784992Z",
                           "averageVideoFrameRate":null,
                           "averageRoundTripTime":null,
                           "startDateTime":"2020-08-09T16:44:31.9792596Z",
                           "averagePacketLossRate":0,
                           "averageAudioNetworkJitter":"PT0.005S",
                           "lowFrameRateRatio":null,
                           "averageJitter":"PT0S",
                           "packetUtilization":405
                        }
                     ],
                     "label":"main-audio"
                  }
               ],
               "endDateTime":"2020-08-09T16:44:40.3132247Z",
               "failureInfo":null
            }
         ]
      }
   ],
   "lastModifiedDateTime":"2020-08-09T16:57:22.3609474Z",
   "@odata.context":"https://graph.microsoft.com/v1.0/$metadata#communications/callRecords(sessions(segments()))/$entity",
   "type":"peerToPeer",
   "endDateTime":"2020-08-09T16:44:40.3132247Z",
   "version":1,
   "modalities":[
      "audio"
   ],
   "startDateTime":"2020-08-09T16:44:31.8912797Z",
   "joinWebUrl":null,
   "organizer":{
      "spoolUser":null,
      "encrypted":null,
      "application":null,
      "acsUser":null,
      "phone":{
         "displayName":null,
         "tenantId":null,
         "id":"+447825589457"
      },
      "spoolApplicationInstance":null,
      "applicationInstance":null,
      "acsApplicationInstance":null,
      "guest":null,
      "user":null,
      "device":null,
      "onPremises":null
   },
   "id":"5fb40d79-03ed-4cc4-a0b7-664204f6aa7d",
   "participants":[
      {
         "spoolUser":null,
         "encrypted":null,
         "application":null,
         "acsUser":null,
         "phone":{
            "displayName":null,
            "tenantId":null,
            "id":"+447825589457"
         },
         "spoolApplicationInstance":null,
         "applicationInstance":null,
         "acsApplicationInstance":null,
         "guest":null,
         "user":null,
         "device":null,
         "onPremises":null
      },
      {
         "spoolUser":null,
         "encrypted":null,
         "application":null,
         "acsUser":null,
         "phone":null,
         "spoolApplicationInstance":null,
         "applicationInstance":null,
         "acsApplicationInstance":null,
         "guest":null,
         "device":null,
         "user":{
            "displayName":null,
            "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
            "id":"7b0e71d9-7c83-48b3-8a66-60cb930a99b8"
         },
         "onPremises":null
      }
   ]
}
-------------------------------------------------------------------------------------------------------------

--- outgoing voip call ----

{
   "sessions@odata.context":"https://graph.microsoft.com/v1.0/$metadata#communications/callRecords('bf7f20f0-5843-4e93-9e67-3a92cd44700b')/sessions(segments())",
   "sessions":[
      {
         "segments@odata.context":"https://graph.microsoft.com/v1.0/$metadata#communications/callRecords('bf7f20f0-5843-4e93-9e67-3a92cd44700b')/sessions('bf7f20f0-5843-4e93-9e67-3a92cd44700b')/segments",
         "caller":{
            "feedback":null,
            "@odata.type":"#microsoft.graph.callRecords.participantEndpoint",
            "identity":{
               "spoolUser":null,
               "encrypted":null,
               "application":null,
               "acsUser":null,
               "phone":null,
               "spoolApplicationInstance":null,
               "applicationInstance":null,
               "acsApplicationInstance":null,
               "guest":null,
               "device":null,
               "user":{
                  "displayName":"Dele Olajide",
                  "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
                  "id":"83ec482c-3bc5-4116-acee-e081cc720630"
               },
               "onPremises":null
            },
            "userAgent":{
               "applicationVersion":null,
               "productFamily":"teams",
               "@odata.type":"#microsoft.graph.callRecords.clientUserAgent",
               "headerValue":"CallSignalingAgent (27/1.3.00.19173//;release_onthefly/shaotwan/20200626T235057Z.2020.20.01.11;releases/CL2020.R20)",
               "platform":"windows"
            }
         },
         "modalities":[
            "audio"
         ],
         "startDateTime":"2020-08-09T13:15:31.225961Z",
         "callee":{
            "feedback":null,
            "@odata.type":"#microsoft.graph.callRecords.participantEndpoint",
            "identity":{
               "spoolUser":null,
               "encrypted":null,
               "application":null,
               "acsUser":null,
               "phone":null,
               "spoolApplicationInstance":null,
               "applicationInstance":null,
               "acsApplicationInstance":null,
               "guest":null,
               "device":null,
               "user":{
                  "displayName":"Florence Olajide",
                  "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
                  "id":"ba9e081a-5748-40ca-8fd5-ab9c74dae3d1"
               },
               "onPremises":null
            },
            "userAgent":{
               "applicationVersion":null,
               "productFamily":"unknown",
               "@odata.type":"#microsoft.graph.callRecords.clientUserAgent",
               "headerValue":"MicrosoftTeamsVoicemailService (202007.26.1)",
               "platform":"unknown"
            }
         },
         "id":"bf7f20f0-5843-4e93-9e67-3a92cd44700b",
         "endDateTime":"2020-08-09T13:15:56.5602744Z",
         "failureInfo":null,
         "segments":[
            {
               "caller":{
                  "feedback":null,
                  "@odata.type":"#microsoft.graph.callRecords.participantEndpoint",
                  "identity":{
                     "spoolUser":null,
                     "encrypted":null,
                     "application":null,
                     "acsUser":null,
                     "phone":null,
                     "spoolApplicationInstance":null,
                     "applicationInstance":null,
                     "acsApplicationInstance":null,
                     "guest":null,
                     "device":null,
                     "user":{
                        "displayName":"Dele Olajide",
                        "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
                        "id":"83ec482c-3bc5-4116-acee-e081cc720630"
                     },
                     "onPremises":null
                  },
                  "userAgent":{
                     "applicationVersion":null,
                     "productFamily":"teams",
                     "@odata.type":"#microsoft.graph.callRecords.clientUserAgent",
                     "headerValue":"CallSignalingAgent (27/1.3.00.19173//;release_onthefly/shaotwan/20200626T235057Z.2020.20.01.11;releases/CL2020.R20)",
                     "platform":"windows"
                  }
               },
               "startDateTime":"2020-08-09T13:15:31.225961Z",
               "callee":{
                  "feedback":null,
                  "@odata.type":"#microsoft.graph.callRecords.participantEndpoint",
                  "identity":{
                     "spoolUser":null,
                     "encrypted":null,
                     "application":null,
                     "acsUser":null,
                     "phone":null,
                     "spoolApplicationInstance":null,
                     "applicationInstance":null,
                     "acsApplicationInstance":null,
                     "guest":null,
                     "device":null,
                     "user":{
                        "displayName":"Florence Olajide",
                        "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
                        "id":"ba9e081a-5748-40ca-8fd5-ab9c74dae3d1"
                     },
                     "onPremises":null
                  },
                  "userAgent":{
                     "applicationVersion":null,
                     "productFamily":"unknown",
                     "@odata.type":"#microsoft.graph.callRecords.clientUserAgent",
                     "headerValue":"MicrosoftTeamsVoicemailService (202007.26.1)",
                     "platform":"unknown"
                  }
               },
               "id":"bf7f20f0-5843-4e93-9e67-3a92cd44700b",
               "media":[
                  {
                     "callerNetwork":{
                        "wifiVendorDriver":"Marvell AVASTAR Wireless-AC Network Controller",
                        "subnet":"192.168.1.0",
                        "wifiMicrosoftDriverVersion":"Microsoft:10.0.19041.1",
                        "wifiRadioType":"unknown",
                        "bandwidthLowEventRatio":null,
                        "receivedQualityEventRatio":0,
                        "wifiBand":"unknown",
                        "ipAddress":"192.168.1.0",
                        "wifiMicrosoftDriver":"",
                        "basicServiceSetIdentifier":null,
                        "linkSpeed":100000000,
                        "reflexiveIPAddress":"90.248.57.230",
                        "sentQualityEventRatio":0,
                        "relayIPAddress":"52.114.233.210",
                        "connectionType":"wired",
                        "wifiBatteryCharge":0,
                        "wifiSignalStrength":0,
                        "macAddress":null,
                        "relayPort":3480,
                        "port":50004,
                        "dnsSuffix":null,
                        "delayEventRatio":0,
                        "wifiVendorDriverVersion":"Marvell Semiconductors, Inc.:15.68.17018.116",
                        "wifiChannel":0
                     },
                     "calleeNetwork":{
                        "wifiVendorDriver":null,
                        "subnet":"192.168.0.0",
                        "wifiMicrosoftDriverVersion":null,
                        "wifiRadioType":"unknown",
                        "bandwidthLowEventRatio":null,
                        "receivedQualityEventRatio":0,
                        "wifiBand":"unknown",
                        "ipAddress":"192.168.0.72",
                        "wifiMicrosoftDriver":null,
                        "basicServiceSetIdentifier":null,
                        "linkSpeed":4294967295,
                        "reflexiveIPAddress":"168.61.84.27",
                        "sentQualityEventRatio":0,
                        "relayIPAddress":"52.114.124.53",
                        "connectionType":"wired",
                        "wifiBatteryCharge":null,
                        "wifiSignalStrength":null,
                        "macAddress":null,
                        "relayPort":3480,
                        "port":52130,
                        "dnsSuffix":null,
                        "delayEventRatio":0,
                        "wifiVendorDriverVersion":null,
                        "wifiChannel":null
                     },
                     "callerDevice":{
                        "receivedNoiseLevel":-109,
                        "captureNotFunctioningEventRatio":0,
                        "howlingEventCount":0,
                        "renderMuteEventRatio":0,
                        "renderZeroVolumeEventRatio":0,
                        "deviceGlitchEventRatio":0,
                        "renderNotFunctioningEventRatio":0,
                        "deviceClippingEventRatio":0,
                        "receivedSignalLevel":-11,
                        "renderDeviceDriver":"Microsoft: 10.0.19041.388",
                        "captureDeviceName":"Jabra SPEAK 410 USB",
                        "micGlitchRate":null,
                        "cpuInsufficentEventRatio":0,
                        "speakerGlitchRate":null,
                        "lowSpeechToNoiseEventRatio":0,
                        "lowSpeechLevelEventRatio":0,
                        "captureDeviceDriver":"Microsoft: 10.0.19041.388",
                        "sentSignalLevel":null,
                        "sentNoiseLevel":null,
                        "renderDeviceName":"Jabra SPEAK 410 USB",
                        "initialSignalLevelRootMeanSquare":null
                     },
                     "calleeDevice":{
                        "receivedNoiseLevel":null,
                        "captureNotFunctioningEventRatio":0,
                        "howlingEventCount":0,
                        "renderMuteEventRatio":0,
                        "renderZeroVolumeEventRatio":0,
                        "deviceGlitchEventRatio":0,
                        "renderNotFunctioningEventRatio":0,
                        "deviceClippingEventRatio":0,
                        "receivedSignalLevel":null,
                        "renderDeviceDriver":null,
                        "captureDeviceName":"Audio",
                        "micGlitchRate":null,
                        "cpuInsufficentEventRatio":0,
                        "speakerGlitchRate":null,
                        "lowSpeechToNoiseEventRatio":0,
                        "lowSpeechLevelEventRatio":0,
                        "captureDeviceDriver":"Unknown:x.x.x.x",
                        "sentSignalLevel":null,
                        "sentNoiseLevel":null,
                        "renderDeviceName":null,
                        "initialSignalLevelRootMeanSquare":null
                     },
                     "streams":[
                        {
                           "averageAudioDegradation":0.05815125,
                           "streamId":"36297",
                           "averageVideoFrameLossPercentage":null,
                           "maxAudioNetworkJitter":"PT0.066S",
                           "maxJitter":"PT0.002S",
                           "averageVideoPacketLossRate":null,
                           "maxRoundTripTime":"PT0.041S",
                           "lowVideoProcessingCapabilityRatio":null,
                           "postForwardErrorCorrectionPacketLossRate":null,
                           "maxPacketLossRate":0,
                           "averageRatioOfConcealedSamples":0.01041667,
                           "streamDirection":"callerToCallee",
                           "wasMediaBypassed":null,
                           "maxRatioOfConcealedSamples":0.003996004,
                           "averageReceivedFrameRate":null,
                           "averageBandwidthEstimate":16016640,
                           "endDateTime":null,
                           "averageVideoFrameRate":null,
                           "averageRoundTripTime":"PT0.028S",
                           "startDateTime":null,
                           "averagePacketLossRate":0,
                           "averageAudioNetworkJitter":"PT0.008S",
                           "lowFrameRateRatio":null,
                           "averageJitter":"PT0.001S",
                           "packetUtilization":1236
                        },
                        {
                           "averageAudioDegradation":null,
                           "streamId":"1000",
                           "averageVideoFrameLossPercentage":null,
                           "maxAudioNetworkJitter":"PT0.027S",
                           "maxJitter":"PT0.003S",
                           "averageVideoPacketLossRate":null,
                           "maxRoundTripTime":"PT0.022S",
                           "lowVideoProcessingCapabilityRatio":null,
                           "postForwardErrorCorrectionPacketLossRate":null,
                           "maxPacketLossRate":0,
                           "averageRatioOfConcealedSamples":0.008969,
                           "streamDirection":"calleeToCaller",
                           "wasMediaBypassed":null,
                           "maxRatioOfConcealedSamples":0,
                           "averageReceivedFrameRate":null,
                           "averageBandwidthEstimate":75821925,
                           "endDateTime":null,
                           "averageVideoFrameRate":null,
                           "averageRoundTripTime":"PT0.019S",
                           "startDateTime":null,
                           "averagePacketLossRate":0,
                           "averageAudioNetworkJitter":"PT0.008S",
                           "lowFrameRateRatio":null,
                           "averageJitter":"PT0.002S",
                           "packetUtilization":664
                        }
                     ],
                     "label":"main-audio"
                  }
               ],
               "endDateTime":"2020-08-09T13:15:56.5602744Z",
               "failureInfo":null
            }
         ]
      }
   ],
   "lastModifiedDateTime":"2020-08-09T13:24:20.528052Z",
   "@odata.context":"https://graph.microsoft.com/v1.0/$metadata#communications/callRecords(sessions(segments()))/$entity",
   "type":"peerToPeer",
   "endDateTime":"2020-08-09T13:15:56.5602744Z",
   "version":1,
   "modalities":[
      "audio"
   ],
   "startDateTime":"2020-08-09T13:15:31.225961Z",
   "joinWebUrl":null,
   "organizer":{
      "spoolUser":null,
      "encrypted":null,
      "application":null,
      "acsUser":null,
      "phone":null,
      "spoolApplicationInstance":null,
      "applicationInstance":null,
      "acsApplicationInstance":null,
      "guest":null,
      "device":null,
      "user":{
         "displayName":"Dele Olajide",
         "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
         "id":"83ec482c-3bc5-4116-acee-e081cc720630"
      },
      "onPremises":null
   },
   "id":"bf7f20f0-5843-4e93-9e67-3a92cd44700b",
   "participants":[
      {
         "spoolUser":null,
         "encrypted":null,
         "application":null,
         "acsUser":null,
         "phone":null,
         "spoolApplicationInstance":null,
         "applicationInstance":null,
         "acsApplicationInstance":null,
         "guest":null,
         "device":null,
         "user":{
            "displayName":"Dele Olajide",
            "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
            "id":"83ec482c-3bc5-4116-acee-e081cc720630"
         },
         "onPremises":null
      },
      {
         "spoolUser":null,
         "encrypted":null,
         "application":null,
         "acsUser":null,
         "phone":null,
         "spoolApplicationInstance":null,
         "applicationInstance":null,
         "acsApplicationInstance":null,
         "guest":null,
         "device":null,
         "user":{
            "displayName":"Florence Olajide",
            "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
            "id":"ba9e081a-5748-40ca-8fd5-ab9c74dae3d1"
         },
         "onPremises":null
      }
   ]
}

-------------------------------------------------------------------------------------------------------------

--- message ---
{
   "channelData":{
      "tenant":{
         "id":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e"
      }
   },
   "serviceUrl":"https://smba.trafficmanager.net/emea/",
   "type":"message",
   "locale":"en-GB",
   "textFormat":"plain",
   "entities":[
      {
         "country":"GB",
         "locale":"en-GB",
         "type":"clientInfo",
         "platform":"Windows"
      }
   ],
   "recipient":{
      "name":"UBS Smart Call",
      "id":"28:2bc0e78e-4f70-41b1-bbdc-023c88cce69c"
   },
   "localTimestamp":"2020-08-14T10:29:02.9647631+01:00",
   "from":{
      "name":"Dele Olajide",
      "aadObjectId":"83ec482c-3bc5-4116-acee-e081cc720630",
      "id":"29:1vsRXem4CaP32UHOMeXuB7VpFV2HCCKlivC1bccSdibtQh8D8EGCdbaIYeeIonz6hECXw_MPk9z8rcclmx2HIVA"
   },
   "text":"SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS",
   "id":"1597397342949",
   "channelId":"msteams",
   "conversation":{
      "conversationType":"personal",
      "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
      "id":"a:1e1WMceUCbRtIVgGLKRPOMuFl9l_AOcLTnM8eHkDVEhxgbYGWfhOi9HJS9kn4fUC5LEIG18oUQkMsjNOS1u0FfkYiV8TiYRAoysW6oxSQ3mG8HMIF3xgX94ngJXUbh8Q_"
   },
   "timestamp":"2020-08-14T09:29:02.9647631Z"
}
-------------------------------------------------------------------------------------------------------------

--- message rection ---

{
   "channelData":{
      "legacy":{
         "replyToId":"1:1jIbxypXzwN2hefYm9eG4pbHenB8n1BKrxJrcyJHVRXU"
      },
      "tenant":{
         "id":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e"
      }
   },
   "replyToId":"1597835402947",
   "serviceUrl":"https://smba.trafficmanager.net/emea/",
   "recipient":{
      "name":"UBS Smart Call",
      "id":"28:2bc0e78e-4f70-41b1-bbdc-023c88cce69c"
   },
   "reactionsAdded":[
      {
         "type":"like"
      }
   ],
   "from":{
      "aadObjectId":"83ec482c-3bc5-4116-acee-e081cc720630",
      "id":"29:1vsRXem4CaP32UHOMeXuB7VpFV2HCCKlivC1bccSdibtQh8D8EGCdbaIYeeIonz6hECXw_MPk9z8rcclmx2HIVA"
   },
   "id":"1597835402947",
   "type":"messageReaction",
   "channelId":"msteams",
   "conversation":{
      "conversationType":"personal",
      "tenantId":"a83ec96f-82b0-456e-90a2-a6ba1ce7fc4e",
      "id":"a:1e1WMceUCbRtIVgGLKRPOMuFl9l_AOcLTnM8eHkDVEhxgbYGWfhOi9HJS9kn4fUC5LEIG18oUQkMsjNOS1u0FfkYiV8TiYRAoysW6oxSQ3mG8HMIF3xgX94ngJXUbh8Q_"
   },
   "timestamp":"2020-08-19T11:10:32.8162836Z"
}
-------------------------------------------------------------------------------------------------------------
-- web chat conversation --

{
   "channelData":{
      "clientActivityID":"159799359208296n7ckn31e",
      "clientTimestamp":"2020-08-21T07:06:32.083Z"
   },
   "serviceUrl":"https://webchat.botframework.com/",
   "type":"message",
   "locale":"en-US",
   "textFormat":"plain",
   "entities":[
      {
         "supportsTts":true,
         "type":"ClientCapabilities",
         "requiresBotState":true,
         "supportsListening":true
      }
   ],
   "recipient":{
      "name":"UBS Smart Call",
      "id":"ubs_smart_call@Aerg4d_3T0M"
   },
   "from":{
      "name":"You",
      "id":"83ec482c-3bc5-4116-acee-e081cc720630"
   },
   "id":"5qn3GxiQh95GN4uqaWkjto-a|0000000",
   "text":"hello bot",
   "channelId":"webchat",
   "conversation":{
      "id":"5qn3GxiQh95GN4uqaWkjto-a"
   },
   "timestamp":"2020-08-21T07:06:32.1517386Z"
}
-------------------------------------------------------------------------------------------------------------

<iframe src='https://webchat.botframework.com/embed/ubs_smart_call?s=n3HjUBsZyZ4.ucohOrKzFiDBmTxZwNNjyzqDuRJDOwhUffI35r8m9W0'  style='min-width: 400px; width: 100%; min-height: 500px;'></iframe>
-------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------
