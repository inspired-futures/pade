document.addEventListener('DOMContentLoaded', function()
{
    microsoftTeams.initialize();
    microsoftTeams.appInitialization.notifyAppLoaded();

    microsoftTeams.getContext(async context => {
        console.log("smart scheduling logged in user", context.userPrincipalName);
        microsoftTeams.appInitialization.notifySuccess();
    });

    microsoftTeams.registerOnThemeChangeHandler(function (theme) {
        console.log("change theme", theme);
    });
})