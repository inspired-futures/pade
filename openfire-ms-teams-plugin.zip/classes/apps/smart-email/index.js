document.addEventListener('DOMContentLoaded', function()
{
    microsoftTeams.initialize();
    microsoftTeams.appInitialization.notifyAppLoaded();

    microsoftTeams.getContext(async context => {
        console.log("smart email logged in user", context.userPrincipalName);
        microsoftTeams.appInitialization.notifySuccess();
    });

    microsoftTeams.registerOnThemeChangeHandler(function (theme) {
        console.log("change theme", theme);
    });

    const deeplink = document.getElementById("deeplink");

    deeplink.addEventListener("click", function(evt)
    {
        const body = {
            "name":"Dele Olajide",
            "source":"dele_olajide.net",
            "interest":"442045228153dele_olajide.net",
            "destination":"florence@olajide.net"
        };

        fetch("https://pade.chat:5443/apps/webhook", {method: "POST", body: JSON.stringify(body)}).then(function(response)
        {
            console.debug('webhook ok', response);
            window.open("callto:" + body.destination, "msteams");

        }).catch(function (err) {
            console.error('webhook error', err);
        });
    });
})