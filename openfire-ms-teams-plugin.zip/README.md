# openfire-ms-teams-plugin
Openlink plugin for Microsoft Teams
